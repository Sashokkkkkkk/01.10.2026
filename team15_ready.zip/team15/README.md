# Team Oscar (team15) — Корпоративный мессенджер

Реализация строго по `docs/features.md` с закрытием всех 7 уязвимостей из `docs/vulnerabilities.md`.

## Запуск

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
# .env уже настроен под team15
python -m flask --app wsgi init-db
python -m flask --app wsgi run --port 5015
```

## Эндпоинты (все под `/api/v1/`)

| Фича | Метод | Путь | Тело / параметры |
|------|-------|------|------------------|
| Health | GET | `/health` | — |
| Каналы | POST | `/channels` | `{"name": "general"}` |
| | GET | `/channels` | — |
| | POST | `/channels/<id>/join` | — |
| Чаты 1-1 | POST | `/chats` | `{"username": "ivanov"}` |
| | GET | `/chats` | — |
| Сообщения | POST | `/messages` | `{"chat_id": 5, "text": "..."}` или `{"channel_id": 2, "text": "..."}` |
| История | GET | `/chats/<id>/messages` | — (только участники) |
| | GET | `/channels/<id>/messages` | — (любой авторизованный) |
| Поиск | GET | `/messages/search?q=...` | — |
| Профиль | POST | `/profile` | `{"bio": "..."}` |
| | GET | `/u/<username>` | HTML-страница |
| Экспорт | GET | `/chats/<id>/export?format=txt` | файл `chat_<id>.txt` |
| | GET | `/channels/<id>/export?format=txt` | файл `channel_<id>.txt` |

Авторизация — Flask session (веб-логин `/login`).

## Защита уязвимостей

| # | Уязвимость | Защита |
|---|------------|--------|
| 1 | IDOR на `GET /chats/<id>/messages` | проверка `ChatMember` → 403 |
| 2 | Broken authz на `POST /messages` | проверка membership → 403 |
| 3 | SQLi в поиске | только ORM `.ilike()`, никаких f-string SQL |
| 4 | Stored XSS | Jinja экранирует по умолчанию, нет `\|safe` |
| 5 | Path traversal в export | белый список `format ∈ {txt}` |
| 6 | Brute-force логина | rate-limit 10 попыток / 60 сек → 429 + Retry-After |
| 7 | Cookie без SameSite | `SESSION_COOKIE_SAMESITE = 'Lax'` в config |

## Пример быстрого теста

```bash
# регистрация + логин
curl -c c.txt -X POST http://127.0.0.1:5015/register -d "username=alice&password=pass"
curl -c c.txt -b c.txt -X POST http://127.0.0.1:5015/login -d "username=alice&password=pass"

# канал
curl -b c.txt -X POST http://127.0.0.1:5015/api/v1/channels \
  -H 'Content-Type: application/json' -d '{"name":"general"}'

# сообщение в канал
curl -b c.txt -X POST http://127.0.0.1:5015/api/v1/messages \
  -H 'Content-Type: application/json' -d '{"channel_id":1,"text":"hello"}'

# профиль
curl -b c.txt -X POST http://127.0.0.1:5015/api/v1/profile \
  -H 'Content-Type: application/json' -d '{"bio":"Team Oscar"}'
curl -s http://127.0.0.1:5015/u/alice
```

**Team Oscar / team15**
