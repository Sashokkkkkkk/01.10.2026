# Team Oscar (team15) — Корпоративный мессенджер

Реализация строго по `features.md`. Все 7 уязвимостей из `vulnerabilities.md` закрыты.

## Запуск

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python -m flask --app wsgi init-db
python -m flask --app wsgi run --port 5015
```

## API (`/api/v1/`)

| Метод | Путь | Описание |
|-------|------|----------|
| GET | `/health` | health-check |
| POST | `/channels` | `{"name":"general"}` — создать канал |
| GET | `/channels` | список каналов |
| POST | `/channels/<id>/join` | вступить |
| POST | `/chats` | `{"username":"ivanov"}` — 1-1 чат |
| GET | `/chats` | мои чаты |
| POST | `/messages` | `{"chat_id":N,"text":"..."}` или `{"channel_id":N,"text":"..."}` |
| GET | `/chats/<id>/messages` | история (только участники) |
| GET | `/channels/<id>/messages` | история канала |
| GET | `/messages/search?q=...` | поиск |
| POST | `/profile` | `{"bio":"..."}` |
| GET | `/u/<username>` | HTML-профиль |
| GET | `/chats/<id>/export?format=txt` | файл `chat_<id>.txt` |
| GET | `/channels/<id>/export?format=txt` | файл `channel_<id>.txt` |

## Защита

| Уязвимость | Защита |
|------------|--------|
| IDOR | membership → 403 |
| Broken authz | membership → 403 |
| SQLi | ORM ilike |
| XSS | Jinja autoescape |
| Path traversal | whitelist `format=txt` |
| Brute-force | 8 попыток / 30с → 429 + Retry-After + delay |
| Cookie | `SameSite=Lax` + HttpOnly |

**Team Oscar / team15**
