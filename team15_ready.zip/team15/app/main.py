from flask import Blueprint, render_template, abort, session

from .models import User, Channel, ChannelMember
from .extensions import db

bp = Blueprint('main', __name__)


@bp.get('/')
def index():
    return render_template('index.html')


@bp.get('/u/<username>')
def public_profile(username):
    """
    GET /u/<username> — HTML-страница публичного профиля.
    Показывает bio и список публичных каналов пользователя.
    Jinja экранирует по умолчанию → XSS защищён.
    """
    user = User.query.filter_by(username=username).first()
    if not user:
        abort(404)

    # Каналы, в которых пользователь состоит (публичные)
    memberships = ChannelMember.query.filter_by(user_id=user.id).all()
    channel_ids = [m.channel_id for m in memberships]
    channels = []
    if channel_ids:
        channels = (
            Channel.query
            .filter(Channel.id.in_(channel_ids))
            .order_by(Channel.name)
            .all()
        )

    return render_template(
        'profile.html',
        profile_user=user,
        channels=channels,
    )
