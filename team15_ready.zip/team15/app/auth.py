"""
Веб-аутентификация + защита от brute-force (vulnerabilities.md #6).

Rate-limit: не более 10 неудачных попыток с одного IP за 60 секунд.
При превышении — 429 + Retry-After.
"""
import time
from collections import defaultdict
from threading import Lock

from flask import (
    Blueprint, render_template, request, redirect,
    url_for, session, flash, make_response,
)
from .models import User
from .extensions import db

bp = Blueprint('auth', __name__)

# Простой in-memory rate limiter (достаточно для одного процесса)
_failed_attempts: dict[str, list[float]] = defaultdict(list)
_lock = Lock()
MAX_ATTEMPTS = 10
WINDOW_SEC = 60


def _client_ip() -> str:
    # X-Forwarded-For на случай прокси; иначе remote_addr
    forwarded = request.headers.get('X-Forwarded-For', '')
    if forwarded:
        return forwarded.split(',')[0].strip()
    return request.remote_addr or 'unknown'


def _is_rate_limited(ip: str) -> bool:
    now = time.time()
    with _lock:
        attempts = _failed_attempts[ip]
        # чистим устаревшие
        _failed_attempts[ip] = [t for t in attempts if now - t < WINDOW_SEC]
        return len(_failed_attempts[ip]) >= MAX_ATTEMPTS


def _record_failure(ip: str) -> None:
    with _lock:
        _failed_attempts[ip].append(time.time())


def _clear_failures(ip: str) -> None:
    with _lock:
        _failed_attempts.pop(ip, None)


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if not username or not password:
            flash('Заполните все поля')
        elif len(username) > 80:
            flash('Слишком длинный логин')
        elif User.query.filter_by(username=username).first():
            flash('Пользователь уже существует')
        else:
            user = User(username=username)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            return redirect(url_for('auth.login'))
    return render_template('auth/register.html')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        ip = _client_ip()

        if _is_rate_limited(ip):
            resp = make_response(render_template('auth/login.html'), 429)
            resp.headers['Retry-After'] = str(WINDOW_SEC)
            flash('Слишком много попыток. Подождите минуту.')
            return resp

        username = (request.form.get('username') or '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            _clear_failures(ip)
            session['user_id'] = user.id
            session.permanent = True
            return redirect(url_for('main.index'))

        _record_failure(ip)
        flash('Неверные данные')
    return render_template('auth/login.html')


@bp.get('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('main.index'))
