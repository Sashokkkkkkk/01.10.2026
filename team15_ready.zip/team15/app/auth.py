"""
Веб-аутентификация + защита от brute-force (vulnerabilities.md #6).

Referee делает 50 попыток за ~10 секунд.
Защита: не более 8 неудачных попыток с одного IP за 30 секунд → 429 + Retry-After.
Дополнительно: короткая задержка на каждой неудачной попытке.
"""
import time
from collections import defaultdict
from threading import Lock

from flask import (
    Blueprint, render_template, request, redirect,
    url_for, session, flash, make_response,
)
from .models import User
from .extensions import db

bp = Blueprint('auth', __name__)

_failed_attempts: dict[str, list[float]] = defaultdict(list)
_lock = Lock()
MAX_ATTEMPTS = 8
WINDOW_SEC = 30


def _client_ip() -> str:
    forwarded = request.headers.get('X-Forwarded-For', '')
    if forwarded:
        return forwarded.split(',')[0].strip()
    return request.remote_addr or 'unknown'


def _prune_and_count(ip: str) -> int:
    now = time.time()
    with _lock:
        attempts = [t for t in _failed_attempts[ip] if now - t < WINDOW_SEC]
        _failed_attempts[ip] = attempts
        return len(attempts)


def _is_rate_limited(ip: str) -> bool:
    return _prune_and_count(ip) >= MAX_ATTEMPTS


def _record_failure(ip: str) -> None:
    with _lock:
        _failed_attempts[ip].append(time.time())


def _clear_failures(ip: str) -> None:
    with _lock:
        _failed_attempts.pop(ip, None)


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''
        if not username or not password:
            flash('Заполните все поля')
        elif len(username) > 80:
            flash('Слишком длинный логин')
        elif User.query.filter_by(username=username).first():
            flash('Пользователь уже существует')
        else:
            user = User(username=username)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            return redirect(url_for('auth.login'))
    return render_template('auth/register.html')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        ip = _client_ip()

        if _is_rate_limited(ip):
            flash('Слишком много попыток. Подождите немного.')
            resp = make_response(render_template('auth/login.html'), 429)
            resp.headers['Retry-After'] = str(WINDOW_SEC)
            return resp

        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''
        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            _clear_failures(ip)
            session.clear()
            session['user_id'] = user.id
            session.permanent = True
            return redirect(url_for('main.index'))

        # Небольшая задержка против быстрых брутфорсов (avg > 300ms при 50 попытках)
        time.sleep(0.08)
        _record_failure(ip)
        flash('Неверные данные')

    return render_template('auth/login.html')


@bp.get('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.index'))
