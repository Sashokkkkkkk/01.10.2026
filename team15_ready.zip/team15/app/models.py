from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from .extensions import db


class User(db.Model):
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    bio = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def to_public_dict(self) -> dict:
        return {
            'id': self.id,
            'username': self.username,
            'bio': self.bio or '',
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }


class Channel(db.Model):
    __tablename__ = 'channel'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, default='')
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    owner = db.relationship('User', backref=db.backref('owned_channels', lazy='dynamic'))
    members = db.relationship(
        'ChannelMember', back_populates='channel', cascade='all, delete-orphan',
    )
    messages = db.relationship(
        'Message', back_populates='channel', cascade='all, delete-orphan',
        foreign_keys='Message.channel_id',
    )

    def to_dict(self, member_count: int | None = None) -> dict:
        data = {
            'id': self.id,
            'name': self.name,
            'description': self.description or '',
            'owner_id': self.owner_id,
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }
        if member_count is not None:
            data['member_count'] = member_count
        return data


class ChannelMember(db.Model):
    __tablename__ = 'channel_member'
    __table_args__ = (
        db.UniqueConstraint('channel_id', 'user_id', name='uq_channel_user'),
    )

    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.Integer, db.ForeignKey('channel.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    channel = db.relationship('Channel', back_populates='members')
    user = db.relationship('User')


class Chat(db.Model):
    __tablename__ = 'chat'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), default='')
    is_group = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    members = db.relationship(
        'ChatMember', back_populates='chat', cascade='all, delete-orphan',
    )
    messages = db.relationship(
        'Message', back_populates='chat', cascade='all, delete-orphan',
        foreign_keys='Message.chat_id',
    )

    def to_dict(self, current_user_id: int | None = None) -> dict:
        member_ids = [m.user_id for m in self.members]
        data = {
            'id': self.id,
            'title': self.title or '',
            'is_group': self.is_group,
            'member_ids': member_ids,
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
            'created_by': self.created_by,
        }
        if not self.is_group and current_user_id is not None:
            other = next(
                (m.user for m in self.members if m.user_id != current_user_id),
                None,
            )
            if other:
                data['title'] = other.username
        return data


class ChatMember(db.Model):
    __tablename__ = 'chat_member'
    __table_args__ = (
        db.UniqueConstraint('chat_id', 'user_id', name='uq_chat_user'),
    )

    id = db.Column(db.Integer, primary_key=True)
    chat_id = db.Column(db.Integer, db.ForeignKey('chat.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    chat = db.relationship('Chat', back_populates='members')
    user = db.relationship('User')


class Message(db.Model):
    __tablename__ = 'message'

    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    channel_id = db.Column(db.Integer, db.ForeignKey('channel.id'), nullable=True, index=True)
    chat_id = db.Column(db.Integer, db.ForeignKey('chat.id'), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    author = db.relationship('User')
    channel = db.relationship('Channel', back_populates='messages', foreign_keys=[channel_id])
    chat = db.relationship('Chat', back_populates='messages', foreign_keys=[chat_id])

    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'text': self.content,
            'content': self.content,
            'author_id': self.author_id,
            'author_username': self.author.username if self.author else None,
            'channel_id': self.channel_id,
            'chat_id': self.chat_id,
            'created_at': self.created_at.isoformat() + 'Z' if self.created_at else None,
        }
