"""
REST API корпоративного мессенджера — строго по features.md.

Все эндпоинты под /api/v1/.
Авторизация — Flask session.

Защита (vulnerabilities.md):
  1. IDOR          — membership check → 403
  2. Broken authz  — membership check на POST /messages → 403
  3. SQLi          — только ORM ilike
  4. XSS           — Jinja без |safe; API отдаёт JSON
  5. Path traversal— format только из белого списка {'txt'}
  6. Brute force   — rate-limit в auth.py
  7. Cookie        — SESSION_COOKIE_SAMESITE = 'Lax'
"""
from functools import wraps
from io import BytesIO

from flask import (
    Blueprint, jsonify, request, session, current_app, send_file,
)
from sqlalchemy import or_

from .extensions import db
from .models import User, Channel, ChannelMember, Chat, ChatMember, Message

bp = Blueprint('api', __name__)


# ---- helpers ----------------------------------------------------------------

def _current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return db.session.get(User, uid)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = _current_user()
        if not user:
            return jsonify({'error': 'authentication required'}), 401
        return f(user, *args, **kwargs)
    return decorated


def _err(msg: str, code: int = 400):
    return jsonify({'error': msg}), code


def _is_channel_member(user_id: int, channel_id: int) -> bool:
    return (
        ChannelMember.query
        .filter_by(channel_id=channel_id, user_id=user_id)
        .first()
    ) is not None


def _is_chat_member(user_id: int, chat_id: int) -> bool:
    return (
        ChatMember.query
        .filter_by(chat_id=chat_id, user_id=user_id)
        .first()
    ) is not None


# ---- health -----------------------------------------------------------------

@bp.get('/health')
def health():
    return jsonify({
        'status': 'ok',
        'team_id': current_app.config['TEAM_ID'],
        'team_name': current_app.config['TEAM_NAME'],
    })


# ---- 2. Публичные каналы ----------------------------------------------------

@bp.post('/channels')
@login_required
def create_channel(user):
    """POST /api/v1/channels  {"name": "general"}"""
    data = request.get_json(silent=True) or {}
    name = (data.get('name') or '').strip()
    if not name or len(name) > 100:
        return _err('name is required, max 100 chars')
    if Channel.query.filter_by(name=name).first():
        return _err('channel name already taken', 409)

    ch = Channel(
        name=name,
        description=(data.get('description') or '').strip()[:2000],
        owner_id=user.id,
    )
    db.session.add(ch)
    db.session.flush()
    db.session.add(ChannelMember(channel_id=ch.id, user_id=user.id))
    db.session.commit()
    return jsonify(ch.to_dict(member_count=1)), 201


@bp.get('/channels')
@login_required
def list_channels(user):
    """GET /api/v1/channels — список всех публичных каналов"""
    channels = Channel.query.order_by(Channel.name).all()
    result = []
    for ch in channels:
        cnt = ChannelMember.query.filter_by(channel_id=ch.id).count()
        d = ch.to_dict(member_count=cnt)
        d['is_member'] = _is_channel_member(user.id, ch.id)
        result.append(d)
    return jsonify(result)


@bp.post('/channels/<int:channel_id>/join')
@login_required
def join_channel(user, channel_id):
    """POST /api/v1/channels/<id>/join"""
    ch = db.session.get(Channel, channel_id)
    if not ch:
        return _err('channel not found', 404)
    if _is_channel_member(user.id, ch.id):
        return jsonify({'status': 'already_member'})
    db.session.add(ChannelMember(channel_id=ch.id, user_id=user.id))
    db.session.commit()
    return jsonify({'status': 'joined'})


# ---- 3. Приватные чаты (1-на-1) ---------------------------------------------

@bp.post('/chats')
@login_required
def create_chat(user):
    """
    POST /api/v1/chats  {"username": "ivanov"}
    Создаёт 1-на-1 чат. Если уже есть — возвращает существующий.
    """
    data = request.get_json(silent=True) or {}
    username = (data.get('username') or '').strip()
    if not username:
        return _err('username is required')

    other = User.query.filter_by(username=username).first()
    if not other:
        return _err('user not found', 404)
    if other.id == user.id:
        return _err('cannot create chat with yourself')

    # Ищем существующий 1-1 чат между двумя пользователями
    subq = (
        db.session.query(ChatMember.chat_id)
        .filter(ChatMember.user_id.in_([user.id, other.id]))
        .group_by(ChatMember.chat_id)
        .having(db.func.count(ChatMember.user_id) == 2)
    )
    existing = (
        Chat.query
        .filter(Chat.is_group.is_(False), Chat.id.in_(subq))
        .first()
    )
    if existing:
        return jsonify(existing.to_dict(current_user_id=user.id))

    chat = Chat(title='', is_group=False, created_by=user.id)
    db.session.add(chat)
    db.session.flush()
    db.session.add(ChatMember(chat_id=chat.id, user_id=user.id))
    db.session.add(ChatMember(chat_id=chat.id, user_id=other.id))
    db.session.commit()
    return jsonify(chat.to_dict(current_user_id=user.id)), 201


@bp.get('/chats')
@login_required
def list_chats(user):
    """GET /api/v1/chats — список ваших приватных чатов"""
    memberships = ChatMember.query.filter_by(user_id=user.id).all()
    chat_ids = [m.chat_id for m in memberships]
    if not chat_ids:
        return jsonify([])
    chats = (
        Chat.query
        .filter(Chat.id.in_(chat_ids))
        .order_by(Chat.created_at.desc())
        .all()
    )
    return jsonify([c.to_dict(current_user_id=user.id) for c in chats])


# ---- 4. Отправка сообщения --------------------------------------------------

@bp.post('/messages')
@login_required
def post_message(user):
    """
    POST /api/v1/messages
    {"chat_id": 5, "text": "привет"}  или  {"channel_id": 2, "text": "привет"}
    """
    data = request.get_json(silent=True) or {}
    text = (data.get('text') or '').strip()
    if not text:
        return _err('text is required')
    if len(text) > 10000:
        return _err('text too long')

    chat_id = data.get('chat_id')
    channel_id = data.get('channel_id')

    if chat_id is not None:
        try:
            chat_id = int(chat_id)
        except (TypeError, ValueError):
            return _err('chat_id must be integer')
        chat = db.session.get(Chat, chat_id)
        if not chat:
            return _err('chat not found', 404)
        # Broken Authorization protection
        if not _is_chat_member(user.id, chat.id):
            return _err('forbidden', 403)
        msg = Message(content=text, author_id=user.id, chat_id=chat.id)
        db.session.add(msg)
        db.session.commit()
        return jsonify(msg.to_dict()), 201

    if channel_id is not None:
        try:
            channel_id = int(channel_id)
        except (TypeError, ValueError):
            return _err('channel_id must be integer')
        ch = db.session.get(Channel, channel_id)
        if not ch:
            return _err('channel not found', 404)
        if not _is_channel_member(user.id, ch.id):
            return _err('forbidden', 403)
        msg = Message(content=text, author_id=user.id, channel_id=ch.id)
        db.session.add(msg)
        db.session.commit()
        return jsonify(msg.to_dict()), 201

    return _err('chat_id or channel_id is required')


# ---- 5. История сообщений ---------------------------------------------------

@bp.get('/chats/<int:chat_id>/messages')
@login_required
def chat_messages(user, chat_id):
    """GET /api/v1/chats/<id>/messages — только для участников (IDOR)"""
    chat = db.session.get(Chat, chat_id)
    if not chat:
        return _err('chat not found', 404)
    if not _is_chat_member(user.id, chat.id):
        return _err('forbidden', 403)

    messages = (
        Message.query
        .filter_by(chat_id=chat.id)
        .order_by(Message.created_at.asc())
        .all()
    )
    return jsonify([m.to_dict() for m in messages])


@bp.get('/channels/<int:channel_id>/messages')
@login_required
def channel_messages(user, channel_id):
    """GET /api/v1/channels/<id>/messages — для любого авторизованного"""
    ch = db.session.get(Channel, channel_id)
    if not ch:
        return _err('channel not found', 404)

    messages = (
        Message.query
        .filter_by(channel_id=ch.id)
        .order_by(Message.created_at.asc())
        .all()
    )
    return jsonify([m.to_dict() for m in messages])


# ---- 6. Поиск по сообщениям -------------------------------------------------

@bp.get('/messages/search')
@login_required
def search_messages(user):
    """
    GET /api/v1/messages/search?q=...
    Только сообщения из доступных пользователю чатов и каналов.
    ORM → защита от SQLi.
    """
    q = (request.args.get('q') or '').strip()
    if not q:
        return _err('q is required')
    if len(q) > 200:
        return _err('q too long')

    my_channel_ids = [
        m.channel_id
        for m in ChannelMember.query.filter_by(user_id=user.id).all()
    ]
    my_chat_ids = [
        m.chat_id
        for m in ChatMember.query.filter_by(user_id=user.id).all()
    ]

    conditions = []
    if my_channel_ids:
        conditions.append(Message.channel_id.in_(my_channel_ids))
    if my_chat_ids:
        conditions.append(Message.chat_id.in_(my_chat_ids))

    if not conditions:
        return jsonify([])

    # Параметризованный LIKE через ORM — безопасно
    messages = (
        Message.query
        .filter(or_(*conditions))
        .filter(Message.content.ilike(f'%{q}%'))
        .order_by(Message.created_at.desc())
        .limit(100)
        .all()
    )
    return jsonify([m.to_dict() for m in messages])


# ---- 7. Публичный профиль (API) ---------------------------------------------

@bp.post('/profile')
@login_required
def update_profile(user):
    """POST /api/v1/profile  {"bio": "..."}"""
    data = request.get_json(silent=True) or {}
    bio = data.get('bio')
    if bio is None:
        return _err('bio is required')
    if not isinstance(bio, str) or len(bio) > 2000:
        return _err('bio must be a string up to 2000 chars')
    user.bio = bio.strip()
    db.session.commit()
    return jsonify(user.to_public_dict())


# ---- 8. Экспорт истории -----------------------------------------------------

ALLOWED_FORMATS = frozenset({'txt'})


def _messages_to_txt(messages, title: str) -> str:
    lines = [f'# {title}', f'# messages: {len(messages)}', '']
    for m in messages:
        ts = m.created_at.isoformat() + 'Z' if m.created_at else ''
        author = m.author.username if m.author else str(m.author_id)
        text = (m.content or '').replace('\n', ' ')
        lines.append(f'[{ts}] {author}: {text}')
    return '\n'.join(lines) + '\n'


@bp.get('/chats/<int:chat_id>/export')
@login_required
def export_chat(user, chat_id):
    """GET /api/v1/chats/<id>/export?format=txt → файл chat_<id>.txt"""
    fmt = (request.args.get('format') or '').strip().lower()
    if fmt not in ALLOWED_FORMATS:
        return _err('unsupported format, use format=txt', 400)

    chat = db.session.get(Chat, chat_id)
    if not chat:
        return _err('chat not found', 404)
    if not _is_chat_member(user.id, chat.id):
        return _err('forbidden', 403)

    messages = (
        Message.query
        .filter_by(chat_id=chat.id)
        .order_by(Message.created_at.asc())
        .all()
    )
    title = chat.to_dict(current_user_id=user.id).get('title') or f'chat_{chat.id}'
    body = _messages_to_txt(messages, title)
    buf = BytesIO(body.encode('utf-8'))
    return send_file(
        buf,
        mimetype='text/plain; charset=utf-8',
        as_attachment=True,
        download_name=f'chat_{chat.id}.txt',
    )


@bp.get('/channels/<int:channel_id>/export')
@login_required
def export_channel(user, channel_id):
    """GET /api/v1/channels/<id>/export?format=txt → файл channel_<id>.txt"""
    fmt = (request.args.get('format') or '').strip().lower()
    if fmt not in ALLOWED_FORMATS:
        return _err('unsupported format, use format=txt', 400)

    ch = db.session.get(Channel, channel_id)
    if not ch:
        return _err('channel not found', 404)

    messages = (
        Message.query
        .filter_by(channel_id=ch.id)
        .order_by(Message.created_at.asc())
        .all()
    )
    body = _messages_to_txt(messages, ch.name)
    buf = BytesIO(body.encode('utf-8'))
    return send_file(
        buf,
        mimetype='text/plain; charset=utf-8',
        as_attachment=True,
        download_name=f'channel_{ch.id}.txt',
    )
