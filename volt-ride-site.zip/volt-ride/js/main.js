document.addEventListener('DOMContentLoaded', () => {
  // ===== Navbar scroll =====
  const navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 40);
    });
  }

  // ===== Mobile menu =====
  const mobileBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  if (mobileBtn && mobileMenu) {
    mobileBtn.addEventListener('click', () => mobileMenu.classList.toggle('open'));
    mobileMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => mobileMenu.classList.remove('open'));
    });
  }

  // ===== Filters =====
  const filterBtns = document.querySelectorAll('.filter-btn');
  const productCards = document.querySelectorAll('.product-card');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      productCards.forEach(card => {
        const cat = card.dataset.category;
        if (filter === 'all' || cat === filter) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });

  // ===== Toast =====
  const toast = document.getElementById('toast');
  const toastMsg = document.getElementById('toast-message');
  let toastTimer;
  function showToast(message) {
    if (!toast || !toastMsg) return;
    toastMsg.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
  }

  // ===== Cart =====
  const CART_KEY = 'veloride_cart';
  let cart = loadCart();

  function loadCart() {
    try {
      return JSON.parse(localStorage.getItem(CART_KEY)) || [];
    } catch {
      return [];
    }
  }
  function saveCart() {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    updateCartUI();
  }

  function parsePrice(str) {
    return parseInt(String(str).replace(/\s|₽/g, ''), 10) || 0;
  }
  function formatPrice(n) {
    return n.toLocaleString('ru-RU') + ' ₽';
  }

  function addToCart(item) {
    const existing = cart.find(i => i.id === item.id);
    if (existing) {
      existing.qty += 1;
    } else {
      cart.push({ ...item, qty: 1 });
    }
    saveCart();
    showToast(item.name + ' добавлен в корзину');
  }

  // From product page
  window.addEventListener('add-to-cart', (e) => {
    if (e.detail) addToCart(e.detail);
  });

  function removeFromCart(id) {
    cart = cart.filter(i => i.id !== id);
    saveCart();
    showToast('Товар удалён из корзины');
  }

  function changeQty(id, delta) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty < 1) {
      removeFromCart(id);
    } else {
      saveCart();
    }
  }

  function cartTotal() {
    return cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  }
  function cartCount() {
    return cart.reduce((sum, i) => sum + i.qty, 0);
  }

  // Product cards → add to cart
  document.querySelectorAll('[data-action="cart"]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      const card = btn.closest('.product-card');
      if (!card) return;
      const name = card.querySelector('.product-title')?.textContent?.trim() || 'Товар';
      const cat = card.querySelector('.product-cat')?.textContent?.trim() || '';
      const priceEl = card.querySelector('.product-price');
      const price = parsePrice(priceEl?.textContent || '0');
      const img = card.querySelector('.product-img-wrap img')?.src || '';
      const id = name.toLowerCase().replace(/\s+/g, '-');
      addToCart({ id, name, cat, price, img });
      const original = btn.textContent;
      btn.textContent = '✓ Добавлено';
      setTimeout(() => { btn.textContent = original; }, 1200);
    });
  });

  // Wishlist
  document.querySelectorAll('[data-action="wishlist"]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      const svg = btn.querySelector('svg');
      const active = btn.classList.contains('wishlist-active');
      if (active) {
        btn.classList.remove('wishlist-active');
        if (svg) svg.setAttribute('fill', 'none');
        showToast('Удалено из избранного');
      } else {
        btn.classList.add('wishlist-active');
        if (svg) svg.setAttribute('fill', 'currentColor');
        showToast('Добавлено в избранное');
      }
    });
  });

  // Cart UI elements
  const cartOverlay = document.getElementById('cart-overlay');
  const cartDrawer = document.getElementById('cart-drawer');
  const cartBody = document.getElementById('cart-body');
  const cartTotalEl = document.getElementById('cart-total');
  const cartCountEls = document.querySelectorAll('.cart-count');

  function openCart() {
    cartOverlay?.classList.add('open');
    cartDrawer?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeCart() {
    cartOverlay?.classList.remove('open');
    cartDrawer?.classList.remove('open');
    document.body.style.overflow = '';
  }

  document.querySelectorAll('[data-action="open-cart"]').forEach(btn => {
    btn.addEventListener('click', openCart);
  });
  document.getElementById('cart-close')?.addEventListener('click', closeCart);
  cartOverlay?.addEventListener('click', closeCart);

  function updateCartUI() {
    const count = cartCount();
    cartCountEls.forEach(el => {
      el.textContent = count;
      el.classList.toggle('hidden', count === 0);
    });

    if (cartTotalEl) cartTotalEl.textContent = formatPrice(cartTotal());

    if (!cartBody) return;

    if (cart.length === 0) {
      cartBody.innerHTML = `
        <div class="cart-empty">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          <p>Корзина пуста</p>
          <a href="catalog.html" class="btn-primary" style="margin-top:0.5rem" onclick="document.getElementById('cart-close')?.click()">Перейти в каталог</a>
        </div>`;
      return;
    }

    cartBody.innerHTML = cart.map(item => `
      <div class="cart-item" data-id="${item.id}">
        <img class="cart-item-img" src="${item.img}" alt="${item.name}">
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-cat">${item.cat}</div>
          <div class="cart-item-bottom">
            <div class="cart-item-price">${formatPrice(item.price * item.qty)}</div>
            <div class="qty-controls">
              <button class="qty-btn" data-qty="-1" aria-label="Меньше">−</button>
              <span class="qty-val">${item.qty}</span>
              <button class="qty-btn" data-qty="1" aria-label="Больше">+</button>
            </div>
            <button class="cart-item-remove" data-remove aria-label="Удалить">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </div>
        </div>
      </div>
    `).join('');

    cartBody.querySelectorAll('[data-qty]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.closest('.cart-item').dataset.id;
        changeQty(id, parseInt(btn.dataset.qty, 10));
      });
    });
    cartBody.querySelectorAll('[data-remove]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.closest('.cart-item').dataset.id;
        removeFromCart(id);
      });
    });
  }

  updateCartUI();

  // ===== Checkout =====
  const checkoutOverlay = document.getElementById('checkout-overlay');
  const checkoutBody = document.getElementById('checkout-body');
  let checkoutStep = 1;
  let selectedPayment = 'card';

  function openCheckout() {
    if (cart.length === 0) {
      showToast('Корзина пуста');
      return;
    }
    closeCart();
    checkoutStep = 1;
    selectedPayment = 'card';
    renderCheckout();
    checkoutOverlay?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeCheckout() {
    checkoutOverlay?.classList.remove('open');
    document.body.style.overflow = '';
  }

  document.getElementById('btn-checkout')?.addEventListener('click', openCheckout);
  document.getElementById('checkout-close')?.addEventListener('click', closeCheckout);
  checkoutOverlay?.addEventListener('click', e => {
    if (e.target === checkoutOverlay) closeCheckout();
  });

  function renderCheckout() {
    if (!checkoutBody) return;
    const total = cartTotal();
    const delivery = total >= 35000 ? 0 : 990;

    if (checkoutStep === 1) {
      checkoutBody.innerHTML = `
        <div class="checkout-steps">
          <div class="checkout-step active">1. Данные</div>
          <div class="checkout-step">2. Оплата</div>
          <div class="checkout-step">3. Готово</div>
        </div>
        <form id="checkout-form-step1">
          <div class="form-group">
            <label for="ch-name">Имя и фамилия</label>
            <input type="text" id="ch-name" required placeholder="Иван Иванов">
          </div>
          <div class="form-group">
            <label for="ch-phone">Телефон</label>
            <input type="tel" id="ch-phone" required placeholder="+7 (___) ___-__-__">
          </div>
          <div class="form-group">
            <label for="ch-email">Email</label>
            <input type="email" id="ch-email" required placeholder="mail@example.com">
          </div>
          <div class="form-group">
            <label for="ch-address">Адрес доставки</label>
            <input type="text" id="ch-address" required placeholder="Город, улица, дом, квартира">
          </div>
          <div class="checkout-summary">
            <div class="checkout-summary-row"><span>Товары (${cartCount()})</span><span>${formatPrice(total)}</span></div>
            <div class="checkout-summary-row"><span>Доставка</span><span>${delivery === 0 ? 'Бесплатно' : formatPrice(delivery)}</span></div>
            <div class="checkout-summary-row total"><span>Итого</span><span>${formatPrice(total + delivery)}</span></div>
          </div>
          <button type="submit" class="btn-primary" style="width:100%;padding:0.9rem">Перейти к оплате</button>
        </form>`;

      document.getElementById('checkout-form-step1')?.addEventListener('submit', e => {
        e.preventDefault();
        checkoutStep = 2;
        renderCheckout();
      });

      // phone mask
      const ph = document.getElementById('ch-phone');
      ph?.addEventListener('input', e => {
        let v = e.target.value.replace(/\D/g, '');
        if (v.startsWith('8')) v = '7' + v.slice(1);
        if (v.startsWith('7') && v.length > 1) {
          let f = '+7';
          if (v.length > 1) f += ' (' + v.slice(1, 4);
          if (v.length >= 4) f += ') ' + v.slice(4, 7);
          if (v.length >= 7) f += '-' + v.slice(7, 9);
          if (v.length >= 9) f += '-' + v.slice(9, 11);
          e.target.value = f;
        }
      });
    } else if (checkoutStep === 2) {
      checkoutBody.innerHTML = `
        <div class="checkout-steps">
          <div class="checkout-step done">1. Данные</div>
          <div class="checkout-step active">2. Оплата</div>
          <div class="checkout-step">3. Готово</div>
        </div>
        <p style="color:#9ca3af;font-size:0.9rem;margin-bottom:1rem">Выберите способ оплаты</p>
        <div class="payment-methods">
          <div class="payment-method ${selectedPayment === 'card' ? 'selected' : ''}" data-pay="card">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
            Карта
          </div>
          <div class="payment-method ${selectedPayment === 'sbp' ? 'selected' : ''}" data-pay="sbp">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
            СБП
          </div>
          <div class="payment-method ${selectedPayment === 'cash' ? 'selected' : ''}" data-pay="cash">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2z"/></svg>
            При получении
          </div>
          <div class="payment-method ${selectedPayment === 'installment' ? 'selected' : ''}" data-pay="installment">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            Рассрочка 0%
          </div>
        </div>
        <div class="checkout-summary">
          <div class="checkout-summary-row"><span>Товары</span><span>${formatPrice(total)}</span></div>
          <div class="checkout-summary-row"><span>Доставка</span><span>${delivery === 0 ? 'Бесплатно' : formatPrice(delivery)}</span></div>
          <div class="checkout-summary-row total"><span>К оплате</span><span>${formatPrice(total + delivery)}</span></div>
        </div>
        <button class="btn-primary" id="btn-pay" style="width:100%;padding:0.9rem">Оплатить ${formatPrice(total + delivery)}</button>
        <button class="btn-secondary" id="btn-back-step" style="width:100%;margin-top:0.6rem;padding:0.7rem">Назад</button>`;

      checkoutBody.querySelectorAll('[data-pay]').forEach(el => {
        el.addEventListener('click', () => {
          selectedPayment = el.dataset.pay;
          renderCheckout();
        });
      });
      document.getElementById('btn-pay')?.addEventListener('click', () => {
        checkoutStep = 3;
        // clear cart on success
        cart = [];
        saveCart();
        renderCheckout();
      });
      document.getElementById('btn-back-step')?.addEventListener('click', () => {
        checkoutStep = 1;
        renderCheckout();
      });
    } else {
      const orderNum = 'VR-' + Math.floor(100000 + Math.random() * 900000);
      checkoutBody.innerHTML = `
        <div class="checkout-steps">
          <div class="checkout-step done">1. Данные</div>
          <div class="checkout-step done">2. Оплата</div>
          <div class="checkout-step active">3. Готово</div>
        </div>
        <div class="success-block">
          <div class="success-icon">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          </div>
          <h3>Заказ оформлен!</h3>
          <p>Номер заказа: <strong style="color:#4ade80">${orderNum}</strong><br>
          Мы свяжемся с вами для подтверждения в течение 30 минут.</p>
          <button class="btn-primary" id="btn-success-close" style="padding:0.85rem 2rem">Отлично</button>
        </div>`;
      document.getElementById('btn-success-close')?.addEventListener('click', closeCheckout);
    }
  }

  // Contact form
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('name')?.value || '';
      showToast('Спасибо' + (name ? ', ' + name : '') + '! Мы свяжемся с вами');
      form.reset();
    });
  }

  // Phone mask contact
  const phone = document.getElementById('phone');
  if (phone) {
    phone.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '');
      if (v.startsWith('8')) v = '7' + v.slice(1);
      if (v.startsWith('7') && v.length > 1) {
        let f = '+7';
        if (v.length > 1) f += ' (' + v.slice(1, 4);
        if (v.length >= 4) f += ') ' + v.slice(4, 7);
        if (v.length >= 7) f += '-' + v.slice(7, 9);
        if (v.length >= 9) f += '-' + v.slice(9, 11);
        e.target.value = f;
      }
    });
  }

  // Reveal
  const reveals = document.querySelectorAll('.reveal');
  if (reveals.length && 'IntersectionObserver' in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(el => obs.observe(el));
  } else {
    reveals.forEach(el => el.classList.add('visible'));
  }

  // Product card → product page (click on image or title)
  document.querySelectorAll('.product-card').forEach(card => {
    const title = card.querySelector('.product-title');
    const imgWrap = card.querySelector('.product-img-wrap');
    const name = title?.textContent?.trim() || '';
    const id = name.toLowerCase().replace(/\s+/g, '-');
    const go = () => { window.location.href = 'product.html?id=' + encodeURIComponent(id); };
    if (imgWrap) {
      imgWrap.style.cursor = 'pointer';
      imgWrap.addEventListener('click', go);
    }
    if (title) {
      title.style.cursor = 'pointer';
      title.addEventListener('click', go);
    }
  });

});
