document.addEventListener('DOMContentLoaded', () => {
  const navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 40);
    });
  }

  const mobileBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  if (mobileBtn && mobileMenu) {
    mobileBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
    });
    mobileMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => mobileMenu.classList.remove('open'));
    });
  }

  const filterBtns = document.querySelectorAll('.filter-btn');
  const productCards = document.querySelectorAll('.product-card');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      productCards.forEach(card => {
        const cat = card.dataset.category;
        if (filter === 'all' || cat === filter) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });

  const toast = document.getElementById('toast');
  const toastMsg = document.getElementById('toast-message');
  let toastTimer;

  function showToast(message) {
    if (!toast || !toastMsg) return;
    toastMsg.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
  }

  document.querySelectorAll('[data-action="cart"]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      const card = btn.closest('.product-card');
      const title = card ? (card.querySelector('.product-title')?.textContent || 'Товар') : 'Товар';
      showToast(title + ' добавлен в корзину');
      const original = btn.textContent;
      btn.textContent = '✓ Добавлено';
      setTimeout(() => { btn.textContent = original; }, 1500);
    });
  });

  document.querySelectorAll('[data-action="wishlist"]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      const svg = btn.querySelector('svg');
      const active = btn.classList.contains('wishlist-active');
      if (active) {
        btn.classList.remove('wishlist-active');
        if (svg) svg.setAttribute('fill', 'none');
        showToast('Удалено из избранного');
      } else {
        btn.classList.add('wishlist-active');
        if (svg) svg.setAttribute('fill', 'currentColor');
        showToast('Добавлено в избранное');
      }
    });
  });

  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('name')?.value || '';
      showToast('Спасибо' + (name ? ', ' + name : '') + '! Мы свяжемся с вами');
      form.reset();
    });
  }

  const phone = document.getElementById('phone');
  if (phone) {
    phone.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '');
      if (v.startsWith('8')) v = '7' + v.slice(1);
      if (v.startsWith('7') && v.length > 1) {
        let f = '+7';
        if (v.length > 1) f += ' (' + v.slice(1, 4);
        if (v.length >= 4) f += ') ' + v.slice(4, 7);
        if (v.length >= 7) f += '-' + v.slice(7, 9);
        if (v.length >= 9) f += '-' + v.slice(9, 11);
        e.target.value = f;
      }
    });
  }

  const reveals = document.querySelectorAll('.reveal');
  if (reveals.length && 'IntersectionObserver' in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(el => obs.observe(el));
  } else {
    reveals.forEach(el => el.classList.add('visible'));
  }
});
