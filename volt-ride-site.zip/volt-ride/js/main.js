// ===== Navbar scroll effect =====
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 40) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

// ===== Mobile menu =====
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const mobileMenu = document.getElementById('mobile-menu');

mobileMenuBtn?.addEventListener('click', () => {
  mobileMenu.classList.toggle('hidden');
});

// Close mobile menu on link click
mobileMenu?.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    mobileMenu.classList.add('hidden');
  });
});

// ===== Catalog filters =====
const filterBtns = document.querySelectorAll('.filter-btn');
const productCards = document.querySelectorAll('.product-card');

filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    // Update active state
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;

    productCards.forEach(card => {
      const category = card.dataset.category;
      if (filter === 'all' || category === filter) {
        card.style.display = '';
        card.style.animation = 'fade-in 0.4s ease-out forwards';
      } else {
        card.style.display = 'none';
      }
    });
  });
});

// ===== Add to cart / Wishlist toast =====
const toast = document.getElementById('toast');
const toastMessage = document.getElementById('toast-message');
let toastTimeout;

function showToast(message) {
  toastMessage.textContent = message;
  toast.classList.remove('hidden');
  
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.add('hidden');
  }, 2800);
}

// Add to cart buttons
document.querySelectorAll('.product-actions .btn-primary').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    const card = btn.closest('.product-card');
    const title = card.querySelector('.product-title')?.textContent || 'Товар';
    showToast(`${title} добавлен в корзину`);
    
    // Brief visual feedback
    btn.textContent = '✓ Добавлено';
    setTimeout(() => {
      btn.textContent = 'В корзину';
    }, 1500);
  });
});

// Wishlist buttons
document.querySelectorAll('.product-actions .btn-icon').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    const svg = btn.querySelector('svg');
    const isActive = btn.classList.contains('wishlist-active');
    
    if (isActive) {
      btn.classList.remove('wishlist-active');
      svg.setAttribute('fill', 'none');
      showToast('Удалено из избранного');
    } else {
      btn.classList.add('wishlist-active');
      svg.setAttribute('fill', 'currentColor');
      btn.style.color = '#f87171';
      showToast('Добавлено в избранное');
    }
  });
});

// ===== Contact form =====
const contactForm = document.getElementById('contact-form');
contactForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('name').value;
  showToast(`Спасибо, ${name}! Мы свяжемся с вами в ближайшее время`);
  contactForm.reset();
});

// ===== Smooth reveal on scroll (simple IntersectionObserver) =====
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -40px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

// Observe feature cards, product cards, testimonials
document.querySelectorAll('.feature-card, .product-card, .testimonial-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(24px)';
  el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
  observer.observe(el);
});

// ===== Phone mask (simple) =====
const phoneInput = document.getElementById('phone');
phoneInput?.addEventListener('input', (e) => {
  let value = e.target.value.replace(/\D/g, '');
  if (value.startsWith('8')) value = '7' + value.slice(1);
  if (value.startsWith('7') && value.length > 1) {
    let formatted = '+7';
    if (value.length > 1) formatted += ' (' + value.slice(1, 4);
    if (value.length >= 4) formatted += ') ' + value.slice(4, 7);
    if (value.length >= 7) formatted += '-' + value.slice(7, 9);
    if (value.length >= 9) formatted += '-' + value.slice(9, 11);
    e.target.value = formatted;
  }
});
