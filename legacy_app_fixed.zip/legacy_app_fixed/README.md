# Legacy App — исправленная версия

## Быстрый запуск (Windows)

**Самый простой способ:** двойной клик по файлу `run.bat`

Он сам найдёт Python, установит Flask, создаст базу и запустит сервер.

После запуска откройте в браузере: **http://127.0.0.1:5001**

---

## Запуск вручную

```powershell
cd папка_с_этим_проектом

python -m pip install -r requirements.txt
python seed.py
python app.py
```

Если команда `python` не находится:

```powershell
py -3 -m pip install -r requirements.txt
py -3 seed.py
py -3 app.py
```

Или полный путь (пример для Python 3.15):

```powershell
& "$env:LOCALAPPDATA\Python\pythoncore-3.15-64\python.exe" -m pip install flask
& "$env:LOCALAPPDATA\Python\pythoncore-3.15-64\python.exe" seed.py
& "$env:LOCALAPPDATA\Python\pythoncore-3.15-64\python.exe" app.py
```

---

## Тесты

```powershell
python test_app.py
```

Ожидаемый результат: все тесты `ok`, в конце `OK: N tests passed`.

---

## API

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/` | HTML-страница со списком товаров |
| GET | `/api/items` | JSON: товары + количество заказов |
| POST | `/api/orders` | Создать заказ: `{"item_id": 1, "qty": 2}` |
| GET | `/api/report?from=2024-01-01&to=2025-01-01` | Отчёт по заказам за период |
| GET | `/api/health` | Проверка, что приложение и БД работают |

---

## Что было исправлено

| Было (плохо) | Стало |
|--------------|--------|
| SQL через f-string (`f"...{id}..."`) — инъекции | Параметризованные запросы `?` |
| N+1: отдельный COUNT на каждый товар | Один `LEFT JOIN` + `GROUP BY` |
| Секретный ключ захардкожен в коде | Берётся из `SECRET_KEY` (env) |
| Новое соединение на каждый вызов, без закрытия при ошибках | `@contextmanager` + commit / rollback |
| Нет WAL, нет индексов | `PRAGMA journal_mode=WAL`, индексы на `item_id` и `created_at` |
| `except Exception: pass` → всегда 500 | Коды 400 / 404 / 500 и понятные сообщения |
| Нет проверки входных данных | Проверка типов, `qty > 0`, товар существует |
| `debug=True`, `threaded=False` | debug только при `FLASK_DEBUG=1`, `threaded=True` |
| БД искалась относительно текущей папки → `no such table` | Путь к БД и шаблонам относительно файла `app.py` |

---

## Структура проекта

```
legacy_app_fixed/
  app.py            — приложение Flask
  seed.py           — заполнение БД (500 товаров, 5000 заказов)
  test_app.py       — автотесты
  requirements.txt  — зависимости (flask)
  run.bat           — запуск одним кликом на Windows
  templates/
    index.html      — страница со списком товаров
  README.md         — эта инструкция
```
