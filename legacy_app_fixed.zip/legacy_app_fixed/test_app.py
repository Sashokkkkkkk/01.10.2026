#!/usr/bin/env python3
"""
Тесты приложения.

Запуск:
    python test_app.py
"""

from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["DB_PATH"] = _tmp.name

from app import app, init_db_if_needed, DB_PATH  # noqa: E402
import seed as seed_module  # noqa: E402


class AppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        seed_module.seed(Path(_tmp.name))
        init_db_if_needed()
        cls.client = app.test_client()

    @classmethod
    def tearDownClass(cls):
        try:
            os.unlink(_tmp.name)
        except OSError:
            pass

    # --- HTML ---
    def test_index_returns_200(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)

    def test_index_contains_title(self):
        text = self.client.get("/").get_data(as_text=True)
        self.assertIn("Товары", text)

    def test_index_contains_items(self):
        text = self.client.get("/").get_data(as_text=True)
        self.assertIn("Товар", text)

    # --- /api/items ---
    def test_api_items_status(self):
        r = self.client.get("/api/items")
        self.assertEqual(r.status_code, 200)

    def test_api_items_count(self):
        data = self.client.get("/api/items").get_json()
        self.assertEqual(len(data), 500)

    def test_api_items_has_orders_field(self):
        data = self.client.get("/api/items").get_json()
        self.assertIn("orders", data[0])
        self.assertIn("id", data[0])
        self.assertIn("name", data[0])
        self.assertIn("price", data[0])
        self.assertIn("qty", data[0])

    def test_api_items_orders_is_int(self):
        data = self.client.get("/api/items").get_json()
        self.assertIsInstance(data[0]["orders"], int)

    # --- /api/orders ---
    def test_create_order_ok(self):
        r = self.client.post("/api/orders", json={"item_id": 1, "qty": 3})
        self.assertEqual(r.status_code, 201)
        body = r.get_json()
        self.assertTrue(body["ok"])
        self.assertIn("order_id", body)

    def test_create_order_no_body(self):
        r = self.client.post("/api/orders", content_type="application/json")
        self.assertEqual(r.status_code, 400)

    def test_create_order_bad_json(self):
        r = self.client.post(
            "/api/orders", data="not-json", content_type="application/json"
        )
        self.assertEqual(r.status_code, 400)

    def test_create_order_bad_types(self):
        r = self.client.post("/api/orders", json={"item_id": "abc", "qty": 1})
        self.assertEqual(r.status_code, 400)

    def test_create_order_missing_fields(self):
        r = self.client.post("/api/orders", json={"item_id": 1})
        self.assertEqual(r.status_code, 400)

    def test_create_order_zero_qty(self):
        r = self.client.post("/api/orders", json={"item_id": 1, "qty": 0})
        self.assertEqual(r.status_code, 400)

    def test_create_order_negative_qty(self):
        r = self.client.post("/api/orders", json={"item_id": 1, "qty": -5})
        self.assertEqual(r.status_code, 400)

    def test_create_order_not_found(self):
        r = self.client.post("/api/orders", json={"item_id": 99999, "qty": 1})
        self.assertEqual(r.status_code, 404)

    # --- /api/report ---
    def test_report_ok(self):
        r = self.client.get("/api/report?from=2024-01-01&to=2025-12-31")
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertIn("total", data)
        self.assertIn("by_item", data)
        self.assertIsInstance(data["total"], int)
        self.assertIsInstance(data["by_item"], dict)

    def test_report_default_dates(self):
        r = self.client.get("/api/report")
        self.assertEqual(r.status_code, 200)

    def test_report_bad_from(self):
        r = self.client.get("/api/report?from=not-a-date")
        self.assertEqual(r.status_code, 400)

    def test_report_bad_to(self):
        r = self.client.get("/api/report?to=xx")
        self.assertEqual(r.status_code, 400)

    # --- /api/health ---
    def test_health_ok(self):
        r = self.client.get("/api/health")
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertEqual(data["status"], "ok")
        self.assertIn("db", data)

    # --- security: SQL injection attempts must not crash ---
    def test_sql_injection_in_order_rejected(self):
        r = self.client.post(
            "/api/orders",
            json={"item_id": "1; DROP TABLE items;--", "qty": 1},
        )
        self.assertEqual(r.status_code, 400)

    def test_sql_injection_in_report_rejected(self):
        r = self.client.get("/api/report?from=2024-01-01' OR '1'='1")
        self.assertEqual(r.status_code, 400)


if __name__ == "__main__":
    print("Running tests...")
    print(f"Temp DB: {_tmp.name}")
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(AppTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print()
    if result.wasSuccessful():
        print(f"OK: {result.testsRun} tests passed")
    else:
        print(f"FAIL: {len(result.failures) + len(result.errors)} failed")
    sys.exit(0 if result.wasSuccessful() else 1)
