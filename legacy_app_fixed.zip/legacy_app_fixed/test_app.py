#!/usr/bin/env python3
"""Тесты: python test_app.py"""

from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["DB_PATH"] = _tmp.name

from app import app, init_db_if_needed  # noqa: E402
import seed as seed_module  # noqa: E402


class AppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        seed_module.seed(Path(_tmp.name))
        init_db_if_needed()
        cls.client = app.test_client()

    @classmethod
    def tearDownClass(cls):
        try:
            os.unlink(_tmp.name)
        except OSError:
            pass

    def test_index_ok(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn("Товары", r.get_data(as_text=True))

    def test_api_items(self):
        r = self.client.get("/api/items")
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertEqual(len(data), 500)
        self.assertIn("orders", data[0])

    def test_create_order_ok(self):
        r = self.client.post("/api/orders", json={"item_id": 1, "qty": 3})
        self.assertEqual(r.status_code, 201)
        self.assertTrue(r.get_json()["ok"])

    def test_create_order_bad_json(self):
        r = self.client.post(
            "/api/orders", data="not-json", content_type="application/json"
        )
        self.assertEqual(r.status_code, 400)

    def test_create_order_bad_types(self):
        r = self.client.post("/api/orders", json={"item_id": "x", "qty": 1})
        self.assertEqual(r.status_code, 400)

    def test_create_order_negative_qty(self):
        r = self.client.post("/api/orders", json={"item_id": 1, "qty": -5})
        self.assertEqual(r.status_code, 400)

    def test_create_order_not_found(self):
        r = self.client.post("/api/orders", json={"item_id": 99999, "qty": 1})
        self.assertEqual(r.status_code, 404)

    def test_report_ok(self):
        r = self.client.get("/api/report?from=2024-01-01&to=2025-12-31")
        self.assertEqual(r.status_code, 200)
        data = r.get_json()
        self.assertIn("total", data)
        self.assertIsInstance(data["total"], int)

    def test_report_bad_date(self):
        r = self.client.get("/api/report?from=bad")
        self.assertEqual(r.status_code, 400)

    def test_health(self):
        r = self.client.get("/api/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "ok")


if __name__ == "__main__":
    print("Running tests...")
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(AppTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
