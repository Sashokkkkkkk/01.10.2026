@echo off
chcp 65001 >nul
cd /d "%~dp0"

set PY=
where py >nul 2>&1 && set PY=py -3
if not defined PY where python >nul 2>&1 && set PY=python
if not defined PY (
    if exist "%LOCALAPPDATA%\Python\pythoncore-3.15-64\python.exe" set PY="%LOCALAPPDATA%\Python\pythoncore-3.15-64\python.exe"
)
if not defined PY (
    if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
)
if not defined PY (
    echo ERROR: Python not found. Install Python 3 from python.org
    pause
    exit /b 1
)

echo Using: %PY%
echo.

echo [1/3] Installing Flask...
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
    echo pip failed
    pause
    exit /b 1
)

echo.
echo [2/3] Creating database...
%PY% seed.py
if errorlevel 1 (
    echo seed failed
    pause
    exit /b 1
)

echo.
echo [3/3] Starting server...
echo Open browser: http://127.0.0.1:5001
echo Press Ctrl+C to stop
echo.
%PY% app.py
pause
