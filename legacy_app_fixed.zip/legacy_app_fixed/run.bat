@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo [1/3] Install Flask...
python -m pip install -r requirements.txt 2>nul
if errorlevel 1 py -3 -m pip install -r requirements.txt

echo [2/3] Seed database...
python seed.py 2>nul
if errorlevel 1 py -3 seed.py

echo [3/3] Start server -> http://127.0.0.1:5001
python app.py 2>nul
if errorlevel 1 py -3 app.py

pause
