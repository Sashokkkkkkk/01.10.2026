WengAuto — стабильная сборка (не падает на кнопках)

1. pip install -r requirements.txt
2. python app.py
3. http://127.0.0.1:5003
4. admin / пароль из seed_data.py

Исправления:
- шаблоны errors, CRM, склад
- обработка ошибок без краша (fallback HTML)
- безопасные commit() с rollback на всех формах
- модуль Оптимизация: /admin/performance
