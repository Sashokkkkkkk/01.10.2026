# modules/email_service.py — отправка email (SMTP)
"""
Настройка через переменные окружения или .env (см. .env.example):

  MAIL_ENABLED=1
  MAIL_SERVER=smtp.yandex.ru
  MAIL_PORT=465
  MAIL_USE_SSL=1
  MAIL_USERNAME=robot@yourdomain.ru
  MAIL_PASSWORD=app-password
  MAIL_DEFAULT_SENDER=WengAuto <robot@yourdomain.ru>
  MAIL_MANAGER=manager@wengauto.ru

Если MAIL_ENABLED не включён — письма не отправляются (сайт работает как раньше).
"""
from __future__ import annotations

import logging
import smtplib
import ssl
from email.message import EmailMessage
from typing import Optional

from flask import current_app

logger = logging.getLogger(__name__)


def _cfg(key: str, default: str = '') -> str:
    return str(current_app.config.get(key, default) or default).strip()


def mail_enabled() -> bool:
    v = _cfg('MAIL_ENABLED', '0').lower()
    return v in ('1', 'true', 'yes', 'on')


def send_email(
    subject: str,
    body_text: str,
    to_addrs: list[str],
    body_html: Optional[str] = None,
) -> bool:
    """Отправить письмо. Возвращает True при успехе. Ошибки только в лог."""
    if not mail_enabled():
        logger.info('MAIL disabled, skip: %s -> %s', subject, to_addrs)
        return False

    to_addrs = [a.strip() for a in to_addrs if a and a.strip()]
    if not to_addrs:
        return False

    server = _cfg('MAIL_SERVER')
    port = int(_cfg('MAIL_PORT', '465') or '465')
    username = _cfg('MAIL_USERNAME')
    password = _cfg('MAIL_PASSWORD')
    sender = _cfg('MAIL_DEFAULT_SENDER') or username
    use_ssl = _cfg('MAIL_USE_SSL', '1').lower() in ('1', 'true', 'yes', 'on')
    use_tls = _cfg('MAIL_USE_TLS', '0').lower() in ('1', 'true', 'yes', 'on')

    if not server or not sender:
        logger.warning('MAIL_SERVER / MAIL_DEFAULT_SENDER не заданы')
        return False

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = ', '.join(to_addrs)
    msg.set_content(body_text)
    if body_html:
        msg.add_alternative(body_html, subtype='html')

    try:
        if use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(server, port, timeout=20, context=context) as smtp:
                if username and password:
                    smtp.login(username, password)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(server, port, timeout=20) as smtp:
                smtp.ehlo()
                if use_tls:
                    context = ssl.create_default_context()
                    smtp.starttls(context=context)
                    smtp.ehlo()
                if username and password:
                    smtp.login(username, password)
                smtp.send_message(msg)
        logger.info('Email sent: %s -> %s', subject, to_addrs)
        return True
    except Exception as ex:
        logger.exception('Email failed: %s', ex)
        return False


def notify_new_lead(name: str, phone: str, email: str, lead_type: str, message: str, car_id=None) -> None:
    manager = _cfg('MAIL_MANAGER') or _cfg('MAIL_USERNAME')
    subject = f'[WengAuto] Новая заявка: {lead_type} — {name}'
    text = (
        f'Новая заявка с сайта WengAuto\n\n'
        f'Тип: {lead_type}\n'
        f'Имя: {name}\n'
        f'Телефон: {phone}\n'
        f'Email: {email or "—"}\n'
        f'Авто (id): {car_id or "—"}\n'
        f'Сообщение:\n{message or "—"}\n'
    )
    html = f'''
    <h2>Новая заявка</h2>
    <ul>
      <li><b>Тип:</b> {lead_type}</li>
      <li><b>Имя:</b> {name}</li>
      <li><b>Телефон:</b> {phone}</li>
      <li><b>Email:</b> {email or "—"}</li>
      <li><b>Авто ID:</b> {car_id or "—"}</li>
    </ul>
    <p><b>Сообщение:</b><br>{(message or "—").replace(chr(10), "<br>")}</p>
    '''
    if manager:
        send_email(subject, text, [manager], html)

    # Подтверждение клиенту
    if email:
        c_subj = 'WengAuto: мы получили вашу заявку'
        c_text = (
            f'Здравствуйте, {name}!\n\n'
            f'Спасибо за обращение в автосалон WengAuto.\n'
            f'Мы получили вашу заявку ({lead_type}) и свяжемся с вами в ближайшее время.\n\n'
            f'Телефон салона: +7 (495) 123-45-67\n'
            f'С уважением,\nWengAuto\n'
        )
        c_html = f'''
        <p>Здравствуйте, <b>{name}</b>!</p>
        <p>Спасибо за обращение в автосалон <b>WengAuto</b>.</p>
        <p>Мы получили вашу заявку (<i>{lead_type}</i>) и свяжемся с вами в ближайшее время.</p>
        <p>Телефон салона: +7 (495) 123-45-67</p>
        <p>С уважением,<br>WengAuto</p>
        '''
        send_email(c_subj, c_text, [email], c_html)


def notify_service_booking(name: str, phone: str, car_info: str, service_type: str, notes: str) -> None:
    manager = _cfg('MAIL_MANAGER') or _cfg('MAIL_USERNAME')
    subject = f'[WengAuto] Запись на сервис — {name}'
    text = (
        f'Новая запись на сервис\n\n'
        f'Клиент: {name}\n'
        f'Телефон: {phone}\n'
        f'Авто: {car_info or "—"}\n'
        f'Услуга: {service_type or "—"}\n'
        f'Комментарий: {notes or "—"}\n'
    )
    if manager:
        send_email(subject, text, [manager])
