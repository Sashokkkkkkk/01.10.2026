#!/usr/bin/env python3
"""Сброс пароля admin на пустой (без пароля)."""
from app import create_app
from models import db, User

app = create_app()
with app.app_context():
    db.create_all()
    u = User.query.filter_by(username='admin').first()
    if not u:
        u = User(username='admin', email='admin@wengauto.ru', full_name='Администратор', role='admin')
        db.session.add(u)
    u.set_password('')
    db.session.commit()
    print('OK: admin без пароля. Логин: admin, пароль: (пустой)')
