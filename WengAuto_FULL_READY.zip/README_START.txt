WengAuto — полная сборка
========================

1. Распаковать в C:\WengAuto (не на сетевой диск)
2. pip install -r requirements.txt
3. Скопировать .env.example в .env и указать свою почту Mail.ru
4. python reset_admin_password.py
5. python app.py
6. Сайт: http://127.0.0.1:5003

Вход admin: логин admin, пароль пустой
Модуль оптимизации: кнопка на главной / пункт меню «Оптимизация»

Email: при заявке и записи на сервис письмо уходит на MAIL_MANAGER
