using System;
using System.Data.SQLite;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    public partial class AddKnowledgeForm : Form
    {
        #region Настройки формы
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion
        private SQLiteConnection DB;
        [Obsolete]
        public AddKnowledgeForm()
        {
            InitializeComponent();
        }

        private async void AddKnowledgeForm_Load(object sender, EventArgs e)
        {
            DB = new SQLiteConnection(Database.connectionString);
            await DB.OpenAsync();
        }

        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _ = ReleaseCapture();
                _ = SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void ButtonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private async void ExpUIButtonSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxTitle.Text))
            {
                MessageBoxUI.Show("Введите заголовок статьи!", "Ошибка", "Error");
                return;
            }
            try
            {
                SQLiteCommand commandInsert = new SQLiteCommand(
                    $"INSERT INTO {Table_knowledge.main} ({Table_knowledge.title}, {Table_knowledge.category}, {Table_knowledge.content}, {Table_knowledge.tags}, {Table_knowledge.dateCreated}) VALUES (@title, @category, @content, @tags, @date)", DB);
                _ = commandInsert.Parameters.AddWithValue("title", textBoxTitle.Text.Trim());
                _ = commandInsert.Parameters.AddWithValue("category", textBoxCategory.Text.Trim());
                _ = commandInsert.Parameters.AddWithValue("content", richTextBoxContent.Text.Trim());
                _ = commandInsert.Parameters.AddWithValue("tags", textBoxTags.Text.Trim());
                _ = commandInsert.Parameters.AddWithValue("date", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                _ = await commandInsert.ExecuteNonQueryAsync();
                MessageBoxUI.Show("Статья успешно добавлена!", "Новая статья", "Accept");
                Close();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
        }
    }
}
