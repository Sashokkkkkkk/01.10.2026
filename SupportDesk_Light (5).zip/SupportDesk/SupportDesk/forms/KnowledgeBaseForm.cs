using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    public partial class KnowledgeBaseForm : Form
    {
        #region Настройки формы
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion
        #region Локальные переменные
        private SQLiteConnection DB;
        #endregion
        [Obsolete]
        public KnowledgeBaseForm()
        {
            InitializeComponent();
        }

        private async void KnowledgeBaseForm_Load(object sender, EventArgs e)
        {
            DB = new SQLiteConnection(Database.connectionString);
            await DB.OpenAsync();
            FullList();
        }
        #region Загрузка БД
        private async void FullList()
        {
            dataGridViewKnowledge.Rows.Clear();
            SQLiteDataReader sqlReader = null;
            SQLiteCommand command = new SQLiteCommand($"SELECT * FROM [{Table_knowledge.main}] ORDER BY [{Table_knowledge.id}] DESC", DB);
            List<string[]> data = new List<string[]>();
            try
            {
                sqlReader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                while (await sqlReader.ReadAsync())
                {
                    data.Add(new string[5]);
                    data[data.Count - 1][0] = Convert.ToString($"{sqlReader[$"{Table_knowledge.id}"]}");
                    data[data.Count - 1][1] = Convert.ToString($"{sqlReader[$"{Table_knowledge.title}"]}");
                    data[data.Count - 1][2] = Convert.ToString($"{sqlReader[$"{Table_knowledge.category}"]}");
                    data[data.Count - 1][3] = Convert.ToString($"{sqlReader[$"{Table_knowledge.tags}"]}");
                    data[data.Count - 1][4] = Convert.ToString($"{sqlReader[$"{Table_knowledge.dateCreated}"]}");
                }

                foreach (string[] s in data)
                {
                    _ = dataGridViewKnowledge.Rows.Add(s);
                }
                dataGridViewKnowledge.ClearSelection();
                if (dataGridViewKnowledge.Columns.Count > 0)
                    dataGridViewKnowledge.Columns[0].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
            finally
            {
                sqlReader?.Close();
            }
        }
        #endregion
        #region Управление формой
        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _ = ReleaseCapture();
                _ = SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
        #region Назад
        [Obsolete]
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            if (DataUsers.GroupUser == "ADMIN")
            {
                Form fMain = new MainAdminForm();
                fMain.Show();
                fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                Hide();
            }
            else
            {
                Form fMain = new MainWorkerForm();
                fMain.Show();
                fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                Hide();
            }
        }

        private void Form_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }
        #endregion
        #region Обновить
        private void ExpUIButtonRefresh_Click(object sender, EventArgs e)
        {
            FullList();
            richTextBoxContent.Clear();
            textBoxSearch.Clear();
        }
        #endregion
        #region Добавить
        [Obsolete]
        private void ExpUIButtonAdd_Click(object sender, EventArgs e)
        {
            Form fAdd = new AddKnowledgeForm();
            fAdd.ShowDialog();
            FullList();
        }
        #endregion
        #region Удалить
        private async void ExpUIButtonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewKnowledge.SelectedCells.Count > 0)
            {
                int selectedrowindex = dataGridViewKnowledge.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridViewKnowledge.Rows[selectedrowindex];
                string id = Convert.ToString(selectedRow.Cells["ColumnId"].Value);
                string title = Convert.ToString(selectedRow.Cells["ColumnTitle"].Value);
                try
                {
                    SQLiteCommand commandDelete = new SQLiteCommand($"DELETE FROM {Table_knowledge.main} WHERE [{Table_knowledge.id}] = @id", DB);
                    _ = commandDelete.Parameters.AddWithValue("id", id);
                    _ = await commandDelete.ExecuteNonQueryAsync();
                    MessageBoxUI.Show($"Статья «{title}» удалена!", "Удаление", "Accept");
                    FullList();
                    richTextBoxContent.Clear();
                }
                catch (Exception ex)
                {
                    MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
                }
            }
            else
            {
                MessageBoxUI.Show("Выберите статью для удаления!", "Удаление", "Error");
            }
        }
        #endregion
        #region Выбор строки — показ содержимого
        private async void dataGridViewKnowledge_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewKnowledge.SelectedCells.Count > 0)
            {
                int selectedrowindex = dataGridViewKnowledge.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridViewKnowledge.Rows[selectedrowindex];
                string id = Convert.ToString(selectedRow.Cells["ColumnId"].Value);
                try
                {
                    SQLiteCommand command = new SQLiteCommand($"SELECT [{Table_knowledge.content}] FROM [{Table_knowledge.main}] WHERE [{Table_knowledge.id}] = @id", DB);
                    _ = command.Parameters.AddWithValue("id", id);
                    object result = await command.ExecuteScalarAsync();
                    richTextBoxContent.Text = result?.ToString() ?? "";
                }
                catch (Exception ex)
                {
                    MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
                }
            }
        }
        #endregion
        #region Поиск
        private async void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            string search = textBoxSearch.Text.Trim();
            dataGridViewKnowledge.Rows.Clear();
            SQLiteDataReader sqlReader = null;
            string sql = string.IsNullOrEmpty(search)
                ? $"SELECT * FROM [{Table_knowledge.main}] ORDER BY [{Table_knowledge.id}] DESC"
                : $"SELECT * FROM [{Table_knowledge.main}] WHERE [{Table_knowledge.title}] LIKE @s OR [{Table_knowledge.category}] LIKE @s OR [{Table_knowledge.tags}] LIKE @s OR [{Table_knowledge.content}] LIKE @s ORDER BY [{Table_knowledge.id}] DESC";
            SQLiteCommand command = new SQLiteCommand(sql, DB);
            if (!string.IsNullOrEmpty(search))
                _ = command.Parameters.AddWithValue("s", "%" + search + "%");
            List<string[]> data = new List<string[]>();
            try
            {
                sqlReader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                while (await sqlReader.ReadAsync())
                {
                    data.Add(new string[5]);
                    data[data.Count - 1][0] = Convert.ToString($"{sqlReader[$"{Table_knowledge.id}"]}");
                    data[data.Count - 1][1] = Convert.ToString($"{sqlReader[$"{Table_knowledge.title}"]}");
                    data[data.Count - 1][2] = Convert.ToString($"{sqlReader[$"{Table_knowledge.category}"]}");
                    data[data.Count - 1][3] = Convert.ToString($"{sqlReader[$"{Table_knowledge.tags}"]}");
                    data[data.Count - 1][4] = Convert.ToString($"{sqlReader[$"{Table_knowledge.dateCreated}"]}");
                }
                foreach (string[] s in data)
                    _ = dataGridViewKnowledge.Rows.Add(s);
                dataGridViewKnowledge.ClearSelection();
                if (dataGridViewKnowledge.Columns.Count > 0)
                    dataGridViewKnowledge.Columns[0].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
            finally
            {
                sqlReader?.Close();
            }
        }
        #endregion
    }
}
