#!/usr/bin/env python3
"""Заполнение базы тестовыми данными."""

import datetime
import random
import sqlite3
import sys

DB_PATH = "app.db"


def seed(db_path: str = DB_PATH) -> None:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.executescript(
        """
        DROP TABLE IF EXISTS orders;
        DROP TABLE IF EXISTS items;

        CREATE TABLE items (
            id    INTEGER PRIMARY KEY,
            name  TEXT NOT NULL,
            price REAL NOT NULL CHECK (price >= 0),
            qty   INTEGER NOT NULL CHECK (qty >= 0)
        );

        CREATE TABLE orders (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id    INTEGER NOT NULL,
            qty        INTEGER NOT NULL CHECK (qty > 0),
            created_at TEXT NOT NULL,
            FOREIGN KEY (item_id) REFERENCES items(id)
        );

        CREATE INDEX idx_orders_item_id ON orders(item_id);
        CREATE INDEX idx_orders_created_at ON orders(created_at);
        """
    )

    items = [
        (f"Товар {i}", round(random.uniform(10, 1000), 2), random.randint(0, 500))
        for i in range(1, 501)
    ]
    cur.executemany(
        "INSERT INTO items (name, price, qty) VALUES (?, ?, ?)", items
    )

    start = datetime.date(2024, 1, 1)
    orders = []
    for _ in range(5000):
        d = start + datetime.timedelta(days=random.randint(0, 700))
        orders.append(
            (random.randint(1, 500), random.randint(1, 10), d.isoformat())
        )
    cur.executemany(
        "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
        orders,
    )

    conn.commit()
    conn.close()
    print(f"seeded: 500 items, 5000 orders → {db_path}")


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DB_PATH
    seed(path)
