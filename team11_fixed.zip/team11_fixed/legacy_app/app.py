import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

# Секрет берём из окружения; в dev можно задать значение по умолчанию
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me-in-production")

DB_PATH = os.environ.get("DB_PATH", "app.db")


@contextmanager
def get_db():
    """Контекстный менеджер для безопасной работы с SQLite."""
    conn = sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES)
    conn.row_factory = sqlite3.Row
    # Включаем WAL — лучше конкурентный доступ и производительность
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db_if_needed() -> None:
    """Создаёт таблицы и индексы, если их ещё нет (на случай запуска без seed)."""
    with get_db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS items (
                id    INTEGER PRIMARY KEY,
                name  TEXT NOT NULL,
                price REAL NOT NULL CHECK (price >= 0),
                qty   INTEGER NOT NULL CHECK (qty >= 0)
            );
            CREATE TABLE IF NOT EXISTS orders (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id    INTEGER NOT NULL,
                qty        INTEGER NOT NULL CHECK (qty > 0),
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (item_id) REFERENCES items(id)
            );
            CREATE INDEX IF NOT EXISTS idx_orders_item_id ON orders(item_id);
            CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
            """
        )


@app.route("/")
def index():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, name, price, qty FROM items ORDER BY id"
        ).fetchall()
        items = [dict(r) for r in rows]
    return render_template("index.html", items=items)


@app.route("/api/items")
def api_items():
    """Возвращает товары вместе с количеством заказов (один запрос, без N+1)."""
    with get_db() as conn:
        rows = conn.execute(
            """
            SELECT
                i.id,
                i.name,
                i.price,
                i.qty,
                COUNT(o.id) AS orders
            FROM items i
            LEFT JOIN orders o ON o.item_id = i.id
            GROUP BY i.id, i.name, i.price, i.qty
            ORDER BY i.id
            """
        ).fetchall()
        result = [dict(r) for r in rows]
    return jsonify(result)


@app.route("/api/orders", methods=["POST"])
def create_order():
    data = request.get_json(silent=True)
    if not data or not isinstance(data, dict):
        return jsonify({"ok": False, "error": "JSON body required"}), 400

    try:
        item_id = int(data["item_id"])
        qty = int(data["qty"])
    except (KeyError, TypeError, ValueError):
        return jsonify({"ok": False, "error": "item_id and qty must be integers"}), 400

    if qty <= 0:
        return jsonify({"ok": False, "error": "qty must be positive"}), 400

    try:
        with get_db() as conn:
            # Проверяем существование товара
            item = conn.execute(
                "SELECT id, qty FROM items WHERE id = ?", (item_id,)
            ).fetchone()
            if item is None:
                return jsonify({"ok": False, "error": "item not found"}), 404

            # Параметризованный запрос — защита от SQL-инъекций
            cur = conn.execute(
                "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
                (item_id, qty, datetime.utcnow().isoformat(timespec="seconds")),
            )
            order_id = cur.lastrowid
        return jsonify({"ok": True, "order_id": order_id}), 201
    except sqlite3.Error as e:
        return jsonify({"ok": False, "error": "database error"}), 500


@app.route("/api/report")
def report():
    frm = request.args.get("from", "2000-01-01")
    to = request.args.get("to", "2100-01-01")

    # Простая валидация формата даты (YYYY-MM-DD)
    for label, value in (("from", frm), ("to", to)):
        try:
            datetime.strptime(value, "%Y-%m-%d")
        except ValueError:
            return jsonify({"ok": False, "error": f"invalid {label} date, use YYYY-MM-DD"}), 400

    with get_db() as conn:
        # Параметризованный запрос + использование индекса по created_at
        rows = conn.execute(
            """
            SELECT item_id, qty
            FROM orders
            WHERE created_at BETWEEN ? AND ?
            """,
            (frm, to),
        ).fetchall()

    total = 0
    by_item: Dict[int, int] = {}
    for row in rows:
        total += row["qty"]
        by_item[row["item_id"]] = by_item.get(row["item_id"], 0) + row["qty"]

    return jsonify({"total": total, "by_item": by_item})


if __name__ == "__main__":
    import sys

    init_db_if_needed()

    port = 5001
    if "--port" in sys.argv:
        try:
            port = int(sys.argv[sys.argv.index("--port") + 1])
        except (IndexError, ValueError):
            print("Usage: python app.py [--port PORT]")
            sys.exit(1)

    # debug=False по умолчанию; для разработки можно задать FLASK_DEBUG=1
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="127.0.0.1", port=port, debug=debug, threaded=True)
