namespace SupportDesk.forms
{
    partial class KanbanForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblUpdated = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.panelMove = new System.Windows.Forms.Panel();
            this.btnToDone = new System.Windows.Forms.Button();
            this.btnToWork = new System.Windows.Forms.Button();
            this.btnToNew = new System.Windows.Forms.Button();
            this.lblMove = new System.Windows.Forms.Label();
            this.panelColNew = new System.Windows.Forms.Panel();
            this.listNew = new System.Windows.Forms.ListView();
            this.colNewTitle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNewSub = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelHeadNew = new System.Windows.Forms.Panel();
            this.lblCountNew = new System.Windows.Forms.Label();
            this.lblHeadNew = new System.Windows.Forms.Label();
            this.panelColWork = new System.Windows.Forms.Panel();
            this.listWork = new System.Windows.Forms.ListView();
            this.colWorkTitle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colWorkSub = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelHeadWork = new System.Windows.Forms.Panel();
            this.lblCountWork = new System.Windows.Forms.Label();
            this.lblHeadWork = new System.Windows.Forms.Label();
            this.panelColDone = new System.Windows.Forms.Panel();
            this.listDone = new System.Windows.Forms.ListView();
            this.colDoneTitle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDoneSub = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelHeadDone = new System.Windows.Forms.Panel();
            this.lblCountDone = new System.Windows.Forms.Label();
            this.lblHeadDone = new System.Windows.Forms.Label();
            this.panelHeader.SuspendLayout();
            this.panelMove.SuspendLayout();
            this.panelColNew.SuspendLayout();
            this.panelHeadNew.SuspendLayout();
            this.panelColWork.SuspendLayout();
            this.panelHeadWork.SuspendLayout();
            this.panelColDone.SuspendLayout();
            this.panelHeadDone.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Controls.Add(this.btnClose);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(1100, 44);
            this.panelHeader.TabIndex = 0;
            this.panelHeader.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelHeader_MouseDown);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 12.5F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(14, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(280, 23);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "📋  Канбан-доска заявок";
            this.lblTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelHeader_MouseDown);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(43)))));
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1052, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(40, 32);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "✕";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblUpdated
            // 
            this.lblUpdated.AutoSize = true;
            this.lblUpdated.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUpdated.ForeColor = System.Drawing.Color.Gray;
            this.lblUpdated.Location = new System.Drawing.Point(12, 56);
            this.lblUpdated.Name = "lblUpdated";
            this.lblUpdated.Size = new System.Drawing.Size(120, 15);
            this.lblUpdated.TabIndex = 1;
            this.lblUpdated.Text = "Обновлено: —";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnRefresh.FlatAppearance.BorderSize = 0;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Location = new System.Drawing.Point(860, 50);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(110, 32);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(68)))), ((int)(((byte)(173)))));
            this.btnOpen.FlatAppearance.BorderSize = 0;
            this.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpen.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnOpen.ForeColor = System.Drawing.Color.White;
            this.btnOpen.Location = new System.Drawing.Point(980, 50);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(110, 32);
            this.btnOpen.TabIndex = 3;
            this.btnOpen.Text = "Открыть";
            this.btnOpen.UseVisualStyleBackColor = false;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // panelMove
            // 
            this.panelMove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.panelMove.Controls.Add(this.btnToDone);
            this.panelMove.Controls.Add(this.btnToWork);
            this.panelMove.Controls.Add(this.btnToNew);
            this.panelMove.Controls.Add(this.lblMove);
            this.panelMove.Location = new System.Drawing.Point(12, 90);
            this.panelMove.Name = "panelMove";
            this.panelMove.Size = new System.Drawing.Size(1076, 48);
            this.panelMove.TabIndex = 4;
            // 
            // btnToDone
            // 
            this.btnToDone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnToDone.FlatAppearance.BorderSize = 0;
            this.btnToDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToDone.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnToDone.ForeColor = System.Drawing.Color.White;
            this.btnToDone.Location = new System.Drawing.Point(520, 8);
            this.btnToDone.Name = "btnToDone";
            this.btnToDone.Size = new System.Drawing.Size(160, 32);
            this.btnToDone.TabIndex = 3;
            this.btnToDone.Text = "→  Выполнена";
            this.btnToDone.UseVisualStyleBackColor = false;
            this.btnToDone.Click += new System.EventHandler(this.btnToDone_Click);
            // 
            // btnToWork
            // 
            this.btnToWork.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(126)))), ((int)(((byte)(34)))));
            this.btnToWork.FlatAppearance.BorderSize = 0;
            this.btnToWork.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToWork.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnToWork.ForeColor = System.Drawing.Color.White;
            this.btnToWork.Location = new System.Drawing.Point(340, 8);
            this.btnToWork.Name = "btnToWork";
            this.btnToWork.Size = new System.Drawing.Size(160, 32);
            this.btnToWork.TabIndex = 2;
            this.btnToWork.Text = "→  В работе";
            this.btnToWork.UseVisualStyleBackColor = false;
            this.btnToWork.Click += new System.EventHandler(this.btnToWork_Click);
            // 
            // btnToNew
            // 
            this.btnToNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnToNew.FlatAppearance.BorderSize = 0;
            this.btnToNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToNew.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnToNew.ForeColor = System.Drawing.Color.White;
            this.btnToNew.Location = new System.Drawing.Point(160, 8);
            this.btnToNew.Name = "btnToNew";
            this.btnToNew.Size = new System.Drawing.Size(160, 32);
            this.btnToNew.TabIndex = 1;
            this.btnToNew.Text = "→  Новая";
            this.btnToNew.UseVisualStyleBackColor = false;
            this.btnToNew.Click += new System.EventHandler(this.btnToNew_Click);
            // 
            // lblMove
            // 
            this.lblMove.AutoSize = true;
            this.lblMove.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblMove.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lblMove.Location = new System.Drawing.Point(12, 14);
            this.lblMove.Name = "lblMove";
            this.lblMove.Size = new System.Drawing.Size(140, 17);
            this.lblMove.TabIndex = 0;
            this.lblMove.Text = "Переместить в:";
            // 
            // panelColNew
            // 
            this.panelColNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.panelColNew.Controls.Add(this.listNew);
            this.panelColNew.Controls.Add(this.panelHeadNew);
            this.panelColNew.Location = new System.Drawing.Point(12, 150);
            this.panelColNew.Name = "panelColNew";
            this.panelColNew.Size = new System.Drawing.Size(350, 480);
            this.panelColNew.TabIndex = 5;
            // 
            // listNew
            // 
            this.listNew.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listNew.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNewTitle,
            this.colNewSub});
            this.listNew.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listNew.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.listNew.FullRowSelect = true;
            this.listNew.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listNew.HideSelection = false;
            this.listNew.Location = new System.Drawing.Point(0, 40);
            this.listNew.MultiSelect = false;
            this.listNew.Name = "listNew";
            this.listNew.ShowItemToolTips = true;
            this.listNew.Size = new System.Drawing.Size(350, 440);
            this.listNew.TabIndex = 1;
            this.listNew.UseCompatibleStateImageBehavior = false;
            this.listNew.View = System.Windows.Forms.View.Details;
            this.listNew.SelectedIndexChanged += new System.EventHandler(this.listNew_SelectedIndexChanged);
            this.listNew.DoubleClick += new System.EventHandler(this.list_DoubleClick);
            // 
            // colNewTitle
            // 
            this.colNewTitle.Text = "Заявка";
            this.colNewTitle.Width = 340;
            // 
            // colNewSub
            // 
            this.colNewSub.Text = "";
            this.colNewSub.Width = 0;
            // 
            // panelHeadNew
            // 
            this.panelHeadNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.panelHeadNew.Controls.Add(this.lblCountNew);
            this.panelHeadNew.Controls.Add(this.lblHeadNew);
            this.panelHeadNew.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeadNew.Location = new System.Drawing.Point(0, 0);
            this.panelHeadNew.Name = "panelHeadNew";
            this.panelHeadNew.Size = new System.Drawing.Size(350, 40);
            this.panelHeadNew.TabIndex = 0;
            // 
            // lblCountNew
            // 
            this.lblCountNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountNew.BackColor = System.Drawing.Color.White;
            this.lblCountNew.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblCountNew.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.lblCountNew.Location = new System.Drawing.Point(290, 8);
            this.lblCountNew.Name = "lblCountNew";
            this.lblCountNew.Size = new System.Drawing.Size(48, 24);
            this.lblCountNew.TabIndex = 1;
            this.lblCountNew.Text = "0";
            this.lblCountNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeadNew
            // 
            this.lblHeadNew.AutoSize = true;
            this.lblHeadNew.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblHeadNew.ForeColor = System.Drawing.Color.White;
            this.lblHeadNew.Location = new System.Drawing.Point(12, 9);
            this.lblHeadNew.Name = "lblHeadNew";
            this.lblHeadNew.Size = new System.Drawing.Size(60, 20);
            this.lblHeadNew.TabIndex = 0;
            this.lblHeadNew.Text = "Новая";
            // 
            // panelColWork
            // 
            this.panelColWork.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.panelColWork.Controls.Add(this.listWork);
            this.panelColWork.Controls.Add(this.panelHeadWork);
            this.panelColWork.Location = new System.Drawing.Point(375, 150);
            this.panelColWork.Name = "panelColWork";
            this.panelColWork.Size = new System.Drawing.Size(350, 480);
            this.panelColWork.TabIndex = 6;
            // 
            // listWork
            // 
            this.listWork.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listWork.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colWorkTitle,
            this.colWorkSub});
            this.listWork.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listWork.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.listWork.FullRowSelect = true;
            this.listWork.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listWork.HideSelection = false;
            this.listWork.Location = new System.Drawing.Point(0, 40);
            this.listWork.MultiSelect = false;
            this.listWork.Name = "listWork";
            this.listWork.ShowItemToolTips = true;
            this.listWork.Size = new System.Drawing.Size(350, 440);
            this.listWork.TabIndex = 1;
            this.listWork.UseCompatibleStateImageBehavior = false;
            this.listWork.View = System.Windows.Forms.View.Details;
            this.listWork.SelectedIndexChanged += new System.EventHandler(this.listWork_SelectedIndexChanged);
            this.listWork.DoubleClick += new System.EventHandler(this.list_DoubleClick);
            // 
            // colWorkTitle
            // 
            this.colWorkTitle.Text = "Заявка";
            this.colWorkTitle.Width = 340;
            // 
            // colWorkSub
            // 
            this.colWorkSub.Width = 0;
            // 
            // panelHeadWork
            // 
            this.panelHeadWork.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(126)))), ((int)(((byte)(34)))));
            this.panelHeadWork.Controls.Add(this.lblCountWork);
            this.panelHeadWork.Controls.Add(this.lblHeadWork);
            this.panelHeadWork.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeadWork.Location = new System.Drawing.Point(0, 0);
            this.panelHeadWork.Name = "panelHeadWork";
            this.panelHeadWork.Size = new System.Drawing.Size(350, 40);
            this.panelHeadWork.TabIndex = 0;
            // 
            // lblCountWork
            // 
            this.lblCountWork.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountWork.BackColor = System.Drawing.Color.White;
            this.lblCountWork.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblCountWork.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(126)))), ((int)(((byte)(34)))));
            this.lblCountWork.Location = new System.Drawing.Point(290, 8);
            this.lblCountWork.Name = "lblCountWork";
            this.lblCountWork.Size = new System.Drawing.Size(48, 24);
            this.lblCountWork.TabIndex = 1;
            this.lblCountWork.Text = "0";
            this.lblCountWork.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeadWork
            // 
            this.lblHeadWork.AutoSize = true;
            this.lblHeadWork.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblHeadWork.ForeColor = System.Drawing.Color.White;
            this.lblHeadWork.Location = new System.Drawing.Point(12, 9);
            this.lblHeadWork.Name = "lblHeadWork";
            this.lblHeadWork.Size = new System.Drawing.Size(80, 20);
            this.lblHeadWork.TabIndex = 0;
            this.lblHeadWork.Text = "В работе";
            // 
            // panelColDone
            // 
            this.panelColDone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.panelColDone.Controls.Add(this.listDone);
            this.panelColDone.Controls.Add(this.panelHeadDone);
            this.panelColDone.Location = new System.Drawing.Point(738, 150);
            this.panelColDone.Name = "panelColDone";
            this.panelColDone.Size = new System.Drawing.Size(350, 480);
            this.panelColDone.TabIndex = 7;
            // 
            // listDone
            // 
            this.listDone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listDone.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colDoneTitle,
            this.colDoneSub});
            this.listDone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listDone.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.listDone.FullRowSelect = true;
            this.listDone.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listDone.HideSelection = false;
            this.listDone.Location = new System.Drawing.Point(0, 40);
            this.listDone.MultiSelect = false;
            this.listDone.Name = "listDone";
            this.listDone.ShowItemToolTips = true;
            this.listDone.Size = new System.Drawing.Size(350, 440);
            this.listDone.TabIndex = 1;
            this.listDone.UseCompatibleStateImageBehavior = false;
            this.listDone.View = System.Windows.Forms.View.Details;
            this.listDone.SelectedIndexChanged += new System.EventHandler(this.listDone_SelectedIndexChanged);
            this.listDone.DoubleClick += new System.EventHandler(this.list_DoubleClick);
            // 
            // colDoneTitle
            // 
            this.colDoneTitle.Text = "Заявка";
            this.colDoneTitle.Width = 340;
            // 
            // colDoneSub
            // 
            this.colDoneSub.Width = 0;
            // 
            // panelHeadDone
            // 
            this.panelHeadDone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.panelHeadDone.Controls.Add(this.lblCountDone);
            this.panelHeadDone.Controls.Add(this.lblHeadDone);
            this.panelHeadDone.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeadDone.Location = new System.Drawing.Point(0, 0);
            this.panelHeadDone.Name = "panelHeadDone";
            this.panelHeadDone.Size = new System.Drawing.Size(350, 40);
            this.panelHeadDone.TabIndex = 0;
            // 
            // lblCountDone
            // 
            this.lblCountDone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountDone.BackColor = System.Drawing.Color.White;
            this.lblCountDone.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblCountDone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.lblCountDone.Location = new System.Drawing.Point(290, 8);
            this.lblCountDone.Name = "lblCountDone";
            this.lblCountDone.Size = new System.Drawing.Size(48, 24);
            this.lblCountDone.TabIndex = 1;
            this.lblCountDone.Text = "0";
            this.lblCountDone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeadDone
            // 
            this.lblHeadDone.AutoSize = true;
            this.lblHeadDone.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblHeadDone.ForeColor = System.Drawing.Color.White;
            this.lblHeadDone.Location = new System.Drawing.Point(12, 9);
            this.lblHeadDone.Name = "lblHeadDone";
            this.lblHeadDone.Size = new System.Drawing.Size(90, 20);
            this.lblHeadDone.TabIndex = 0;
            this.lblHeadDone.Text = "Выполнена";
            // 
            // KanbanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(246)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1100, 650);
            this.Controls.Add(this.panelColDone);
            this.Controls.Add(this.panelColWork);
            this.Controls.Add(this.panelColNew);
            this.Controls.Add(this.panelMove);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblUpdated);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "KanbanForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Канбан-доска SupportDesk";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.KanbanForm_FormClosing);
            this.Load += new System.EventHandler(this.KanbanForm_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelMove.ResumeLayout(false);
            this.panelMove.PerformLayout();
            this.panelColNew.ResumeLayout(false);
            this.panelHeadNew.ResumeLayout(false);
            this.panelHeadNew.PerformLayout();
            this.panelColWork.ResumeLayout(false);
            this.panelHeadWork.ResumeLayout(false);
            this.panelHeadWork.PerformLayout();
            this.panelColDone.ResumeLayout(false);
            this.panelHeadDone.ResumeLayout(false);
            this.panelHeadDone.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblUpdated;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Panel panelMove;
        private System.Windows.Forms.Button btnToDone;
        private System.Windows.Forms.Button btnToWork;
        private System.Windows.Forms.Button btnToNew;
        private System.Windows.Forms.Label lblMove;
        private System.Windows.Forms.Panel panelColNew;
        private System.Windows.Forms.ListView listNew;
        private System.Windows.Forms.ColumnHeader colNewTitle;
        private System.Windows.Forms.ColumnHeader colNewSub;
        private System.Windows.Forms.Panel panelHeadNew;
        private System.Windows.Forms.Label lblCountNew;
        private System.Windows.Forms.Label lblHeadNew;
        private System.Windows.Forms.Panel panelColWork;
        private System.Windows.Forms.ListView listWork;
        private System.Windows.Forms.ColumnHeader colWorkTitle;
        private System.Windows.Forms.ColumnHeader colWorkSub;
        private System.Windows.Forms.Panel panelHeadWork;
        private System.Windows.Forms.Label lblCountWork;
        private System.Windows.Forms.Label lblHeadWork;
        private System.Windows.Forms.Panel panelColDone;
        private System.Windows.Forms.ListView listDone;
        private System.Windows.Forms.ColumnHeader colDoneTitle;
        private System.Windows.Forms.ColumnHeader colDoneSub;
        private System.Windows.Forms.Panel panelHeadDone;
        private System.Windows.Forms.Label lblCountDone;
        private System.Windows.Forms.Label lblHeadDone;
    }
}
