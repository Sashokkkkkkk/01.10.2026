namespace SupportDesk.forms
{
    partial class KanbanForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblUpdated = new System.Windows.Forms.Label();
            this.lblHint = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.panelToolbar = new System.Windows.Forms.Panel();
            this.lblMove = new System.Windows.Forms.Label();
            this.btnToNew = new System.Windows.Forms.Button();
            this.btnToWork = new System.Windows.Forms.Button();
            this.btnToDone = new System.Windows.Forms.Button();
            this.panelColNew = new System.Windows.Forms.Panel();
            this.listNew = new System.Windows.Forms.ListView();
            this.colNew1 = new System.Windows.Forms.ColumnHeader();
            this.colNew2 = new System.Windows.Forms.ColumnHeader();
            this.colNew3 = new System.Windows.Forms.ColumnHeader();
            this.panelHeadNew = new System.Windows.Forms.Panel();
            this.lblCountNew = new System.Windows.Forms.Label();
            this.lblHeadNew = new System.Windows.Forms.Label();
            this.panelColWork = new System.Windows.Forms.Panel();
            this.listWork = new System.Windows.Forms.ListView();
            this.colWork1 = new System.Windows.Forms.ColumnHeader();
            this.colWork2 = new System.Windows.Forms.ColumnHeader();
            this.colWork3 = new System.Windows.Forms.ColumnHeader();
            this.panelHeadWork = new System.Windows.Forms.Panel();
            this.lblCountWork = new System.Windows.Forms.Label();
            this.lblHeadWork = new System.Windows.Forms.Label();
            this.panelColDone = new System.Windows.Forms.Panel();
            this.listDone = new System.Windows.Forms.ListView();
            this.colDone1 = new System.Windows.Forms.ColumnHeader();
            this.colDone2 = new System.Windows.Forms.ColumnHeader();
            this.colDone3 = new System.Windows.Forms.ColumnHeader();
            this.panelHeadDone = new System.Windows.Forms.Panel();
            this.lblCountDone = new System.Windows.Forms.Label();
            this.lblHeadDone = new System.Windows.Forms.Label();
            this.panelHeader.SuspendLayout();
            this.panelToolbar.SuspendLayout();
            this.panelColNew.SuspendLayout();
            this.panelHeadNew.SuspendLayout();
            this.panelColWork.SuspendLayout();
            this.panelHeadWork.SuspendLayout();
            this.panelColDone.SuspendLayout();
            this.panelHeadDone.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(32, 40, 55);
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Controls.Add(this.btnClose);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(1080, 48);
            this.panelHeader.TabIndex = 0;
            this.panelHeader.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelHeader_MouseDown);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(16, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(200, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Канбан-доска заявок";
            this.lblTitle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelHeader_MouseDown);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(192, 57, 43);
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1030, 8);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(40, 32);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblUpdated
            // 
            this.lblUpdated.AutoSize = true;
            this.lblUpdated.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUpdated.ForeColor = System.Drawing.Color.FromArgb(120, 120, 120);
            this.lblUpdated.Location = new System.Drawing.Point(16, 58);
            this.lblUpdated.Name = "lblUpdated";
            this.lblUpdated.Size = new System.Drawing.Size(100, 15);
            this.lblUpdated.TabIndex = 1;
            this.lblUpdated.Text = "Обновлено: —";
            // 
            // lblHint
            // 
            this.lblHint.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHint.ForeColor = System.Drawing.Color.FromArgb(90, 90, 90);
            this.lblHint.Location = new System.Drawing.Point(200, 56);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(620, 20);
            this.lblHint.TabIndex = 2;
            this.lblHint.Text = "";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefresh.FlatAppearance.BorderSize = 0;
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Location = new System.Drawing.Point(840, 52);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(110, 32);
            this.btnRefresh.TabIndex = 3;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOpen.BackColor = System.Drawing.Color.FromArgb(142, 68, 173);
            this.btnOpen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOpen.FlatAppearance.BorderSize = 0;
            this.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpen.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnOpen.ForeColor = System.Drawing.Color.White;
            this.btnOpen.Location = new System.Drawing.Point(960, 52);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(110, 32);
            this.btnOpen.TabIndex = 4;
            this.btnOpen.Text = "Открыть";
            this.btnOpen.UseVisualStyleBackColor = false;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // panelToolbar
            // 
            this.panelToolbar.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.panelToolbar.Controls.Add(this.lblMove);
            this.panelToolbar.Controls.Add(this.btnToNew);
            this.panelToolbar.Controls.Add(this.btnToWork);
            this.panelToolbar.Controls.Add(this.btnToDone);
            this.panelToolbar.Location = new System.Drawing.Point(16, 96);
            this.panelToolbar.Name = "panelToolbar";
            this.panelToolbar.Size = new System.Drawing.Size(1048, 52);
            this.panelToolbar.TabIndex = 5;
            // 
            // lblMove
            // 
            this.lblMove.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblMove.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.lblMove.Location = new System.Drawing.Point(12, 14);
            this.lblMove.Name = "lblMove";
            this.lblMove.Size = new System.Drawing.Size(130, 24);
            this.lblMove.TabIndex = 0;
            this.lblMove.Text = "Переместить в:";
            this.lblMove.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnToNew
            // 
            this.btnToNew.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.btnToNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnToNew.FlatAppearance.BorderSize = 0;
            this.btnToNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToNew.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnToNew.ForeColor = System.Drawing.Color.White;
            this.btnToNew.Location = new System.Drawing.Point(150, 10);
            this.btnToNew.Name = "btnToNew";
            this.btnToNew.Size = new System.Drawing.Size(160, 32);
            this.btnToNew.TabIndex = 1;
            this.btnToNew.Text = "→  Новая";
            this.btnToNew.UseVisualStyleBackColor = false;
            this.btnToNew.Click += new System.EventHandler(this.btnToNew_Click);
            // 
            // btnToWork
            // 
            this.btnToWork.BackColor = System.Drawing.Color.FromArgb(230, 126, 34);
            this.btnToWork.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnToWork.FlatAppearance.BorderSize = 0;
            this.btnToWork.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToWork.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnToWork.ForeColor = System.Drawing.Color.White;
            this.btnToWork.Location = new System.Drawing.Point(330, 10);
            this.btnToWork.Name = "btnToWork";
            this.btnToWork.Size = new System.Drawing.Size(160, 32);
            this.btnToWork.TabIndex = 2;
            this.btnToWork.Text = "→  В работе";
            this.btnToWork.UseVisualStyleBackColor = false;
            this.btnToWork.Click += new System.EventHandler(this.btnToWork_Click);
            // 
            // btnToDone
            // 
            this.btnToDone.BackColor = System.Drawing.Color.FromArgb(39, 174, 96);
            this.btnToDone.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnToDone.FlatAppearance.BorderSize = 0;
            this.btnToDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnToDone.Font = new System.Drawing.Font("Segoe UI Semibold", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnToDone.ForeColor = System.Drawing.Color.White;
            this.btnToDone.Location = new System.Drawing.Point(510, 10);
            this.btnToDone.Name = "btnToDone";
            this.btnToDone.Size = new System.Drawing.Size(160, 32);
            this.btnToDone.TabIndex = 3;
            this.btnToDone.Text = "→  Выполнена";
            this.btnToDone.UseVisualStyleBackColor = false;
            this.btnToDone.Click += new System.EventHandler(this.btnToDone_Click);
            // 
            // panelColNew
            // 
            this.panelColNew.BackColor = System.Drawing.Color.White;
            this.panelColNew.Controls.Add(this.listNew);
            this.panelColNew.Controls.Add(this.panelHeadNew);
            this.panelColNew.Location = new System.Drawing.Point(16, 164);
            this.panelColNew.Name = "panelColNew";
            this.panelColNew.Padding = new System.Windows.Forms.Padding(1);
            this.panelColNew.Size = new System.Drawing.Size(340, 470);
            this.panelColNew.TabIndex = 6;
            // 
            // listNew
            // 
            this.listNew.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listNew.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { this.colNew1, this.colNew2, this.colNew3 });
            this.listNew.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listNew.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.listNew.FullRowSelect = true;
            this.listNew.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listNew.HideSelection = false;
            this.listNew.Location = new System.Drawing.Point(1, 42);
            this.listNew.MultiSelect = false;
            this.listNew.Name = "listNew";
            this.listNew.ShowItemToolTips = true;
            this.listNew.Size = new System.Drawing.Size(338, 427);
            this.listNew.TabIndex = 1;
            this.listNew.UseCompatibleStateImageBehavior = false;
            this.listNew.View = System.Windows.Forms.View.Details;
            this.listNew.SelectedIndexChanged += new System.EventHandler(this.listNew_SelectedIndexChanged);
            this.listNew.DoubleClick += new System.EventHandler(this.list_DoubleClick);
            // 
            // colNew1
            // 
            this.colNew1.Width = 320;
            // 
            // colNew2
            // 
            this.colNew2.Width = 0;
            // 
            // colNew3
            // 
            this.colNew3.Width = 0;
            // 
            // panelHeadNew
            // 
            this.panelHeadNew.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.panelHeadNew.Controls.Add(this.lblCountNew);
            this.panelHeadNew.Controls.Add(this.lblHeadNew);
            this.panelHeadNew.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeadNew.Location = new System.Drawing.Point(1, 1);
            this.panelHeadNew.Name = "panelHeadNew";
            this.panelHeadNew.Size = new System.Drawing.Size(338, 41);
            this.panelHeadNew.TabIndex = 0;
            // 
            // lblCountNew
            // 
            this.lblCountNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountNew.BackColor = System.Drawing.Color.White;
            this.lblCountNew.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblCountNew.ForeColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.lblCountNew.Location = new System.Drawing.Point(278, 8);
            this.lblCountNew.Name = "lblCountNew";
            this.lblCountNew.Size = new System.Drawing.Size(48, 24);
            this.lblCountNew.TabIndex = 1;
            this.lblCountNew.Text = "0";
            this.lblCountNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeadNew
            // 
            this.lblHeadNew.AutoSize = true;
            this.lblHeadNew.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblHeadNew.ForeColor = System.Drawing.Color.White;
            this.lblHeadNew.Location = new System.Drawing.Point(12, 10);
            this.lblHeadNew.Name = "lblHeadNew";
            this.lblHeadNew.Size = new System.Drawing.Size(60, 20);
            this.lblHeadNew.TabIndex = 0;
            this.lblHeadNew.Text = "Новая";
            // 
            // panelColWork
            // 
            this.panelColWork.BackColor = System.Drawing.Color.White;
            this.panelColWork.Controls.Add(this.listWork);
            this.panelColWork.Controls.Add(this.panelHeadWork);
            this.panelColWork.Location = new System.Drawing.Point(370, 164);
            this.panelColWork.Name = "panelColWork";
            this.panelColWork.Padding = new System.Windows.Forms.Padding(1);
            this.panelColWork.Size = new System.Drawing.Size(340, 470);
            this.panelColWork.TabIndex = 7;
            // 
            // listWork
            // 
            this.listWork.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listWork.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { this.colWork1, this.colWork2, this.colWork3 });
            this.listWork.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listWork.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.listWork.FullRowSelect = true;
            this.listWork.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listWork.HideSelection = false;
            this.listWork.Location = new System.Drawing.Point(1, 42);
            this.listWork.MultiSelect = false;
            this.listWork.Name = "listWork";
            this.listWork.ShowItemToolTips = true;
            this.listWork.Size = new System.Drawing.Size(338, 427);
            this.listWork.TabIndex = 1;
            this.listWork.UseCompatibleStateImageBehavior = false;
            this.listWork.View = System.Windows.Forms.View.Details;
            this.listWork.SelectedIndexChanged += new System.EventHandler(this.listWork_SelectedIndexChanged);
            this.listWork.DoubleClick += new System.EventHandler(this.list_DoubleClick);
            // 
            // colWork1
            // 
            this.colWork1.Width = 320;
            // 
            // colWork2
            // 
            this.colWork2.Width = 0;
            // 
            // colWork3
            // 
            this.colWork3.Width = 0;
            // 
            // panelHeadWork
            // 
            this.panelHeadWork.BackColor = System.Drawing.Color.FromArgb(230, 126, 34);
            this.panelHeadWork.Controls.Add(this.lblCountWork);
            this.panelHeadWork.Controls.Add(this.lblHeadWork);
            this.panelHeadWork.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeadWork.Location = new System.Drawing.Point(1, 1);
            this.panelHeadWork.Name = "panelHeadWork";
            this.panelHeadWork.Size = new System.Drawing.Size(338, 41);
            this.panelHeadWork.TabIndex = 0;
            // 
            // lblCountWork
            // 
            this.lblCountWork.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountWork.BackColor = System.Drawing.Color.White;
            this.lblCountWork.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblCountWork.ForeColor = System.Drawing.Color.FromArgb(230, 126, 34);
            this.lblCountWork.Location = new System.Drawing.Point(278, 8);
            this.lblCountWork.Name = "lblCountWork";
            this.lblCountWork.Size = new System.Drawing.Size(48, 24);
            this.lblCountWork.TabIndex = 1;
            this.lblCountWork.Text = "0";
            this.lblCountWork.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeadWork
            // 
            this.lblHeadWork.AutoSize = true;
            this.lblHeadWork.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblHeadWork.ForeColor = System.Drawing.Color.White;
            this.lblHeadWork.Location = new System.Drawing.Point(12, 10);
            this.lblHeadWork.Name = "lblHeadWork";
            this.lblHeadWork.Size = new System.Drawing.Size(80, 20);
            this.lblHeadWork.TabIndex = 0;
            this.lblHeadWork.Text = "В работе";
            // 
            // panelColDone
            // 
            this.panelColDone.BackColor = System.Drawing.Color.White;
            this.panelColDone.Controls.Add(this.listDone);
            this.panelColDone.Controls.Add(this.panelHeadDone);
            this.panelColDone.Location = new System.Drawing.Point(724, 164);
            this.panelColDone.Name = "panelColDone";
            this.panelColDone.Padding = new System.Windows.Forms.Padding(1);
            this.panelColDone.Size = new System.Drawing.Size(340, 470);
            this.panelColDone.TabIndex = 8;
            // 
            // listDone
            // 
            this.listDone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listDone.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { this.colDone1, this.colDone2, this.colDone3 });
            this.listDone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listDone.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.listDone.FullRowSelect = true;
            this.listDone.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.listDone.HideSelection = false;
            this.listDone.Location = new System.Drawing.Point(1, 42);
            this.listDone.MultiSelect = false;
            this.listDone.Name = "listDone";
            this.listDone.ShowItemToolTips = true;
            this.listDone.Size = new System.Drawing.Size(338, 427);
            this.listDone.TabIndex = 1;
            this.listDone.UseCompatibleStateImageBehavior = false;
            this.listDone.View = System.Windows.Forms.View.Details;
            this.listDone.SelectedIndexChanged += new System.EventHandler(this.listDone_SelectedIndexChanged);
            this.listDone.DoubleClick += new System.EventHandler(this.list_DoubleClick);
            // 
            // colDone1
            // 
            this.colDone1.Width = 320;
            // 
            // colDone2
            // 
            this.colDone2.Width = 0;
            // 
            // colDone3
            // 
            this.colDone3.Width = 0;
            // 
            // panelHeadDone
            // 
            this.panelHeadDone.BackColor = System.Drawing.Color.FromArgb(39, 174, 96);
            this.panelHeadDone.Controls.Add(this.lblCountDone);
            this.panelHeadDone.Controls.Add(this.lblHeadDone);
            this.panelHeadDone.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeadDone.Location = new System.Drawing.Point(1, 1);
            this.panelHeadDone.Name = "panelHeadDone";
            this.panelHeadDone.Size = new System.Drawing.Size(338, 41);
            this.panelHeadDone.TabIndex = 0;
            // 
            // lblCountDone
            // 
            this.lblCountDone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCountDone.BackColor = System.Drawing.Color.White;
            this.lblCountDone.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblCountDone.ForeColor = System.Drawing.Color.FromArgb(39, 174, 96);
            this.lblCountDone.Location = new System.Drawing.Point(278, 8);
            this.lblCountDone.Name = "lblCountDone";
            this.lblCountDone.Size = new System.Drawing.Size(48, 24);
            this.lblCountDone.TabIndex = 1;
            this.lblCountDone.Text = "0";
            this.lblCountDone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeadDone
            // 
            this.lblHeadDone.AutoSize = true;
            this.lblHeadDone.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.lblHeadDone.ForeColor = System.Drawing.Color.White;
            this.lblHeadDone.Location = new System.Drawing.Point(12, 10);
            this.lblHeadDone.Name = "lblHeadDone";
            this.lblHeadDone.Size = new System.Drawing.Size(90, 20);
            this.lblHeadDone.TabIndex = 0;
            this.lblHeadDone.Text = "Выполнена";
            // 
            // KanbanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(236, 240, 245);
            this.ClientSize = new System.Drawing.Size(1080, 650);
            this.Controls.Add(this.panelColDone);
            this.Controls.Add(this.panelColWork);
            this.Controls.Add(this.panelColNew);
            this.Controls.Add(this.panelToolbar);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblHint);
            this.Controls.Add(this.lblUpdated);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "KanbanForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Канбан-доска";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.KanbanForm_FormClosing);
            this.Load += new System.EventHandler(this.KanbanForm_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelToolbar.ResumeLayout(false);
            this.panelColNew.ResumeLayout(false);
            this.panelHeadNew.ResumeLayout(false);
            this.panelHeadNew.PerformLayout();
            this.panelColWork.ResumeLayout(false);
            this.panelHeadWork.ResumeLayout(false);
            this.panelHeadWork.PerformLayout();
            this.panelColDone.ResumeLayout(false);
            this.panelHeadDone.ResumeLayout(false);
            this.panelHeadDone.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblUpdated;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Panel panelToolbar;
        private System.Windows.Forms.Label lblMove;
        private System.Windows.Forms.Button btnToNew;
        private System.Windows.Forms.Button btnToWork;
        private System.Windows.Forms.Button btnToDone;
        private System.Windows.Forms.Panel panelColNew;
        private System.Windows.Forms.ListView listNew;
        private System.Windows.Forms.ColumnHeader colNew1;
        private System.Windows.Forms.ColumnHeader colNew2;
        private System.Windows.Forms.ColumnHeader colNew3;
        private System.Windows.Forms.Panel panelHeadNew;
        private System.Windows.Forms.Label lblCountNew;
        private System.Windows.Forms.Label lblHeadNew;
        private System.Windows.Forms.Panel panelColWork;
        private System.Windows.Forms.ListView listWork;
        private System.Windows.Forms.ColumnHeader colWork1;
        private System.Windows.Forms.ColumnHeader colWork2;
        private System.Windows.Forms.ColumnHeader colWork3;
        private System.Windows.Forms.Panel panelHeadWork;
        private System.Windows.Forms.Label lblCountWork;
        private System.Windows.Forms.Label lblHeadWork;
        private System.Windows.Forms.Panel panelColDone;
        private System.Windows.Forms.ListView listDone;
        private System.Windows.Forms.ColumnHeader colDone1;
        private System.Windows.Forms.ColumnHeader colDone2;
        private System.Windows.Forms.ColumnHeader colDone3;
        private System.Windows.Forms.Panel panelHeadDone;
        private System.Windows.Forms.Label lblCountDone;
        private System.Windows.Forms.Label lblHeadDone;
    }
}
