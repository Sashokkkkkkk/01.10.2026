using System;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    public partial class KanbanForm : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")] public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();

        private SQLiteConnection DB;

        public KanbanForm()
        {
            InitializeComponent();
        }

        private async void KanbanForm_Load(object sender, EventArgs e)
        {
            try
            {
                DB = new SQLiteConnection(Database.connectionString);
                await DB.OpenAsync();
                StyleLists();
                await LoadBoardAsync();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Канбан", "Error");
            }
        }

        private void StyleLists()
        {
            foreach (var lv in new[] { listNew, listWork, listDone })
            {
                lv.OwnerDraw = false;
                lv.FullRowSelect = true;
                lv.HideSelection = false;
                lv.ShowItemToolTips = true;
                lv.Font = new Font("Segoe UI", 9.5f);
                lv.BackColor = Color.White;
                lv.BorderStyle = BorderStyle.None;
            }
        }

        private async Task LoadBoardAsync()
        {
            listNew.Items.Clear();
            listWork.Items.Clear();
            listDone.Items.Clear();

            await FillColumnAsync("Новая", listNew, lblCountNew);
            await FillColumnAsync("В работе", listWork, lblCountWork);
            await FillColumnAsync("Выполнена", listDone, lblCountDone);

            lblUpdated.Text = "Обновлено: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            int total = listNew.Items.Count + listWork.Items.Count + listDone.Items.Count;
            lblHint.Text = total == 0
                ? "Пока нет заявок. Создайте задачу в главном окне — она появится в колонке «Новая»."
                : "Выберите заявку → кнопки сверху меняют статус. Двойной клик — открыть карточку.";
        }

        private async Task FillColumnAsync(string status, ListView list, Label counter)
        {
            SQLiteDataReader reader = null;
            try
            {
                var cmd = new SQLiteCommand(
                    "SELECT " + Table_requests.id + ", " + Table_requests.tema + ", " + Table_requests.user + ", " +
                    Table_requests.kabinet + ", " + Table_requests.time + ", " + Table_requests.executor + ", " + Table_requests.typeProblem +
                    " FROM [" + Table_requests.main + "] WHERE " + Table_requests.status + " = @st ORDER BY " + Table_requests.id + " DESC", DB);
                cmd.Parameters.AddWithValue("@st", status);
                reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync();
                int count = 0;
                while (await reader.ReadAsync())
                {
                    string id = reader[Table_requests.id]?.ToString() ?? "";
                    string tema = reader[Table_requests.tema]?.ToString() ?? "Без темы";
                    string user = reader[Table_requests.user]?.ToString() ?? "";
                    string kab = reader[Table_requests.kabinet]?.ToString() ?? "";
                    string time = reader[Table_requests.time]?.ToString() ?? "";
                    string exec = reader[Table_requests.executor]?.ToString() ?? "—";
                    string type = reader[Table_requests.typeProblem]?.ToString() ?? "";

                    if (tema.Length > 40) tema = tema.Substring(0, 38) + "…";

                    var item = new ListViewItem("#" + id + "  " + tema) { Tag = id };
                    item.SubItems.Add(user + "  ·  каб. " + kab);
                    item.SubItems.Add("исп.: " + exec + "  ·  " + time);
                    item.ToolTipText = "#" + id + "\n" + tema + "\nТип: " + type + "\nОт: " + user + "\nКабинет: " + kab + "\nИсполнитель: " + exec + "\n" + time;
                    list.Items.Add(item);
                    count++;
                }
                counter.Text = count.ToString();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(status + ": " + ex.Message, "Канбан", "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private ListView GetSelectedList()
        {
            if (listNew.SelectedItems.Count > 0) return listNew;
            if (listWork.SelectedItems.Count > 0) return listWork;
            if (listDone.SelectedItems.Count > 0) return listDone;
            return null;
        }

        private string GetSelectedId()
        {
            var list = GetSelectedList();
            if (list == null || list.SelectedItems.Count == 0) return null;
            return list.SelectedItems[0].Tag?.ToString();
        }

        private async Task MoveTicketAsync(string newStatus)
        {
            string id = GetSelectedId();
            if (string.IsNullOrEmpty(id))
            {
                MessageBoxUI.Show("Сначала выберите заявку в одной из колонок", "Канбан", "Info");
                return;
            }
            try
            {
                var cmd = new SQLiteCommand(
                    "UPDATE [" + Table_requests.main + "] SET " + Table_requests.status + " = @st WHERE " + Table_requests.id + " = @id", DB);
                cmd.Parameters.AddWithValue("@st", newStatus);
                cmd.Parameters.AddWithValue("@id", id);
                await cmd.ExecuteNonQueryAsync();
                try
                {
                    File.AppendAllText(Logs.file,
                        "[Канбан]" + DataUsers.Initials + " → «" + newStatus + "» #" + id + " (" + DateTime.Now.ToString("dd.MM.yyyy HH:mm") + ")\n");
                }
                catch { }
                await LoadBoardAsync();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Канбан", "Error");
            }
        }

        private async void btnToNew_Click(object sender, EventArgs e) { await MoveTicketAsync("Новая"); }
        private async void btnToWork_Click(object sender, EventArgs e) { await MoveTicketAsync("В работе"); }
        private async void btnToDone_Click(object sender, EventArgs e) { await MoveTicketAsync("Выполнена"); }

        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            btnRefresh.Enabled = false;
            try { await LoadBoardAsync(); }
            finally { btnRefresh.Enabled = true; }
        }

        private async void OpenTicketDetails()
        {
            string id = GetSelectedId();
            if (string.IsNullOrEmpty(id))
            {
                MessageBoxUI.Show("Выберите заявку", "Канбан", "Info");
                return;
            }
            SQLiteDataReader reader = null;
            try
            {
                var cmd = new SQLiteCommand("SELECT * FROM [" + Table_requests.main + "] WHERE " + Table_requests.id + " = @id", DB);
                cmd.Parameters.AddWithValue("@id", id);
                reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    DataRequests.Kod = Convert.ToString(reader["id"]);
                    DataRequests.Tema = Convert.ToString(reader[Table_requests.tema]);
                    DataRequests.TheDate = Convert.ToString(reader[Table_requests.theDate]);
                    DataRequests.Type = Convert.ToString(reader[Table_requests.typeProblem]);
                    DataRequests.User = Convert.ToString(reader[Table_requests.user]);
                    DataRequests.Kabinet = Convert.ToString(reader[Table_requests.kabinet]);
                    DataRequests.Time = Convert.ToString(reader[Table_requests.time]);
                    DataRequests.Discription = Convert.ToString(reader[Table_requests.discription]);
                    DataRequests.Executor = Convert.ToString(reader[Table_requests.executor]);
                    DataRequests.Executor2 = Convert.ToString(reader[Table_requests.executor2]);
                    DataRequests.NameFile = Convert.ToString(reader[Table_requests.nameFile]);
                    DataRequests.PathTo = Convert.ToString(reader[Table_requests.pathFile]);
                    new DataTicketForm().Show();
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Открытие заявки", "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private void list_DoubleClick(object sender, EventArgs e) { OpenTicketDetails(); }
        private void btnOpen_Click(object sender, EventArgs e) { OpenTicketDetails(); }

        private void listNew_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listNew.SelectedItems.Count > 0) { listWork.SelectedItems.Clear(); listDone.SelectedItems.Clear(); }
        }
        private void listWork_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listWork.SelectedItems.Count > 0) { listNew.SelectedItems.Clear(); listDone.SelectedItems.Clear(); }
        }
        private void listDone_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listDone.SelectedItems.Count > 0) { listNew.SelectedItems.Clear(); listWork.SelectedItems.Clear(); }
        }

        private void panelHeader_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void btnClose_Click(object sender, EventArgs e) { Close(); }

        private void KanbanForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try { DB?.Close(); DB?.Dispose(); } catch { }
        }
    }
}
