using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupportDesk.forms
{
    /// <summary>
    /// Модуль «Канбан-доска» — визуальное управление заявками по статусам.
    /// Колонки: Новая → В работе → Выполнена. Перемещение одной кнопкой, двойной клик — карточка заявки.
    /// </summary>
    public partial class KanbanForm : Form
    {
        #region Drag window
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")] public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        #endregion

        private SQLiteConnection DB;
        private readonly Color colNew = Color.FromArgb(52, 152, 219);
        private readonly Color colWork = Color.FromArgb(230, 126, 34);
        private readonly Color colDone = Color.FromArgb(39, 174, 96);
        private readonly Color cardBg = Color.FromArgb(255, 255, 255);
        private readonly Color cardBorder = Color.FromArgb(220, 220, 220);

        // ticket id stored in ListViewItem.Tag
        public KanbanForm()
        {
            InitializeComponent();
        }

        private async void KanbanForm_Load(object sender, EventArgs e)
        {
            try
            {
                DB = new SQLiteConnection(Database.connectionString);
                await DB.OpenAsync();
                await LoadBoardAsync();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Канбан", "Error");
            }
        }

        private async Task LoadBoardAsync()
        {
            listNew.Items.Clear();
            listWork.Items.Clear();
            listDone.Items.Clear();
            lblCountNew.Text = "0";
            lblCountWork.Text = "0";
            lblCountDone.Text = "0";

            await FillColumnAsync("Новая", listNew, lblCountNew);
            await FillColumnAsync("В работе", listWork, lblCountWork);
            await FillColumnAsync("Выполнена", listDone, lblCountDone);

            lblUpdated.Text = "Обновлено: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        }

        private async Task FillColumnAsync(string status, ListView list, Label counter)
        {
            SQLiteDataReader reader = null;
            try
            {
                var cmd = new SQLiteCommand(
                    $"SELECT {Table_requests.id}, {Table_requests.tema}, {Table_requests.user}, " +
                    $"{Table_requests.kabinet}, {Table_requests.time}, {Table_requests.executor}, {Table_requests.typeProblem} " +
                    $"FROM [{Table_requests.main}] WHERE {Table_requests.status} = @st ORDER BY {Table_requests.id} DESC", DB);
                cmd.Parameters.AddWithValue("@st", status);
                reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync();
                int count = 0;
                while (await reader.ReadAsync())
                {
                    string id = reader[Table_requests.id]?.ToString() ?? "";
                    string tema = reader[Table_requests.tema]?.ToString() ?? "—";
                    string user = reader[Table_requests.user]?.ToString() ?? "";
                    string kab = reader[Table_requests.kabinet]?.ToString() ?? "";
                    string time = reader[Table_requests.time]?.ToString() ?? "";
                    string exec = reader[Table_requests.executor]?.ToString() ?? "";
                    string type = reader[Table_requests.typeProblem]?.ToString() ?? "";

                    // Title line + subtitle
                    string title = $"#{id}  {tema}";
                    if (title.Length > 48) title = title.Substring(0, 45) + "…";
                    string sub = $"{user}  ·  каб.{kab}";
                    if (!string.IsNullOrEmpty(exec)) sub += $"  ·  {exec}";
                    if (!string.IsNullOrEmpty(time)) sub += $"\n{time}";

                    var item = new ListViewItem(title) { Tag = id };
                    item.SubItems.Add(sub);
                    item.ToolTipText = $"#{id}\n{tema}\nТип: {type}\nОт: {user}\nКабинет: {kab}\nИсполнитель: {exec}\n{time}";
                    list.Items.Add(item);
                    count++;
                }
                counter.Text = count.ToString();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{status}: {ex.Message}", "Канбан", "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private ListView GetSelectedList()
        {
            if (listNew.SelectedItems.Count > 0) return listNew;
            if (listWork.SelectedItems.Count > 0) return listWork;
            if (listDone.SelectedItems.Count > 0) return listDone;
            return null;
        }

        private string GetSelectedId()
        {
            var list = GetSelectedList();
            if (list == null || list.SelectedItems.Count == 0) return null;
            return list.SelectedItems[0].Tag?.ToString();
        }

        private async Task MoveTicketAsync(string newStatus)
        {
            string id = GetSelectedId();
            if (string.IsNullOrEmpty(id))
            {
                MessageBoxUI.Show("Выберите заявку в любой колонке", "Канбан", "Info");
                return;
            }
            try
            {
                var cmd = new SQLiteCommand(
                    $"UPDATE [{Table_requests.main}] SET {Table_requests.status} = @st WHERE {Table_requests.id} = @id", DB);
                cmd.Parameters.AddWithValue("@st", newStatus);
                cmd.Parameters.AddWithValue("@id", id);
                await cmd.ExecuteNonQueryAsync();

                // log
                try
                {
                    File.AppendAllText(Logs.file,
                        $"[Канбан]{DataUsers.Initials} перевёл заявку #{id} → «{newStatus}» ({DateTime.Now:dd.MM.yyyy HH:mm})\n");
                }
                catch { /* ignore log errors */ }

                await LoadBoardAsync();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Канбан — перемещение", "Error");
            }
        }

        private async void btnToNew_Click(object sender, EventArgs e) => await MoveTicketAsync("Новая");
        private async void btnToWork_Click(object sender, EventArgs e) => await MoveTicketAsync("В работе");
        private async void btnToDone_Click(object sender, EventArgs e) => await MoveTicketAsync("Выполнена");

        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            btnRefresh.Enabled = false;
            btnRefresh.Text = "…";
            try { await LoadBoardAsync(); }
            finally { btnRefresh.Enabled = true; btnRefresh.Text = "Обновить"; }
        }

        private async void OpenTicketDetails()
        {
            string id = GetSelectedId();
            if (string.IsNullOrEmpty(id)) return;

            SQLiteDataReader reader = null;
            try
            {
                var cmd = new SQLiteCommand($"SELECT * FROM [{Table_requests.main}] WHERE {Table_requests.id} = @id", DB);
                cmd.Parameters.AddWithValue("@id", id);
                reader = (SQLiteDataReader)await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    DataRequests.Kod = Convert.ToString(reader["id"]);
                    DataRequests.Tema = Convert.ToString(reader[Table_requests.tema]);
                    DataRequests.TheDate = Convert.ToString(reader[Table_requests.theDate]);
                    DataRequests.Type = Convert.ToString(reader[Table_requests.typeProblem]);
                    DataRequests.User = Convert.ToString(reader[Table_requests.user]);
                    DataRequests.Kabinet = Convert.ToString(reader[Table_requests.kabinet]);
                    DataRequests.Time = Convert.ToString(reader[Table_requests.time]);
                    DataRequests.Discription = Convert.ToString(reader[Table_requests.discription]);
                    DataRequests.Executor = Convert.ToString(reader[Table_requests.executor]);
                    DataRequests.Executor2 = Convert.ToString(reader[Table_requests.executor2]);
                    DataRequests.NameFile = Convert.ToString(reader[Table_requests.nameFile]);
                    DataRequests.PathTo = Convert.ToString(reader[Table_requests.pathFile]);

                    Form f = new DataTicketForm();
                    f.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, "Открытие заявки", "Error");
            }
            finally
            {
                reader?.Close();
            }
        }

        private void list_DoubleClick(object sender, EventArgs e) => OpenTicketDetails();
        private void btnOpen_Click(object sender, EventArgs e) => OpenTicketDetails();

        // clear selection in other lists when selecting in one
        private void listNew_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listNew.SelectedItems.Count > 0)
            {
                listWork.SelectedItems.Clear();
                listDone.SelectedItems.Clear();
            }
        }
        private void listWork_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listWork.SelectedItems.Count > 0)
            {
                listNew.SelectedItems.Clear();
                listDone.SelectedItems.Clear();
            }
        }
        private void listDone_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listDone.SelectedItems.Count > 0)
            {
                listNew.SelectedItems.Clear();
                listWork.SelectedItems.Clear();
            }
        }

        private void panelHeader_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void btnClose_Click(object sender, EventArgs e) => Close();

        private void KanbanForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try { DB?.Close(); DB?.Dispose(); } catch { }
        }
    }
}
