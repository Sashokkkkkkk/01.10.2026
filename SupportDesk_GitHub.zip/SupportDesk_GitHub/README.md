# SupportDesk + Канбан-доска

Программа учёта заявок / helpdesk на WinForms (.NET Framework 4.8) + SQLite.

**Дополнительный модуль:** визуальная **Канбан-доска** заявок (колонки «Новая» → «В работе» → «Выполнена»).

## Возможности Канбана

- Три колонки со счётчиками
- Перенос заявки кнопками одной командой
- Двойной клик / «Открыть» — карточка заявки
- Подсказки при наведении
- Запись действий в `logs.txt`

Кнопка **«Канбан»** — в левой панели главного окна администратора.

## Требования

- Windows
- Visual Studio 2019/2022 (или Build Tools)
- .NET Framework 4.8 Developer Pack
- (опционально) Microsoft Excel — для отчётов

## Быстрый старт

```bash
git clone https://github.com/<ваш-логин>/<репозиторий>.git
cd <репозиторий>
```

1. Откройте `SupportDesk.sln` в Visual Studio  
2. Восстановите пакеты NuGet:
   - ПКМ по решению → **Restore NuGet Packages**  
   - или в Package Manager Console: `Update-Package -reinstall`  
3. **Build → Rebuild Solution**  
4. Запуск (F5)

### NuGet-пакеты (подтянутся автоматически)

| Пакет | Назначение |
|-------|------------|
| System.Data.SQLite | База данных |
| Newtonsoft.Json | JSON |
| Telegram.Bot | Уведомления в Telegram |
| Microsoft.Office.Interop.Excel | Экспорт отчётов |

## Структура

```
SupportDesk.sln
SupportDesk/
  forms/          # все формы, включая KanbanForm
  dll/            # кастомные UI-контролы
  Program.cs      # точка входа + константы таблиц
  packages.config
  ...
.gitignore
README.md
```

## База данных

По умолчанию: `teh_db.db` (SQLite) рядом с exe.  
Файл БД в `.gitignore` — в репозиторий не попадает.

## Лицензия

Используйте и модифицируйте свободно в рамках вашей организации.
