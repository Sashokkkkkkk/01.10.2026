// ============================================================
//  SupportDesk.Core.cs  —  Production-ready module (one file)
//  Автор: улучшенный слой для SupportDesk
//  .NET Framework 4.8 / System.Data.SQLite
// ============================================================

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SupportDesk.Core
{
    #region ==================== LOGGER ====================

    public enum LogLevel { Debug, Info, Warning, Error, Critical }

    /// <summary>
    /// Потокобезопасный логгер с ротацией файлов и уровнями.
    /// </summary>
    public static class Logger
    {
        private static readonly object _lock = new object();
        private static string _logDir = "logs";
        private static string _logFile = "SupportDesk.log";
        private static long _maxSizeBytes = 5 * 1024 * 1024; // 5 MB
        private static int _maxFiles = 10;
        private static LogLevel _minLevel = LogLevel.Info;

        public static void Configure(string directory = null, string fileName = null,
            long maxSizeMb = 5, int maxFiles = 10, LogLevel minLevel = LogLevel.Info)
        {
            if (!string.IsNullOrWhiteSpace(directory)) _logDir = directory;
            if (!string.IsNullOrWhiteSpace(fileName)) _logFile = fileName;
            _maxSizeBytes = maxSizeMb * 1024 * 1024;
            _maxFiles = Math.Max(1, maxFiles);
            _minLevel = minLevel;

            Directory.CreateDirectory(_logDir);
        }

        public static void Debug(string message, Exception ex = null) => Write(LogLevel.Debug, message, ex);
        public static void Info(string message, Exception ex = null) => Write(LogLevel.Info, message, ex);
        public static void Warning(string message, Exception ex = null) => Write(LogLevel.Warning, message, ex);
        public static void Error(string message, Exception ex = null) => Write(LogLevel.Error, message, ex);
        public static void Critical(string message, Exception ex = null) => Write(LogLevel.Critical, message, ex);

        private static void Write(LogLevel level, string message, Exception ex)
        {
            if (level < _minLevel) return;

            var sb = new StringBuilder();
            sb.AppendFormat("[{0:yyyy-MM-dd HH:mm:ss.fff}] [{1,-8}] [{2}] {3}",
                DateTime.Now, level, Thread.CurrentThread.ManagedThreadId, message);

            if (ex != null)
            {
                sb.AppendLine();
                sb.AppendLine(ex.ToString());
            }

            lock (_lock)
            {
                try
                {
                    var path = Path.Combine(_logDir, _logFile);
                    RotateIfNeeded(path);
                    File.AppendAllText(path, sb.ToString() + Environment.NewLine, Encoding.UTF8);
                }
                catch { /* никогда не падаем из-за логов */ }
            }
        }

        private static void RotateIfNeeded(string path)
        {
            if (!File.Exists(path)) return;
            var fi = new FileInfo(path);
            if (fi.Length < _maxSizeBytes) return;

            for (int i = _maxFiles - 1; i >= 1; i--)
            {
                var src = Path.Combine(_logDir, $"{Path.GetFileNameWithoutExtension(_logFile)}.{i}.log");
                var dst = Path.Combine(_logDir, $"{Path.GetFileNameWithoutExtension(_logFile)}.{i + 1}.log");
                if (File.Exists(src))
                {
                    if (File.Exists(dst)) File.Delete(dst);
                    File.Move(src, dst);
                }
            }

            var first = Path.Combine(_logDir, $"{Path.GetFileNameWithoutExtension(_logFile)}.1.log");
            if (File.Exists(first)) File.Delete(first);
            File.Move(path, first);
        }
    }

    #endregion

    #region ==================== DATABASE ====================

    /// <summary>
    /// Централизованный, потокобезопасный менеджер SQLite.
    /// Используй вместо кучи new SQLiteConnection в каждой форме.
    /// </summary>
    public sealed class DbManager : IDisposable
    {
        private readonly string _connectionString;
        private readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);
        private bool _disposed;

        public DbManager(string connectionString = null)
        {
            _connectionString = connectionString
                ?? @"Data Source=teh_db.db;Version=3;Journal Mode=WAL;BusyTimeout=5000;Pooling=True;";
        }

        /// <summary>Выполнить запрос без возврата данных (INSERT/UPDATE/DELETE)</summary>
        public async Task<int> ExecuteAsync(string sql, params SQLiteParameter[] parameters)
        {
            await _semaphore.WaitAsync().ConfigureAwait(false);
            try
            {
                using (var conn = new SQLiteConnection(_connectionString))
                {
                    await conn.OpenAsync().ConfigureAwait(false);
                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        if (parameters != null) cmd.Parameters.AddRange(parameters);
                        return await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"ExecuteAsync failed: {sql}", ex);
                throw;
            }
            finally { _semaphore.Release(); }
        }

        /// <summary>Скалярный запрос (COUNT, MAX и т.д.)</summary>
        public async Task<object> ExecuteScalarAsync(string sql, params SQLiteParameter[] parameters)
        {
            await _semaphore.WaitAsync().ConfigureAwait(false);
            try
            {
                using (var conn = new SQLiteConnection(_connectionString))
                {
                    await conn.OpenAsync().ConfigureAwait(false);
                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        if (parameters != null) cmd.Parameters.AddRange(parameters);
                        return await cmd.ExecuteScalarAsync().ConfigureAwait(false);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"ExecuteScalarAsync failed: {sql}", ex);
                throw;
            }
            finally { _semaphore.Release(); }
        }

        /// <summary>Получить DataTable</summary>
        public async Task<DataTable> QueryAsync(string sql, params SQLiteParameter[] parameters)
        {
            await _semaphore.WaitAsync().ConfigureAwait(false);
            try
            {
                using (var conn = new SQLiteConnection(_connectionString))
                {
                    await conn.OpenAsync().ConfigureAwait(false);
                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        if (parameters != null) cmd.Parameters.AddRange(parameters);
                        using (var adapter = new SQLiteDataAdapter(cmd))
                        {
                            var dt = new DataTable();
                            adapter.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"QueryAsync failed: {sql}", ex);
                throw;
            }
            finally { _semaphore.Release(); }
        }

        /// <summary>Получить список объектов через маппер</summary>
        public async Task<List<T>> QueryAsync<T>(string sql, Func<IDataReader, T> map, params SQLiteParameter[] parameters)
        {
            await _semaphore.WaitAsync().ConfigureAwait(false);
            try
            {
                var list = new List<T>();
                using (var conn = new SQLiteConnection(_connectionString))
                {
                    await conn.OpenAsync().ConfigureAwait(false);
                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        if (parameters != null) cmd.Parameters.AddRange(parameters);
                        using (var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false))
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                                list.Add(map(reader));
                        }
                    }
                }
                return list;
            }
            catch (Exception ex)
            {
                Logger.Error($"QueryAsync<T> failed: {sql}", ex);
                throw;
            }
            finally { _semaphore.Release(); }
        }

        /// <summary>Транзакция</summary>
        public async Task ExecuteInTransactionAsync(Func<SQLiteConnection, SQLiteTransaction, Task> action)
        {
            await _semaphore.WaitAsync().ConfigureAwait(false);
            try
            {
                using (var conn = new SQLiteConnection(_connectionString))
                {
                    await conn.OpenAsync().ConfigureAwait(false);
                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            await action(conn, tran).ConfigureAwait(false);
                            tran.Commit();
                        }
                        catch
                        {
                            tran.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Transaction failed", ex);
                throw;
            }
            finally { _semaphore.Release(); }
        }

        public void Dispose()
        {
            if (_disposed) return;
            _semaphore.Dispose();
            _disposed = true;
        }
    }

    #endregion

    #region ==================== PASSWORD SECURITY ====================

    public static class PasswordHelper
    {
        private static readonly HashSet<string> Forbidden = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "123456","1qwerty","1q2w3e4r5t","1q2w3e4r","1q2w3e4r5t6y","159753","753159",
            "951753","357159","123456789","1234567890","0123456789","qwerty123","qwerty",
            "qwerty1","password","12345678","1q2w3e","111111","11111111","a111111","000000",
            "asdasd","asdasd123","123321","qwertyuiop","abc123","666666","7777777",
            "password1","passw0rd1","passw0rd","iloveyou","zxcvbnm","qazwsx","dragon",
            "asdfghjkl","monkey","unknown","1qaz2wsx","gfhjkm","ghbdtn","default","covid19","gfyltvbz"
        };

        public enum Strength { Invalid, Weak, Medium, Strong, VeryStrong }

        public static Strength Check(string password)
        {
            if (string.IsNullOrWhiteSpace(password) || password.Length < 6)
                return Strength.Invalid;

            if (Forbidden.Contains(password))
                return Strength.Invalid;

            int score = 0;
            if (password.Length >= 8) score++;
            if (password.Length >= 12) score++;
            if (password.Any(char.IsUpper) && password.Any(char.IsLower)) score++;
            if (password.Any(char.IsDigit)) score++;
            if (password.Any(c => !char.IsLetterOrDigit(c))) score++;

            if (score <= 1) return Strength.Weak;
            if (score == 2) return Strength.Medium;
            if (score == 3) return Strength.Strong;
            return Strength.VeryStrong;
        }

        public static string GetMessage(Strength s)
        {
            switch (s)
            {
                case Strength.Invalid: return "Недопустимый / слишком простой пароль";
                case Strength.Weak: return "Слабый пароль";
                case Strength.Medium: return "Средний пароль";
                case Strength.Strong: return "Надёжный пароль";
                case Strength.VeryStrong: return "Очень надёжный пароль";
                default: return "";
            }
        }

        /// <summary>SHA-256 хеш (для будущего перехода с plain-text)</summary>
        public static string Hash(string password, string salt = "SupportDeskSalt2023")
        {
            using (var sha = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password + salt);
                var hash = sha.ComputeHash(bytes);
                return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }
        }
    }

    #endregion

    #region ==================== TICKET REPOSITORY ====================

    public class Ticket
    {
        public long Id { get; set; }
        public string TheDate { get; set; }
        public string Tema { get; set; }
        public string TypeProblem { get; set; }
        public string UserReq { get; set; }
        public string Kabinet { get; set; }
        public string Discription { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Status { get; set; }
        public string Executor { get; set; }
        public string Executor2 { get; set; }
        public string NameFile { get; set; }
        public string PathFile { get; set; }
        public string NameFileResult { get; set; }
        public string PathFileResult { get; set; }
    }

    public class TicketRepository
    {
        private readonly DbManager _db;

        public TicketRepository(DbManager db = null)
        {
            _db = db ?? new DbManager();
        }

        public async Task<List<Ticket>> GetAllAsync()
        {
            const string sql = "SELECT * FROM Requests ORDER BY id DESC";
            return await _db.QueryAsync(sql, MapTicket);
        }

        public async Task<List<Ticket>> GetByStatusAsync(string status)
        {
            const string sql = "SELECT * FROM Requests WHERE status = @status ORDER BY id DESC";
            return await _db.QueryAsync(sql, MapTicket,
                new SQLiteParameter("@status", status));
        }

        public async Task<int> CountByStatusAsync(string status)
        {
            const string sql = "SELECT COUNT(*) FROM Requests WHERE status = @status";
            var result = await _db.ExecuteScalarAsync(sql, new SQLiteParameter("@status", status));
            return Convert.ToInt32(result);
        }

        public async Task<int> CreateAsync(Ticket t)
        {
            const string sql = @"
                INSERT INTO Requests 
                (theDate, tema, typeProblem, userReq, kabinet, discription, time, status, executor, executor2, nameFile, pathFile)
                VALUES 
                (@theDate, @tema, @typeProblem, @user, @kabinet, @disc, @time, @status, @exec, @exec2, @nameFile, @pathFile)";

            return await _db.ExecuteAsync(sql,
                new SQLiteParameter("@theDate", t.TheDate),
                new SQLiteParameter("@tema", t.Tema),
                new SQLiteParameter("@typeProblem", t.TypeProblem),
                new SQLiteParameter("@user", t.UserReq),
                new SQLiteParameter("@kabinet", t.Kabinet),
                new SQLiteParameter("@disc", t.Discription),
                new SQLiteParameter("@time", t.Time),
                new SQLiteParameter("@status", t.Status ?? "Новая"),
                new SQLiteParameter("@exec", t.Executor ?? ""),
                new SQLiteParameter("@exec2", t.Executor2 ?? ""),
                new SQLiteParameter("@nameFile", t.NameFile ?? ""),
                new SQLiteParameter("@pathFile", t.PathFile ?? ""));
        }

        public async Task<int> UpdateStatusAsync(string theDate, string user, string kabinet, string newStatus, string executor = null)
        {
            const string sql = @"
                UPDATE Requests 
                SET status = @status, executor = COALESCE(@executor, executor)
                WHERE theDate = @date AND userReq = @user AND kabinet = @kabinet";

            return await _db.ExecuteAsync(sql,
                new SQLiteParameter("@status", newStatus),
                new SQLiteParameter("@executor", (object)executor ?? DBNull.Value),
                new SQLiteParameter("@date", theDate),
                new SQLiteParameter("@user", user),
                new SQLiteParameter("@kabinet", kabinet));
        }

        private static Ticket MapTicket(IDataReader r)
        {
            return new Ticket
            {
                Id = r["id"] != DBNull.Value ? Convert.ToInt64(r["id"]) : 0,
                TheDate = r["theDate"]?.ToString(),
                Tema = r["tema"]?.ToString(),
                TypeProblem = r["typeProblem"]?.ToString(),
                UserReq = r["userReq"]?.ToString(),
                Kabinet = r["kabinet"]?.ToString(),
                Discription = r["discription"]?.ToString(),
                Date = r["date"]?.ToString(),
                Time = r["time"]?.ToString(),
                Status = r["status"]?.ToString(),
                Executor = r["executor"]?.ToString(),
                Executor2 = r["executor2"]?.ToString(),
                NameFile = r["nameFile"]?.ToString(),
                PathFile = r["pathFile"]?.ToString(),
                NameFileResult = r["nameFileResult"]?.ToString(),
                PathFileResult = r["pathFileResult"]?.ToString()
            };
        }
    }

    #endregion

    #region ==================== QUICK START ====================

    /*
        === Как использовать (пример) ===

        // 1. В Program.cs или PreLoaderForm
        Logger.Configure(minLevel: LogLevel.Debug);
        Logger.Info("Application started");

        // 2. В любой форме вместо кучи SQLiteConnection
        private readonly TicketRepository _tickets = new TicketRepository();

        private async void LoadTickets()
        {
            try
            {
                var list = await _tickets.GetByStatusAsync("Новая");
                // заполняешь DataGridView / ListView
            }
            catch (Exception ex)
            {
                Logger.Error("Ошибка загрузки заявок", ex);
                MessageBox.Show("Не удалось загрузить заявки");
            }
        }

        // 3. Проверка пароля
        var strength = PasswordHelper.Check(txtPassword.Text);
        labelStrength.Text = PasswordHelper.GetMessage(strength);
        if (strength < PasswordHelper.Strength.Medium)
            // запретить
    */

    #endregion
}
