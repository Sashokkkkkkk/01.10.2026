// ============================================================
//  QuickActionFab.cs — аккуратная плавающая кнопка быстрых действий
// ============================================================

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SupportDesk.Core
{
    public class FabMenuItem
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public Color Color { get; set; }
        public Action Action { get; set; }
    }

    public class QuickActionFab : Control
    {
        public Color FabColor { get; set; } = Color.FromArgb(45, 125, 210);
        public Color FabHoverColor { get; set; } = Color.FromArgb(30, 100, 180);
        public int FabDiameter { get; set; } = 52;
        public int BadgeCount { get; set; }
        public int EdgeMargin { get; set; } = 20;

        private readonly List<FabMenuItem> _items = new List<FabMenuItem>();
        private bool _open;
        private bool _hoverMain;
        private int _hoverIndex = -1;
        private float _progress;
        private readonly Timer _timer = new Timer { Interval = 15 };

        public event EventHandler<FabMenuItem> ItemClicked;

        public QuickActionFab()
        {
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.SupportsTransparentBackColor, true);

            BackColor = Color.Transparent;
            Cursor = Cursors.Hand;
            Size = new Size(FabDiameter + 4, FabDiameter + 4);

            _timer.Tick += (s, e) =>
            {
                float step = 0.10f;
                if (_open)
                {
                    _progress += step;
                    if (_progress >= 1f) { _progress = 1f; _timer.Stop(); }
                }
                else
                {
                    _progress -= step;
                    if (_progress <= 0f) { _progress = 0f; _timer.Stop(); }
                }
                UpdateLayout();
                Invalidate();
            };
        }

        public QuickActionFab(Form parent) : this()
        {
            parent.Controls.Add(this);
            parent.Resize += (s, e) => UpdateLayout();
            UpdateLayout();
            BringToFront();
        }

        public void AddItem(string id, string title, Color color, Action action = null)
        {
            _items.Add(new FabMenuItem { Id = id, Title = title, Color = color, Action = action });
        }

        public void ClearItems() => _items.Clear();

        public void SetBadge(int count)
        {
            BadgeCount = Math.Max(0, count);
            Invalidate();
        }

        private void UpdateLayout()
        {
            if (!(Parent is Form f)) return;

            int menuH = _open || _progress > 0.01f
                ? (int)(_items.Count * 48 * Math.Min(1f, _progress + 0.2f))
                : 0;

            Width = Math.Max(FabDiameter + 4, 160);
            Height = FabDiameter + 8 + menuH;
            Left = f.ClientSize.Width - FabDiameter - EdgeMargin;
            Top = f.ClientSize.Height - Height - EdgeMargin;
            BringToFront();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            int mainX = Width - FabDiameter - 2;
            int mainY = Height - FabDiameter - 2;
            int cx = mainX + FabDiameter / 2;
            int cy = mainY + FabDiameter / 2;

            if (_progress > 0.01f)
            {
                for (int i = 0; i < _items.Count; i++)
                {
                    float t = Clamp01(_progress * 1.3f - i * 0.1f);
                    if (t <= 0f) continue;
                    t = EaseOutCubic(t);

                    int size = 40;
                    int ix = mainX + (FabDiameter - size) / 2;
                    int iy = mainY - 10 - (int)((i + 1) * 48 * t);

                    using (var sh = new SolidBrush(Color.FromArgb((int)(35 * t), 0, 0, 0)))
                        g.FillEllipse(sh, ix + 1, iy + 2, size, size);

                    Color col = _hoverIndex == i
                        ? ControlPaint.Light(_items[i].Color)
                        : _items[i].Color;
                    using (var br = new SolidBrush(Color.FromArgb((int)(255 * t), col)))
                        g.FillEllipse(br, ix, iy, size, size);

                    DrawMenuIcon(g, i, ix, iy, size, Color.FromArgb((int)(255 * t), Color.White));

                    if (t > 0.55f)
                    {
                        float a = (t - 0.55f) / 0.45f;
                        using (var font = new Font("Segoe UI", 9f, FontStyle.Regular))
                        {
                            var sz = g.MeasureString(_items[i].Title, font);
                            int lx = ix - (int)sz.Width - 14;
                            int ly = iy + (size - (int)sz.Height) / 2;

                            var rect = new Rectangle(lx - 8, ly - 3, (int)sz.Width + 16, (int)sz.Height + 6);
                            using (var path = RoundRect(rect, 5))
                            using (var bg = new SolidBrush(Color.FromArgb((int)(210 * a), 32, 32, 32)))
                                g.FillPath(bg, path);

                            using (var br = new SolidBrush(Color.FromArgb((int)(255 * a), Color.White)))
                                g.DrawString(_items[i].Title, font, br, lx, ly);
                        }
                    }
                }
            }

            using (var sh = new SolidBrush(Color.FromArgb(45, 0, 0, 0)))
                g.FillEllipse(sh, mainX + 2, mainY + 3, FabDiameter, FabDiameter);

            Color fabCol = _hoverMain ? FabHoverColor : FabColor;
            using (var br = new SolidBrush(fabCol))
                g.FillEllipse(br, mainX, mainY, FabDiameter, FabDiameter);

            using (var pen = new Pen(Color.FromArgb(40, 255, 255, 255), 1.5f))
                g.DrawEllipse(pen, mainX + 1, mainY + 1, FabDiameter - 2, FabDiameter - 2);

            g.TranslateTransform(cx, cy);
            g.RotateTransform(_progress * 45f);
            using (var pen = new Pen(Color.White, 2.6f)
            {
                StartCap = LineCap.Round,
                EndCap = LineCap.Round
            })
            {
                int arm = 11;
                g.DrawLine(pen, -arm, 0, arm, 0);
                g.DrawLine(pen, 0, -arm, 0, arm);
            }
            g.ResetTransform();

            if (BadgeCount > 0 && _progress < 0.15f)
            {
                int bs = 18;
                int bx = mainX + FabDiameter - bs + 2;
                int by = mainY - 2;
                using (var br = new SolidBrush(Color.FromArgb(220, 53, 69)))
                    g.FillEllipse(br, bx, by, bs, bs);
                using (var font = new Font("Segoe UI", 7f, FontStyle.Bold))
                {
                    string txt = BadgeCount > 99 ? "99+" : BadgeCount.ToString();
                    var tsz = g.MeasureString(txt, font);
                    using (var br = new SolidBrush(Color.White))
                        g.DrawString(txt, font, br,
                            bx + (bs - tsz.Width) / 2f,
                            by + (bs - tsz.Height) / 2f + 0.5f);
                }
            }
        }

        private static void DrawMenuIcon(Graphics g, int index, int x, int y, int size, Color color)
        {
            int cx = x + size / 2;
            int cy = y + size / 2;
            using (var pen = new Pen(color, 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                switch (index % 4)
                {
                    case 0:
                        g.DrawRectangle(pen, cx - 7, cy - 8, 14, 16);
                        g.DrawLine(pen, cx - 4, cy - 3, cx + 4, cy - 3);
                        g.DrawLine(pen, cx - 4, cy + 1, cx + 4, cy + 1);
                        g.DrawLine(pen, cx - 4, cy + 5, cx + 2, cy + 5);
                        break;
                    case 1:
                        Point[] box =
                        {
                            new Point(cx, cy - 8),
                            new Point(cx + 9, cy - 3),
                            new Point(cx + 9, cy + 6),
                            new Point(cx, cy + 11),
                            new Point(cx - 9, cy + 6),
                            new Point(cx - 9, cy - 3)
                        };
                        g.DrawPolygon(pen, box);
                        g.DrawLine(pen, cx, cy - 8, cx, cy + 11);
                        g.DrawLine(pen, cx - 9, cy - 3, cx + 9, cy - 3);
                        break;
                    case 2:
                        g.DrawEllipse(pen, cx - 5, cy - 8, 10, 10);
                        g.DrawArc(pen, cx - 9, cy + 2, 18, 14, 200, 140);
                        break;
                    default:
                        g.DrawEllipse(pen, cx - 4, cy - 4, 8, 8);
                        for (int a = 0; a < 360; a += 45)
                        {
                            double rad = a * Math.PI / 180.0;
                            int x1 = cx + (int)(Math.Cos(rad) * 6);
                            int y1 = cy + (int)(Math.Sin(rad) * 6);
                            int x2 = cx + (int)(Math.Cos(rad) * 9);
                            int y2 = cy + (int)(Math.Sin(rad) * 9);
                            g.DrawLine(pen, x1, y1, x2, y2);
                        }
                        break;
                }
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int mainX = Width - FabDiameter - 2;
            int mainY = Height - FabDiameter - 2;
            int cx = mainX + FabDiameter / 2;
            int cy = mainY + FabDiameter / 2;

            bool wasMain = _hoverMain;
            int wasIdx = _hoverIndex;

            _hoverMain = Dist(e.X, e.Y, cx, cy) <= FabDiameter / 2f;
            _hoverIndex = -1;

            if (_open && _progress > 0.7f)
            {
                for (int i = 0; i < _items.Count; i++)
                {
                    int size = 40;
                    int ix = mainX + (FabDiameter - size) / 2 + size / 2;
                    int iy = mainY - 10 - (i + 1) * 48 + size / 2;
                    if (Dist(e.X, e.Y, ix, iy) <= size / 2f)
                    {
                        _hoverIndex = i;
                        break;
                    }
                }
            }

            if (wasMain != _hoverMain || wasIdx != _hoverIndex)
                Invalidate();

            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hoverMain = false;
            _hoverIndex = -1;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            int mainX = Width - FabDiameter - 2;
            int mainY = Height - FabDiameter - 2;
            int cx = mainX + FabDiameter / 2;
            int cy = mainY + FabDiameter / 2;

            if (Dist(e.X, e.Y, cx, cy) <= FabDiameter / 2f)
            {
                _open = !_open;
                _timer.Start();
                UpdateLayout();
                Invalidate();
                return;
            }

            if (_open && _progress > 0.7f)
            {
                for (int i = 0; i < _items.Count; i++)
                {
                    int size = 40;
                    int ix = mainX + (FabDiameter - size) / 2 + size / 2;
                    int iy = mainY - 10 - (i + 1) * 48 + size / 2;
                    if (Dist(e.X, e.Y, ix, iy) <= size / 2f)
                    {
                        var item = _items[i];
                        _open = false;
                        _timer.Start();

                        try
                        {
                            if (item.Action != null)
                                item.Action.Invoke();
                            ItemClicked?.Invoke(this, item);
                        }
                        catch (Exception ex)
                        {
                            try
                            {
                                MessageBox.Show(
                                    "Действие временно недоступно.\n" + ex.Message,
                                    "Быстрые действия",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                            }
                            catch { }
                        }
                        return;
                    }
                }
            }

            base.OnMouseClick(e);
        }

        private static float Dist(int x1, int y1, int x2, int y2)
        {
            float dx = x1 - x2, dy = y1 - y2;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }

        private static float Clamp01(float v) => v < 0 ? 0 : (v > 1 ? 1 : v);

        private static float EaseOutCubic(float t)
        {
            float u = 1f - t;
            return 1f - u * u * u;
        }

        private static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            int d = radius * 2;
            var p = new GraphicsPath();
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _timer.Stop();
                _timer.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
