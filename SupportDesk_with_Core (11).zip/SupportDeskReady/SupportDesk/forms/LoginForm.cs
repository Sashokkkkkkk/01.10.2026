using SupportDesk.forms;
using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SupportDesk
{
    public partial class LoginForm : Form
    {
        #region Настройки формы
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        #endregion
        #region Локальные переменные
        private SQLiteConnection DB;
        private readonly DateTime thisDay = DateTime.Now;
        private readonly string path = Path.GetTempPath();
        private readonly string directory = RememberLogin.directoryName;
        private readonly string nameFileRemember = RememberLogin.fileName;
        private int attemptLogin = 3;
        [Obsolete]
        private readonly Form fbot = new TelegramForm();
        #endregion
        [Obsolete]
        public LoginForm()
        {
            InitializeComponent();
            CheckRemeber();
        }

        [Obsolete]
        private async void LoginForm_Load(object sender, EventArgs e)
        {
            RootAccess.CheckRunApp = true;
            try
            {
                DB = new SQLiteConnection(Database.connectionString);
                await DB.OpenAsync();
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show("Ошибка подключения к БД: " + ex.Message, "Ошибка", "Error");
            }
            try { fbot.Show(); } catch { /* Telegram bot optional */ }
        }
        #region Регистрация
        [Obsolete]
        private void ButtonRegUser_Click(object sender, EventArgs e)
        {
            Form fReg = new RegisterForm();
            fReg.Show();
            fReg.FormClosed += new FormClosedEventHandler(Form_FormClosed);
            Hide();
        }
        #endregion
        #region Управление паролем (Глазик)
        private void ExpUIButtonIconCheckUnlock_Click(object sender, EventArgs e)
        {
            TextBoxPassword.UseSystemPasswordChar = true;
            expUIButtonIconCheckUnlock.Visible = false;
            expUIButtonIconCheckLock.Visible = true;
        }
        private void ExpUIButtonIconCheckLock_Click(object sender, EventArgs e)
        {
            TextBoxPassword.UseSystemPasswordChar = false;
            expUIButtonIconCheckUnlock.Visible = true;
            expUIButtonIconCheckLock.Visible = false;
        }
        #endregion
        #region Выход
        private void ButtonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }
        #endregion
        #region Забыли пароль
        private void LabelForgotPassword_Click(object sender, EventArgs e)
        {
            if (DataRequests.IsOpen)
            {
                return;
            }

            Form fForgotPass = new ForgotPasswordForm();
            fForgotPass.Show();
            DataRequests.IsOpen = true;
        }
        #endregion
        #region Сертификат безопасности
        private void CheckValidatePassword()
        {
            string checkPass = DataUsers.Pass.ToLower();
            foreach (string text in CertificateSecurity.noPasswords)
            {
                if (Regex.IsMatch(checkPass, $"\\b{text}\\b"))
                {
                    MessageBoxUI.Show($"{CertificateSecurity.textError}", $"{CertificateSecurity.textHeadError}", "Error");
                }
            }
        }
        #endregion
        #region Запомнить меня
        private void CheckRemeber()
        {
            string lines = File.ReadAllText(path + directory + nameFileRemember);
            if (lines != "")
            {
                string[] adv = Convert.ToString(lines).Split(':');
                TextBoxLogin.Text = adv[0];
                TextBoxPassword.Text = adv[1];
            }
        }
        private void CheckRemember_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckRemember.Checked)
            {
                string login = TextBoxLogin.Text;
                string password = TextBoxPassword.Text;
                string remember = login + ":" + password;
                File.WriteAllText(path + directory + nameFileRemember, $"{remember}");
            }
        }
        #endregion
        #region Управление формой
        private void FormControl(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _ = ReleaseCapture();
                _ = SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
        #region buttonEnterLogin enabled = true/false
        private void TextBoxPassword_TextChanged(object sender, EventArgs e)
        {
            ButtonEnterLogin.Enabled = !string.IsNullOrWhiteSpace(TextBoxLogin.Text) && !string.IsNullOrWhiteSpace(TextBoxPassword.Text);
        }

        private void TextBoxLogin_TextChanged(object sender, EventArgs e)
        {
            ButtonEnterLogin.Enabled = !string.IsNullOrWhiteSpace(TextBoxLogin.Text) && !string.IsNullOrWhiteSpace(TextBoxPassword.Text);
        }
        #endregion
        #region Вход
        [Obsolete]
        private async void ButtonEnterLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TextBoxLogin.Text) || string.IsNullOrWhiteSpace(TextBoxPassword.Text))
            {
                MessageBoxUI.Show("Введите логин и пароль", "Ошибка авторизации", "Error");
                return;
            }

            // Гарантируем, что соединение открыто и БД рядом с exe
            try
            {
                if (DB == null || DB.State != ConnectionState.Open)
                {
                    string dbPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "teh_db.db");
                    if (!File.Exists(dbPath))
                        dbPath = "teh_db.db";
                    DB = new SQLiteConnection($"Data Source={dbPath};Version=3;BusyTimeout=5000;");
                    await DB.OpenAsync();
                }
            }
            catch (Exception exOpen)
            {
                MessageBoxUI.Show("Не удалось открыть базу данных: " + exOpen.Message, "Ошибка БД", "Error");
                return;
            }

            SQLiteDataReader sqlReader = null;
            try
            {
                string login = TextBoxLogin.Text.Trim();
                string password = TextBoxPassword.Text;

                using (var command = new SQLiteCommand(
                    $"SELECT * FROM [{Table_users.main}] WHERE [{Table_users.login}] = @login AND [{Table_users.pass}] = @pass", DB))
                {
                    command.Parameters.AddWithValue("@login", login);
                    command.Parameters.AddWithValue("@pass", password);

                    sqlReader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                    if (await sqlReader.ReadAsync())
                    {
                        string checkLocked = sqlReader[Table_users.typeAccess]?.ToString() ?? "";
                        if (checkLocked == "LOCKED")
                        {
                            MessageBoxUI.Show("Учетная запись заблокирована! Свяжитесь с системным администратором для восстановления.", "Ошибка авторизации", "Error");
                            Close();
                            return;
                        }

                        DataUsers.Family = sqlReader[Table_users.family]?.ToString();
                        DataUsers.Name = sqlReader[Table_users.name]?.ToString();
                        DataUsers.Father = sqlReader[Table_users.father]?.ToString();
                        DataUsers.Initials = sqlReader[Table_users.initials]?.ToString();
                        DataUsers.Gender = sqlReader[Table_users.gender]?.ToString();
                        DataUsers.Number = sqlReader[Table_users.number]?.ToString();
                        DataUsers.Email = sqlReader[Table_users.email]?.ToString();
                        DataUsers.Depart = sqlReader[Table_users.depart]?.ToString();
                        DataUsers.Position = sqlReader[Table_users.position]?.ToString();
                        DataUsers.Login = sqlReader[Table_users.login]?.ToString();
                        DataUsers.Pass = sqlReader[Table_users.pass]?.ToString();
                        DataUsers.GroupUser = sqlReader[Table_users.groupUser]?.ToString();
                        DataUsers.Image = sqlReader[Table_users.image]?.ToString();

                        sqlReader.Close();
                        sqlReader = null;

                        File.AppendAllText(Logs.file, $"[Вход]{DataUsers.Initials} ({thisDay:dd.MM.yyyy HH:mm}){Environment.NewLine}");

                        string group = DataUsers.GroupUser ?? "";
                        Form fMain = null;
                        if (group == "ADMIN")
                            fMain = new MainAdminForm();
                        else if (group == "WORKER")
                            fMain = new MainWorkerForm();
                        else
                            fMain = new MainUserForm();

                        fMain.Show();
                        fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                        Hide();
                        CheckValidatePassword();
                        return;
                    }
                    sqlReader.Close();
                    sqlReader = null;
                }

                // Неверный логин/пароль — считаем попытки
                using (var commandCheck = new SQLiteCommand(
                    $"SELECT * FROM [{Table_users.main}] WHERE [{Table_users.login}]=@login", DB))
                {
                    commandCheck.Parameters.AddWithValue("@login", login);
                    sqlReader = (SQLiteDataReader)await commandCheck.ExecuteReaderAsync();
                    if (await sqlReader.ReadAsync())
                    {
                        string check = sqlReader[Table_users.typeAccess]?.ToString() ?? "";
                        string initials = sqlReader[Table_users.initials]?.ToString() ?? login;
                        if (attemptLogin > 0 && check != "LOCKED")
                        {
                            attemptLogin -= 1;
                            MessageBoxUI.Show($"Неверный логин или пароль. Осталось попыток: {attemptLogin}", "Ошибка авторизации", "Error");
                        }
                        else
                        {
                            sqlReader.Close();
                            sqlReader = null;
                            using (var commandUpdate = new SQLiteCommand(
                                $"UPDATE {Table_users.main} SET [{Table_users.typeAccess}]=@locked WHERE [{Table_users.login}] = @login", DB))
                            {
                                commandUpdate.Parameters.AddWithValue("@login", login);
                                commandUpdate.Parameters.AddWithValue("@locked", "LOCKED");
                                await commandUpdate.ExecuteNonQueryAsync();
                            }
                            File.AppendAllText(Logs.file, $"[Вход]Учетная запись пользователя {login}|{initials}| заблокирована!({thisDay:dd.MM.yyyy HH:mm}){Environment.NewLine}");
                            MessageBoxUI.Show("Учетная запись заблокирована! Свяжитесь с системным администратором для восстановления.", "Ошибка авторизации", "Error");
                            Close();
                        }
                    }
                    else
                    {
                        MessageBoxUI.Show("Неверный логин или пароль", "Ошибка авторизации", "Error");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show(ex.Message, ex.Source ?? "Error", "Error");
            }
            finally
            {
                sqlReader?.Close();
            }
        }

        [Obsolete]
        public async void EnterLoginPerUser(SQLiteConnection DB)
        {
            DataTable table = new DataTable();
            SQLiteDataAdapter adapter = new SQLiteDataAdapter();
            SQLiteDataReader sqlReader = null;
            SQLiteCommand command = new SQLiteCommand($"SELECT * FROM [{Table_users.main}] WHERE [{Table_users.login}] = '" + LoginPerUser.Login + $"' AND [{Table_users.pass}] = '" + LoginPerUser.Pass + "'", DB);
            try
            {
                adapter.SelectCommand = command;
                _ = adapter.Fill(table);
                if (table.Rows.Count > 0)
                {
                    sqlReader = (SQLiteDataReader)await command.ExecuteReaderAsync();
                    while (await sqlReader.ReadAsync())
                    {
                        DataUsers.Family = sqlReader[$"{Table_users.family}"].ToString();
                        DataUsers.Name = sqlReader[$"{Table_users.name}"].ToString();
                        DataUsers.Father = sqlReader[$"{Table_users.father}"].ToString();
                        DataUsers.Initials = sqlReader[$"{Table_users.initials}"].ToString();
                        DataUsers.Number = sqlReader[$"{Table_users.number}"].ToString();
                        DataUsers.Email = sqlReader[$"{Table_users.email}"].ToString();
                        DataUsers.Depart = sqlReader[$"{Table_users.depart}"].ToString();
                        DataUsers.Position = sqlReader[$"{Table_users.position}"].ToString();
                        DataUsers.Login = sqlReader[$"{Table_users.login}"].ToString();
                        DataUsers.Pass = sqlReader[$"{Table_users.pass}"].ToString();
                        DataUsers.GroupUser = sqlReader[$"{Table_users.groupUser}"].ToString();
                        DataUsers.Image = sqlReader[$"{Table_users.image}"].ToString();
                        if (sqlReader[$"{Table_users.groupUser}"].ToString() == "ADMIN")
                        {
                            Form fMain = new MainAdminForm();
                            fMain.Show();
                            fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                            Hide();
                        }
                        else if (sqlReader[$"{Table_users.groupUser}"].ToString() == "WORKER")
                        {
                            Form fMain = new MainWorkerForm();
                            fMain.Show();
                            fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                            Hide();
                        }
                        else if (sqlReader[$"{Table_users.groupUser}"].ToString() == "USER")
                        {
                            Form fMain = new MainUserForm();
                            fMain.Show();
                            fMain.FormClosed += new FormClosedEventHandler(Form_FormClosed);
                            Hide();
                        }
                        File.AppendAllText(Logs.file, $"[Вход]{DataUsers.Initials} ({thisDay:dd.MM.yyyy HH:mm})");
                        File.AppendAllText(Logs.file, Environment.NewLine);
                        CheckValidatePassword();
                    }
                }
                else
                {
                    MessageBoxUI.Show("Неверный логин или пароль", "Ошибка авторизации", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBoxUI.Show($"{ex.Message}", $"{ex.Source}", "Error");
            }
            finally
            {
                sqlReader?.Close();
            }
        }
        #endregion
    }
}