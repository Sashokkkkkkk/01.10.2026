#!/usr/bin/env python3
"""Создание индексов для ускорения запросов (SQLite / PostgreSQL).

Запуск:
  python apply_indexes.py

Безопасно: CREATE INDEX IF NOT EXISTS. После — ANALYZE.
Индексы также описаны в models.py (__table_args__) — при db.create_all()
на пустой БД они создаются автоматически.
"""
from app import create_app
from models import db
from sqlalchemy import text

INDEXES = [
    # cars — каталог и склад
    "CREATE INDEX IF NOT EXISTS ix_cars_status ON cars(status)",
    "CREATE INDEX IF NOT EXISTS ix_cars_published_status ON cars(published, status)",
    "CREATE INDEX IF NOT EXISTS ix_cars_brand ON cars(brand)",
    "CREATE INDEX IF NOT EXISTS ix_cars_created_at ON cars(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_cars_updated_at ON cars(updated_at)",
    "CREATE INDEX IF NOT EXISTS ix_cars_price ON cars(price)",
    "CREATE INDEX IF NOT EXISTS ix_cars_year ON cars(year)",
    "CREATE INDEX IF NOT EXISTS ix_cars_body_type ON cars(body_type)",
    "CREATE INDEX IF NOT EXISTS ix_cars_catalog ON cars(published, status, created_at)",
    # clients
    "CREATE INDEX IF NOT EXISTS ix_clients_created_at ON clients(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_clients_full_name ON clients(full_name)",
    # leads
    "CREATE INDEX IF NOT EXISTS ix_leads_status ON leads(status)",
    "CREATE INDEX IF NOT EXISTS ix_leads_created_at ON leads(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_leads_status_created ON leads(status, created_at)",
    "CREATE INDEX IF NOT EXISTS ix_leads_type ON leads(type)",
    "CREATE INDEX IF NOT EXISTS ix_leads_client_id ON leads(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_leads_car_id ON leads(car_id)",
    # deals
    "CREATE INDEX IF NOT EXISTS ix_deals_stage ON deals(stage)",
    "CREATE INDEX IF NOT EXISTS ix_deals_updated_at ON deals(updated_at)",
    "CREATE INDEX IF NOT EXISTS ix_deals_client_id ON deals(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_car_id ON deals(car_id)",
    # misc
    "CREATE INDEX IF NOT EXISTS ix_promos_active ON promos(active)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_created_at ON audit_logs(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_user_id ON audit_logs(user_id)",
    "CREATE INDEX IF NOT EXISTS ix_service_bookings_status ON service_bookings(status)",
    "CREATE INDEX IF NOT EXISTS ix_service_bookings_created_at ON service_bookings(created_at)",
]


def main():
    app = create_app()
    with app.app_context():
        for sql in INDEXES:
            db.session.execute(text(sql))
            print('OK:', sql.split('ON')[0].strip())
        db.session.commit()
        try:
            db.session.execute(text('ANALYZE'))
            db.session.commit()
            print('ANALYZE done')
        except Exception as e:
            print('ANALYZE skipped:', e)
        rows = db.session.execute(text(
            "SELECT name, tbl_name FROM sqlite_master WHERE type='index' AND sql IS NOT NULL"
            if 'sqlite' in app.config['SQLALCHEMY_DATABASE_URI']
            else "SELECT indexname, tablename FROM pg_indexes WHERE schemaname='public'"
        )).fetchall()
        print(f'\nВсего индексов: {len(rows)}')
        for name, tbl in rows:
            print(f'  {name} → {tbl}')


if __name__ == '__main__':
    main()
