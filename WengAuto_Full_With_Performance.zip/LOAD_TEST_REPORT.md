# Нагрузочное тестирование и оптимизация БД — WengAuto

## 1. Объём тестовых данных

| Таблица   | Записей |
|-----------|---------|
| cars      | 8 000   |
| clients   | 4 000   |
| leads     | 6 000   |
| deals     | 2 500   |

Скрипты:
- `load_test_data.py` — массовое наполнение
- `benchmark_queries.py` — замер ключевых запросов
- `apply_indexes.py` — создание индексов на существующей БД

## 2. Найденные узкие места (до оптимизации)

| Запрос | Время (avg) | Проблема |
|--------|-------------|----------|
| **warehouse_list ALL** | **~81–106 ms** | `Car.query.order_by(...).all()` — загрузка всех 8000 строк без пагинации |
| warehouse_stats 4× COUNT | ~1.3–12 ms | 4 отдельных `COUNT(*)` вместо одного `GROUP BY` |
| catalog с ILIKE `%brand%` | ~3–5 ms | Ведущий `%` не использует индекс |
| distinct brands/body | ~0.2–1.8 ms | Без индекса — full scan (на 8k ещё терпимо) |

Главный тормоз: **склад без пагинации** (рост линейный с числом авто).

## 3. Выполненные оптимизации

### 3.1 Индексы (`models.py` + `apply_indexes.py`)

```
cars:    status, (published,status), brand, created_at, updated_at,
         price, year, body_type, (published,status,created_at)
leads:   status, created_at, (status,created_at), type, client_id, car_id
deals:   stage, updated_at, client_id, car_id
clients: created_at, full_name
promos:  active
audit_logs, service_bookings: status / created_at
```

### 3.2 Склад (`modules/warehouse.py`)

- Пагинация: `paginate(per_page=50)` вместо `.all()`
- Статистика: один `GROUP BY status` вместо 4× `COUNT`

### 3.3 Каталог (`modules/website.py`)

- Фильтр по марке: **точное сравнение** (`brand == X`) → использует индекс  
  (ILIKE только если в запросе есть `%`/`_`)
- Пагинация: 24 авто на страницу вместо `limit(200)`
- `ORDER BY` + `DISTINCT` с сортировкой

## 4. Результаты замеров (8 000 авто)

| Запрос | До | После | Ускорение |
|--------|-----|-------|-----------|
| warehouse list (все) | **81 ms** | **0.6 ms** (page 50) | **~130×** |
| warehouse stats | 1.3 ms (4 COUNT) | 0.6 ms (GROUP BY) | ~2× |
| catalog_base | ~4.7 ms | ~2.3 ms | ~2× |
| catalog brand | ~4.4 ms | ~3.6 ms (или быстрее при exact) | — |
| distinct brands | ~1.8 ms | ~0.2 ms | ~9× |
| crm_dashboard | ~2.8 ms | ~1.6 ms | ~1.7× |
| admin_analytics | ~6.6 ms | ~4.7 ms | ~1.4× |

**Суммарное время ключевых запросов** снизилось с ~157 ms до единиц–десятков ms на типичный сценарий.

## 5. Как повторить

```bash
# 1. Наполнить БД
python load_test_data.py

# 2. Замерить «до» (без индексов — на чистой копии)
python benchmark_queries.py

# 3. Создать индексы
python apply_indexes.py

# 4. Замерить «после»
python benchmark_queries.py
```

Для PostgreSQL в production те же индексы из `models.__table_args__` создаются через миграции (Alembic) или `apply_indexes.py` (синтаксис совместим).

## 6. Рекомендации на будущее

1. **Пагинация везде**, где `.all()` без лимита (склад, CRM leads/clients/deals).
2. При росте >50–100k строк — перейти на PostgreSQL (GIN/trgm для полнотекста по model).
3. Кэшировать distinct brands/body_types (меняются редко).
4. Для аналитики — материализованные представления или ночные агрегаты.
5. Не использовать `ILIKE '%...%'` для полей, по которым есть select-фильтр.
