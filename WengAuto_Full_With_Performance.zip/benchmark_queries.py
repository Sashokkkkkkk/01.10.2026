#!/usr/bin/env python3
"""Замер скорости ключевых запросов до/после оптимизации."""
import time
import statistics
from contextlib import contextmanager

from app import create_app
from models import db, Car, Client, Lead, Deal, User, Promo, ServiceBooking, AuditLog
from sqlalchemy import func, text


@contextmanager
def timer(label: str, results: dict):
    t0 = time.perf_counter()
    yield
    elapsed_ms = (time.perf_counter() - t0) * 1000
    results.setdefault(label, []).append(elapsed_ms)


def run_once(results: dict):
    # 1. Каталог: фильтр published + status + order + limit (самый частый публичный)
    with timer('catalog_base', results):
        cars = (Car.query
                .filter_by(published=True)
                .filter(Car.status.in_(['in_stock', 'reserved']))
                .order_by(Car.created_at.desc())
                .limit(200)
                .all())

    # 2. Каталог с ILIKE по бренду
    with timer('catalog_brand_ilike', results):
        cars = (Car.query
                .filter_by(published=True)
                .filter(Car.status.in_(['in_stock', 'reserved']))
                .filter(Car.brand.ilike('%Toyota%'))
                .order_by(Car.created_at.desc())
                .limit(200)
                .all())

    # 3. Каталог с фильтром по цене + год
    with timer('catalog_price_year', results):
        cars = (Car.query
                .filter_by(published=True)
                .filter(Car.status.in_(['in_stock', 'reserved']))
                .filter(Car.price >= 2_000_000, Car.price <= 5_000_000)
                .filter(Car.year >= 2022)
                .order_by(Car.created_at.desc())
                .limit(200)
                .all())

    # 4. Distinct бренды (для фильтров)
    with timer('distinct_brands', results):
        brands = db.session.query(Car.brand).distinct().all()

    # 5. Distinct body_type
    with timer('distinct_body_types', results):
        body_types = db.session.query(Car.body_type).distinct().all()

    # 6. Склад: все авто + 4 count
    with timer('warehouse_list_all', results):
        cars = Car.query.order_by(Car.updated_at.desc()).all()

    with timer('warehouse_stats_counts', results):
        stats = {
            'in_stock': Car.query.filter_by(status='in_stock').count(),
            'in_transit': Car.query.filter_by(status='in_transit').count(),
            'reserved': Car.query.filter_by(status='reserved').count(),
            'sold': Car.query.filter_by(status='sold').count(),
        }

    # 7. CRM dashboard
    with timer('crm_dashboard', results):
        new_leads = Lead.query.filter_by(status='new').order_by(Lead.created_at.desc()).limit(10).all()
        deals_count = Deal.query.count()
        clients_count = Client.query.count()
        leads_count = Lead.query.count()
        stages = db.session.query(Deal.stage, func.count(Deal.id)).group_by(Deal.stage).all()

    # 8. CRM leads list
    with timer('crm_leads_list', results):
        items = Lead.query.order_by(Lead.created_at.desc()).limit(500).all()

    # 9. Analytics
    with timer('admin_analytics', results):
        sales_by_brand = (db.session.query(Car.brand, func.count(Car.id))
                          .filter(Car.status == 'sold').group_by(Car.brand).all())
        leads_by_type = (db.session.query(Lead.type, func.count(Lead.id))
                         .group_by(Lead.type).all())
        deals_by_stage = (db.session.query(Deal.stage, func.count(Deal.id))
                          .group_by(Deal.stage).all())
        total_revenue = (db.session.query(func.sum(Deal.amount))
                         .filter(Deal.stage == 'sold').scalar() or 0)
        clients_count = Client.query.count()
        cars_in_stock = Car.query.filter_by(status='in_stock').count()

    # 10. Index page (limit 6)
    with timer('index_featured', results):
        cars = Car.query.filter_by(published=True, status='in_stock').limit(6).all()
        promos = Promo.query.filter_by(active=True).limit(3).all()


def print_report(results: dict, title: str):
    print(f'\n{"="*60}')
    print(f'  {title}')
    print(f'{"="*60}')
    print(f'{"Запрос":<30} {"avg ms":>10} {"min":>8} {"max":>8} {"n":>4}')
    print('-' * 60)
    rows = []
    for label, times in sorted(results.items()):
        avg = statistics.mean(times)
        mn = min(times)
        mx = max(times)
        print(f'{label:<30} {avg:10.2f} {mn:8.2f} {mx:8.2f} {len(times):4d}')
        rows.append((label, avg))
    total = sum(statistics.mean(t) for t in results.values())
    print('-' * 60)
    print(f'{"СУММА avg":<30} {total:10.2f} ms')
    return rows


def main():
    app = create_app()
    with app.app_context():
        print('=== Состояние БД ===')
        print(f'Cars:     {Car.query.count()}')
        print(f'Clients:  {Client.query.count()}')
        print(f'Leads:    {Lead.query.count()}')
        print(f'Deals:    {Deal.query.count()}')
        print(f'Bookings: {ServiceBooking.query.count()}')
        print(f'Audit:    {AuditLog.query.count()}')

        # Проверяем индексы
        indexes = db.session.execute(text(
            "SELECT name, tbl_name, sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL"
        )).fetchall()
        print(f'\nИндексы ({len(indexes)}):')
        for name, tbl, sql in indexes:
            print(f'  {name} on {tbl}')

        results = {}
        N = 5
        print(f'\nЗапуск бенчмарка ({N} прогонов)...')
        for i in range(N):
            run_once(results)
            print(f'  прогон {i+1}/{N}')

        print_report(results, 'РЕЗУЛЬТАТЫ БЕНЧМАРКА')


if __name__ == '__main__':
    main()
