# modules/performance.py — нагрузочные тесты, индексы, замеры (админ-модуль)
import time
import statistics
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from sqlalchemy import text, func

from models import db, Car, Client, Lead, Deal, User, Promo, ServiceBooking, AuditLog
from modules.auth import role_required
from modules.security import client_ip, csrf

performance_bp = Blueprint('performance', __name__, url_prefix='/admin/performance')

INDEX_SQL = [
    "CREATE INDEX IF NOT EXISTS ix_cars_status ON cars(status)",
    "CREATE INDEX IF NOT EXISTS ix_cars_published_status ON cars(published, status)",
    "CREATE INDEX IF NOT EXISTS ix_cars_brand ON cars(brand)",
    "CREATE INDEX IF NOT EXISTS ix_cars_created_at ON cars(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_cars_updated_at ON cars(updated_at)",
    "CREATE INDEX IF NOT EXISTS ix_cars_price ON cars(price)",
    "CREATE INDEX IF NOT EXISTS ix_cars_year ON cars(year)",
    "CREATE INDEX IF NOT EXISTS ix_cars_body_type ON cars(body_type)",
    "CREATE INDEX IF NOT EXISTS ix_cars_catalog ON cars(published, status, created_at)",
    "CREATE INDEX IF NOT EXISTS ix_clients_created_at ON clients(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_clients_full_name ON clients(full_name)",
    "CREATE INDEX IF NOT EXISTS ix_leads_status ON leads(status)",
    "CREATE INDEX IF NOT EXISTS ix_leads_created_at ON leads(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_leads_status_created ON leads(status, created_at)",
    "CREATE INDEX IF NOT EXISTS ix_leads_type ON leads(type)",
    "CREATE INDEX IF NOT EXISTS ix_leads_client_id ON leads(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_leads_car_id ON leads(car_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_stage ON deals(stage)",
    "CREATE INDEX IF NOT EXISTS ix_deals_updated_at ON deals(updated_at)",
    "CREATE INDEX IF NOT EXISTS ix_deals_client_id ON deals(client_id)",
    "CREATE INDEX IF NOT EXISTS ix_deals_car_id ON deals(car_id)",
    "CREATE INDEX IF NOT EXISTS ix_promos_active ON promos(active)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_created_at ON audit_logs(created_at)",
    "CREATE INDEX IF NOT EXISTS ix_audit_logs_user_id ON audit_logs(user_id)",
    "CREATE INDEX IF NOT EXISTS ix_service_bookings_status ON service_bookings(status)",
    "CREATE INDEX IF NOT EXISTS ix_service_bookings_created_at ON service_bookings(created_at)",
]


def _db_stats():
    return {
        'cars': Car.query.count(),
        'clients': Client.query.count(),
        'leads': Lead.query.count(),
        'deals': Deal.query.count(),
        'bookings': ServiceBooking.query.count(),
        'audit': AuditLog.query.count(),
        'users': User.query.count(),
        'promos': Promo.query.count(),
    }


def _index_count():
    try:
        uri = str(db.engine.url)
        if 'sqlite' in uri:
            n = db.session.execute(text(
                "SELECT count(*) FROM sqlite_master WHERE type='index' AND sql IS NOT NULL"
            )).scalar()
        else:
            n = db.session.execute(text(
                "SELECT count(*) FROM pg_indexes WHERE schemaname='public'"
            )).scalar()
        return int(n or 0)
    except Exception:
        return 0


def _run_benchmarks(rounds: int = 3):
    """Возвращает список {name, avg_ms, min_ms, max_ms}."""
    tests = []

    def measure(name, fn):
        times = []
        for _ in range(rounds):
            t0 = time.perf_counter()
            fn()
            times.append((time.perf_counter() - t0) * 1000)
        tests.append({
            'name': name,
            'avg_ms': round(statistics.mean(times), 2),
            'min_ms': round(min(times), 2),
            'max_ms': round(max(times), 2),
        })

    measure('Каталог (published+status, limit 200)', lambda: (
        Car.query.filter_by(published=True)
        .filter(Car.status.in_(['in_stock', 'reserved']))
        .order_by(Car.created_at.desc()).limit(200).all()
    ))
    measure('Каталог + фильтр brand', lambda: (
        Car.query.filter_by(published=True)
        .filter(Car.status.in_(['in_stock', 'reserved']))
        .filter(Car.brand == 'Toyota')
        .order_by(Car.created_at.desc()).limit(200).all()
    ))
    measure('Склад: страница 50', lambda: (
        Car.query.order_by(Car.updated_at.desc()).limit(50).all()
    ))
    measure('Склад: GROUP BY status', lambda: (
        list(db.session.query(Car.status, func.count(Car.id)).group_by(Car.status).all())
    ))
    measure('Склад: все строки (старый способ)', lambda: (
        Car.query.order_by(Car.updated_at.desc()).all()
    ))
    measure('CRM dashboard', lambda: (
        Lead.query.filter_by(status='new').order_by(Lead.created_at.desc()).limit(10).all(),
        Deal.query.count(),
        Client.query.count(),
        list(db.session.query(Deal.stage, func.count(Deal.id)).group_by(Deal.stage).all()),
    ))
    measure('Лиды list 500', lambda: (
        Lead.query.order_by(Lead.created_at.desc()).limit(500).all()
    ))
    measure('Аналитика admin', lambda: (
        list(db.session.query(Car.brand, func.count(Car.id)).filter(Car.status == 'sold').group_by(Car.brand).all()),
        list(db.session.query(Lead.type, func.count(Lead.id)).group_by(Lead.type).all()),
        db.session.query(func.sum(Deal.amount)).filter(Deal.stage == 'sold').scalar(),
    ))
    measure('DISTINCT brands', lambda: list(db.session.query(Car.brand).distinct().all()))
    return tests


def _bulk_seed(cars_n=2000, clients_n=1000, leads_n=1500, deals_n=500):
    """Умеренное наполнение через веб (не блокирует надолго)."""
    import random
    from datetime import datetime, timedelta

    brands = ['Toyota', 'BMW', 'Hyundai', 'Kia', 'Mercedes-Benz', 'Volkswagen',
              'Lada', 'Audi', 'Porsche', 'Tesla', 'Lexus', 'Skoda']
    bodies = ['седан', 'кроссовер', 'хэтчбек']
    statuses = ['in_stock', 'in_transit', 'reserved', 'sold']
    lead_types = ['callback', 'test_drive', 'credit', 'trade_in', 'service']
    lead_statuses = ['new', 'in_progress', 'done', 'rejected', 'converted']
    deal_stages = ['new', 'negotiation', 'contract', 'sold', 'lost']
    first = ['Александр', 'Дмитрий', 'Максим', 'Сергей', 'Анна', 'Мария']
    last = ['Иванов', 'Петров', 'Сидоров', 'Смирнов']

    added = {'cars': 0, 'clients': 0, 'leads': 0, 'deals': 0}
    base = Car.query.count()

    batch = []
    for i in range(cars_n):
        st = random.choices(statuses, weights=[50, 10, 15, 25])[0]
        year = random.randint(2018, 2026)
        batch.append(Car(
            vin=f'WEB{base + i:014d}'[:17],
            brand=random.choice(brands), model='X', year=year,
            price=float(random.randint(1_000_000, 8_000_000)),
            body_type=random.choice(bodies), transmission='АКПП', drive='полный',
            engine='2.0', power_hp=200, color_body='Белый', color_interior='Чёрный',
            mileage=0 if year >= 2024 else 40000, is_new=year >= 2024,
            status=st, description='load-test', image_url='/static/img/car-placeholder.jpg',
            published=(st != 'sold'),
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 400)),
            updated_at=datetime.utcnow(),
        ))
        if len(batch) >= 200:
            db.session.bulk_save_objects(batch)
            db.session.commit()
            added['cars'] += len(batch)
            batch = []
    if batch:
        db.session.bulk_save_objects(batch)
        db.session.commit()
        added['cars'] += len(batch)

    batch = []
    for i in range(clients_n):
        batch.append(Client(
            full_name=f'{random.choice(last)} {random.choice(first)}',
            phone=f'+79{random.randint(100000000, 999999999)}',
            source=random.choice(['site', 'call', 'messenger', 'social']),
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 200)),
        ))
        if len(batch) >= 200:
            db.session.bulk_save_objects(batch)
            db.session.commit()
            added['clients'] += len(batch)
            batch = []
    if batch:
        db.session.bulk_save_objects(batch)
        db.session.commit()
        added['clients'] += len(batch)

    cids = [r[0] for r in db.session.query(Client.id).limit(3000).all()]
    carids = [r[0] for r in db.session.query(Car.id).limit(2000).all()]
    uids = [r[0] for r in db.session.query(User.id).all()] or [None]

    batch = []
    for i in range(leads_n):
        batch.append(Lead(
            client_id=random.choice(cids) if cids else None,
            type=random.choice(lead_types),
            status=random.choice(lead_statuses),
            message=f'web-load {i}',
            car_id=random.choice(carids) if carids and random.random() > 0.4 else None,
            manager_id=random.choice(uids) if uids[0] else None,
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 120)),
        ))
        if len(batch) >= 200:
            db.session.bulk_save_objects(batch)
            db.session.commit()
            added['leads'] += len(batch)
            batch = []
    if batch:
        db.session.bulk_save_objects(batch)
        db.session.commit()
        added['leads'] += len(batch)

    batch = []
    for i in range(deals_n):
        stage = random.choice(deal_stages)
        batch.append(Deal(
            client_id=random.choice(cids) if cids else 1,
            car_id=random.choice(carids) if carids and random.random() > 0.2 else None,
            stage=stage,
            amount=float(random.randint(1_500_000, 6_000_000)) if stage in ('contract', 'sold') else None,
            manager_id=uids[0],
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 150)),
            updated_at=datetime.utcnow(),
        ))
        if len(batch) >= 200:
            db.session.bulk_save_objects(batch)
            db.session.commit()
            added['deals'] += len(batch)
            batch = []
    if batch:
        db.session.bulk_save_objects(batch)
        db.session.commit()
        added['deals'] += len(batch)

    return added


@performance_bp.route('/')
@login_required
@role_required('admin')
def index():
    stats = _db_stats()
    idx = _index_count()
    return render_template(
        'admin/performance.html',
        stats=stats,
        index_count=idx,
        results=None,
        seed_result=None,
    )


@performance_bp.route('/apply-indexes', methods=['POST'])
@login_required
@role_required('admin')
def apply_indexes():
    created = 0
    errors = []
    for sql in INDEX_SQL:
        try:
            db.session.execute(text(sql))
            created += 1
        except Exception as e:
            errors.append(str(e))
    try:
        db.session.execute(text('ANALYZE'))
    except Exception:
        pass
    db.session.commit()
    db.session.add(AuditLog(
        user_id=current_user.id, action='apply_indexes',
        details=f'indexes_ok={created} errors={len(errors)}',
        ip_address=client_ip(),
    ))
    db.session.commit()
    if errors:
        flash(f'Индексы: применено {created}, ошибок: {len(errors)}', 'warning')
    else:
        flash(f'Индексы применены ({created} SQL). ANALYZE выполнен.', 'success')
    return redirect(url_for('performance.index'))


@performance_bp.route('/benchmark', methods=['POST'])
@login_required
@role_required('admin')
def benchmark():
    results = _run_benchmarks(rounds=3)
    stats = _db_stats()
    idx = _index_count()
    db.session.add(AuditLog(
        user_id=current_user.id, action='benchmark',
        details=f'cars={stats["cars"]} tests={len(results)}',
        ip_address=client_ip(),
    ))
    db.session.commit()
    flash('Бенчмарк выполнен (3 прогона на каждый запрос).', 'success')
    return render_template(
        'admin/performance.html',
        stats=stats,
        index_count=idx,
        results=results,
        seed_result=None,
    )


@performance_bp.route('/seed', methods=['POST'])
@login_required
@role_required('admin')
def seed_data():
    # Ограниченные объёмы для веб-интерфейса (чтобы не повесить сервер)
    size = (request.form.get('size') or 'medium').strip()
    presets = {
        'small': dict(cars_n=500, clients_n=300, leads_n=400, deals_n=150),
        'medium': dict(cars_n=2000, clients_n=1000, leads_n=1500, deals_n=500),
        'large': dict(cars_n=5000, clients_n=2500, leads_n=4000, deals_n=1500),
    }
    kw = presets.get(size, presets['medium'])
    t0 = time.perf_counter()
    try:
        added = _bulk_seed(**kw)
        elapsed = round(time.perf_counter() - t0, 1)
        db.session.add(AuditLog(
            user_id=current_user.id, action='seed_load_data',
            details=f'size={size} added={added} sec={elapsed}',
            ip_address=client_ip(),
        ))
        db.session.commit()
        flash(f'Данные добавлены за {elapsed} с: {added}', 'success')
        seed_result = {'added': added, 'elapsed': elapsed, 'size': size}
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка наполнения: {e}', 'danger')
        seed_result = None
    stats = _db_stats()
    idx = _index_count()
    return render_template(
        'admin/performance.html',
        stats=stats,
        index_count=idx,
        results=None,
        seed_result=seed_result,
    )
