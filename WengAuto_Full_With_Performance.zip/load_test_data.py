#!/usr/bin/env python3
"""Наполнение БД большим объёмом данных для нагрузочного тестирования."""
import random
import string
import time
from datetime import datetime, timedelta

from app import create_app
from models import db, Car, Client, Lead, Deal, User, Promo, ServiceBooking, AuditLog

BRANDS = [
    'Toyota', 'BMW', 'Hyundai', 'Kia', 'Mercedes-Benz', 'Volkswagen',
    'Lada', 'Audi', 'Porsche', 'Tesla', 'Lexus', 'Skoda', 'Ford',
    'Nissan', 'Mazda', 'Honda', 'Renault', 'Chevrolet', 'Geely', 'Chery'
]
MODELS = {
    'Toyota': ['Camry', 'RAV4', 'Corolla', 'Land Cruiser', 'Highlander'],
    'BMW': ['X5', 'X3', '3 Series', '5 Series', 'X7'],
    'Hyundai': ['Tucson', 'Santa Fe', 'Elantra', 'Creta', 'Palisade'],
    'Kia': ['Sportage', 'Sorento', 'Rio', 'Ceed', 'K5'],
    'Mercedes-Benz': ['E-Class', 'C-Class', 'GLC', 'GLE', 'S-Class'],
    'Volkswagen': ['Tiguan', 'Polo', 'Passat', 'Touareg', 'Golf'],
    'Lada': ['Vesta', 'Granta', 'Niva', 'Largus', 'XRay'],
    'Audi': ['A4', 'A6', 'Q5', 'Q7', 'A3'],
    'Porsche': ['Cayenne', 'Macan', 'Panamera', '911', 'Taycan'],
    'Tesla': ['Model 3', 'Model Y', 'Model S', 'Model X'],
    'Lexus': ['RX', 'NX', 'ES', 'LX', 'UX'],
    'Skoda': ['Octavia', 'Kodiaq', 'Rapid', 'Superb', 'Karoq'],
    'Ford': ['Focus', 'Mondeo', 'Explorer', 'Kuga', 'Mustang'],
    'Nissan': ['Qashqai', 'X-Trail', 'Almera', 'Murano', 'Pathfinder'],
    'Mazda': ['CX-5', 'CX-30', '3', '6', 'CX-9'],
    'Honda': ['CR-V', 'Civic', 'Accord', 'Pilot', 'HR-V'],
    'Renault': ['Duster', 'Arkana', 'Logan', 'Kaptur', 'Sandero'],
    'Chevrolet': ['Tahoe', 'Trailblazer', 'Malibu', 'Equinox'],
    'Geely': ['Coolray', 'Atlas', 'Monjaro', 'Tugella'],
    'Chery': ['Tiggo 7', 'Tiggo 8', 'Arrizo 8', 'Tiggo 4'],
}
BODY_TYPES = ['седан', 'кроссовер', 'хэтчбек', 'универсал', 'внедорожник', 'купе']
TRANSMISSIONS = ['АКПП', 'МКПП', 'робот', 'вариатор']
DRIVES = ['передний', 'задний', 'полный']
COLORS = ['Белый', 'Чёрный', 'Серый', 'Серебристый', 'Синий', 'Красный', 'Коричневый', 'Зелёный']
STATUSES = ['in_stock', 'in_transit', 'reserved', 'sold']
LEAD_TYPES = ['callback', 'test_drive', 'credit', 'trade_in', 'service']
LEAD_STATUSES = ['new', 'in_progress', 'done', 'rejected', 'converted']
DEAL_STAGES = ['new', 'negotiation', 'contract', 'sold', 'lost']
SOURCES = ['site', 'call', 'messenger', 'social']
FIRST_NAMES = ['Александр', 'Дмитрий', 'Максим', 'Сергей', 'Андрей', 'Алексей', 'Иван',
               'Михаил', 'Евгений', 'Николай', 'Анна', 'Мария', 'Елена', 'Ольга', 'Наталья',
               'Екатерина', 'Татьяна', 'Ирина', 'Светлана', 'Юлия']
LAST_NAMES = ['Иванов', 'Петров', 'Сидоров', 'Смирнов', 'Кузнецов', 'Попов', 'Васильев',
              'Соколов', 'Михайлов', 'Новиков', 'Фёдоров', 'Морозов', 'Волков', 'Алексеев',
              'Лебедев', 'Семёнов', 'Егоров', 'Павлов', 'Козлов', 'Степанов']


def random_vin(i: int) -> str:
    return f'XW8ZZZ61ZJG{i:06d}'[:17]


def bulk_cars(n: int = 15000):
    print(f'  Генерация {n} автомобилей...')
    cars = []
    for i in range(n):
        brand = random.choice(BRANDS)
        model = random.choice(MODELS.get(brand, ['Unknown']))
        year = random.randint(2015, 2026)
        is_new = year >= 2024 and random.random() > 0.3
        status = random.choices(STATUSES, weights=[50, 10, 15, 25])[0]
        price = random.randint(800_000, 12_000_000)
        cars.append(Car(
            vin=random_vin(100000 + i),
            brand=brand,
            model=model,
            year=year,
            price=float(price),
            body_type=random.choice(BODY_TYPES),
            transmission=random.choice(TRANSMISSIONS),
            drive=random.choice(DRIVES),
            engine=f'{random.choice([1.4, 1.6, 2.0, 2.5, 3.0]):.1f}',
            power_hp=random.randint(100, 450),
            color_body=random.choice(COLORS),
            color_interior=random.choice(['Чёрный', 'Бежевый', 'Серый', 'Коричневый']),
            mileage=0 if is_new else random.randint(5000, 150000),
            is_new=is_new,
            status=status,
            description=f'{brand} {model} {year}. Автоматически сгенерированная запись.',
            image_url='/static/img/car-placeholder.jpg',
            published=(status != 'sold' and random.random() > 0.1),
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 730)),
            updated_at=datetime.utcnow() - timedelta(days=random.randint(0, 30)),
        ))
        if len(cars) >= 500:
            db.session.bulk_save_objects(cars)
            db.session.commit()
            cars = []
            print(f'    ... {i+1}/{n}')
    if cars:
        db.session.bulk_save_objects(cars)
        db.session.commit()
    print(f'  Готово: {Car.query.count()} автомобилей')


def bulk_clients(n: int = 8000):
    print(f'  Генерация {n} клиентов...')
    clients = []
    for i in range(n):
        fn = random.choice(FIRST_NAMES)
        ln = random.choice(LAST_NAMES)
        clients.append(Client(
            full_name=f'{ln} {fn}',
            phone=f'+79{random.randint(100000000, 999999999)}',
            email=f'client{i}@example.com' if random.random() > 0.3 else None,
            source=random.choice(SOURCES),
            notes=None,
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 365)),
        ))
        if len(clients) >= 500:
            db.session.bulk_save_objects(clients)
            db.session.commit()
            clients = []
            print(f'    ... {i+1}/{n}')
    if clients:
        db.session.bulk_save_objects(clients)
        db.session.commit()
    print(f'  Готово: {Client.query.count()} клиентов')


def bulk_leads(n: int = 12000):
    print(f'  Генерация {n} лидов...')
    client_ids = [c.id for c in Client.query.with_entities(Client.id).all()]
    car_ids = [c.id for c in Car.query.with_entities(Car.id).limit(5000).all()]
    manager_ids = [u.id for u in User.query.filter(User.role.in_(['manager', 'admin'])).all()]
    leads = []
    for i in range(n):
        leads.append(Lead(
            client_id=random.choice(client_ids) if client_ids else None,
            type=random.choice(LEAD_TYPES),
            status=random.choices(LEAD_STATUSES, weights=[30, 25, 20, 15, 10])[0],
            message=f'Заявка #{i} от клиента',
            car_id=random.choice(car_ids) if car_ids and random.random() > 0.4 else None,
            manager_id=random.choice(manager_ids) if manager_ids and random.random() > 0.5 else None,
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 180)),
        ))
        if len(leads) >= 500:
            db.session.bulk_save_objects(leads)
            db.session.commit()
            leads = []
            print(f'    ... {i+1}/{n}')
    if leads:
        db.session.bulk_save_objects(leads)
        db.session.commit()
    print(f'  Готово: {Lead.query.count()} лидов')


def bulk_deals(n: int = 5000):
    print(f'  Генерация {n} сделок...')
    client_ids = [c.id for c in Client.query.with_entities(Client.id).all()]
    car_ids = [c.id for c in Car.query.with_entities(Car.id).limit(3000).all()]
    manager_ids = [u.id for u in User.query.filter(User.role.in_(['manager', 'admin'])).all()]
    deals = []
    for i in range(n):
        stage = random.choices(DEAL_STAGES, weights=[20, 25, 15, 25, 15])[0]
        deals.append(Deal(
            client_id=random.choice(client_ids),
            car_id=random.choice(car_ids) if car_ids and random.random() > 0.2 else None,
            stage=stage,
            amount=float(random.randint(1_000_000, 8_000_000)) if stage in ('contract', 'sold') else None,
            manager_id=random.choice(manager_ids) if manager_ids else None,
            notes=None,
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 200)),
            updated_at=datetime.utcnow() - timedelta(days=random.randint(0, 30)),
        ))
        if len(deals) >= 500:
            db.session.bulk_save_objects(deals)
            db.session.commit()
            deals = []
            print(f'    ... {i+1}/{n}')
    if deals:
        db.session.bulk_save_objects(deals)
        db.session.commit()
    print(f'  Готово: {Deal.query.count()} сделок')


def bulk_bookings(n: int = 2000):
    print(f'  Генерация {n} записей на сервис...')
    bookings = []
    for i in range(n):
        bookings.append(ServiceBooking(
            client_name=f'{random.choice(LAST_NAMES)} {random.choice(FIRST_NAMES)}',
            phone=f'+79{random.randint(100000000, 999999999)}',
            car_info=f'{random.choice(BRANDS)} {random.randint(2015, 2024)}',
            service_type=random.choice(['ТО', 'Диагностика', 'Ремонт', 'Шиномонтаж', 'Кузовной']),
            preferred_date=datetime.utcnow() + timedelta(days=random.randint(1, 30)),
            status=random.choice(['pending', 'confirmed', 'done', 'cancelled']),
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 90)),
        ))
        if len(bookings) >= 500:
            db.session.bulk_save_objects(bookings)
            db.session.commit()
            bookings = []
    if bookings:
        db.session.bulk_save_objects(bookings)
        db.session.commit()
    print(f'  Готово: {ServiceBooking.query.count()} записей')


def bulk_audit(n: int = 3000):
    print(f'  Генерация {n} записей аудита...')
    user_ids = [u.id for u in User.query.with_entities(User.id).all()]
    actions = ['login', 'add_car', 'edit_car', 'update_lead', 'create_deal', 'add_user', 'view']
    logs = []
    for i in range(n):
        logs.append(AuditLog(
            user_id=random.choice(user_ids) if user_ids and random.random() > 0.1 else None,
            action=random.choice(actions),
            details=f'Авто-запись аудита #{i}',
            ip_address=f'192.168.{random.randint(0,255)}.{random.randint(1,254)}',
            created_at=datetime.utcnow() - timedelta(days=random.randint(0, 60)),
        ))
        if len(logs) >= 500:
            db.session.bulk_save_objects(logs)
            db.session.commit()
            logs = []
    if logs:
        db.session.bulk_save_objects(logs)
        db.session.commit()
    print(f'  Готово: {AuditLog.query.count()} записей аудита')


def main():
    app = create_app()
    with app.app_context():
        db.create_all()
        print('=== Наполнение БД для нагрузочного тестирования ===')
        t0 = time.perf_counter()

        # Уже есть ~12 машин — добавляем массово
        existing_cars = Car.query.count()
        if existing_cars < 1000:
            bulk_cars(15000)
        else:
            print(f'  Cars уже {existing_cars}, пропускаем')

        if Client.query.count() < 1000:
            bulk_clients(8000)
        else:
            print(f'  Clients уже есть, пропускаем')

        if Lead.query.count() < 1000:
            bulk_leads(12000)
        else:
            print(f'  Leads уже есть, пропускаем')

        if Deal.query.count() < 500:
            bulk_deals(5000)
        else:
            print(f'  Deals уже есть, пропускаем')

        if ServiceBooking.query.count() < 200:
            bulk_bookings(2000)
        else:
            print(f'  Bookings уже есть, пропускаем')

        if AuditLog.query.count() < 200:
            bulk_audit(3000)
        else:
            print(f'  Audit уже есть, пропускаем')

        elapsed = time.perf_counter() - t0
        print(f'\n=== Итого ===')
        print(f'Cars:      {Car.query.count()}')
        print(f'Clients:   {Client.query.count()}')
        print(f'Leads:     {Lead.query.count()}')
        print(f'Deals:     {Deal.query.count()}')
        print(f'Bookings:  {ServiceBooking.query.count()}')
        print(f'Audit:     {AuditLog.query.count()}')
        print(f'Время наполнения: {elapsed:.1f} сек')


if __name__ == '__main__':
    main()
