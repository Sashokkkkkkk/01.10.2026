from functools import wraps
from flask import Flask, jsonify, render_template, request, abort

from config import Config
from models import get_all_cars
from partners import fetch_from_partner

app = Flask(__name__)
app.config.from_object(Config)


# ============ Декоратор: проверка API-ключа + CORS ============
def require_partner_key(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        origin = request.headers.get("Origin", "")
        cors = {}
        if origin == app.config["ALLOWED_PARTNER_ORIGIN"]:
            cors = {
                "Access-Control-Allow-Origin": origin,
                "Access-Control-Allow-Headers": "X-API-Key, Content-Type",
                "Access-Control-Allow-Methods": "GET, OPTIONS",
            }

        if request.method == "OPTIONS":
            return ("", 204, cors)

        if request.headers.get("X-API-Key") != app.config["MY_API_KEY"]:
            abort(401, description="Invalid API key")

        resp = f(*args, **kwargs)
        resp.headers.update(cors)
        return resp
    return wrapper


# ============ Своя страница ============
@app.route("/")
def index():
    return render_template("index.html")


# ============ МЫ отдаём авто партнёру ============
@app.route("/api/partner/cars", methods=["GET", "OPTIONS"])
@require_partner_key
def api_partner_cars():
    return jsonify({"items": get_all_cars()})


# ============ МЫ тянем мото у партнёра (прокси через сервер) ============
@app.route("/partner-bikes")
def partner_bikes():
    return jsonify({"items": fetch_from_partner("bikes")})


if __name__ == "__main__":
    app.run(debug=True, port=5000)